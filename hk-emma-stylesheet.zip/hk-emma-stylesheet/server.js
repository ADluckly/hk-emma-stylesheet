const child_process = require('child_process');
const express = require('express');
const cors = require('cors');
const path = require('path');
const main = express();

main.use(cors());
main.use('/', express.static('main'));
main.use('/app', express.static('src/app/example/storybook-static'));
main.use('/web', express.static('src/web/storybook-static'));

// endpoint to get the pre-built emma classname list for class name verifier extension
main.use('/api/static/verifier/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/api/classNameVerifier')(req, res, next);
});

// endpoint to download a zip file of the class name verifier extension
main.use('/api/verifier/download', (req, res) => {
  req.url = getBaseName(req.originalUrl);
  const ZIP_INPUT_PATH = 'src/classNameVerifier';
  const ZIP_OUTPUT_PATH =
    'src/api/classNameVerifier/classNameVerifierExtension.zip';
  child_process.execSync(`zip -r ../../${ZIP_OUTPUT_PATH} *`, {
    cwd: ZIP_INPUT_PATH
  });
  res.download(ZIP_OUTPUT_PATH, function (error) {
    if (error) {
      console.error(error);
      return;
    }
  });
});

main.use('/app/static/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/app/example/storybook-static/static')(req, res, next);
});

main.use('/app/static/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/app/example/storybook-static/static/media')(
    req,
    res,
    next
  );
});

main.use('/app/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/app/example/storybook-static')(req, res, next);
});

main.use('/web/static/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/web/storybook-static/static')(req, res, next);
});

main.use('/web/static/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/web/storybook-static/static/media')(req, res, next);
});

main.use('/web/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('src/web/storybook-static')(req, res, next);
});

main.use('/main/static/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('storybook-static/static')(req, res, next);
});

main.use('/main/static/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('storybook-static/static/media')(req, res, next);
});

main.use('/main/*', (req, res, next) => {
  req.url = getBaseName(req.originalUrl);
  express.static('storybook-static')(req, res, next);
});

main.get('/', (req, res) => {
  res.redirect('/main/index.html');
});

main.listen(8080, function () {
  console.log('Server listening on port 8080');
});

function getBaseName(originalUrl) {
  return path.basename(originalUrl.split('?')[0]);
}
