export declare const INPUT_TYPE_TEXT = "text";
export declare const INPUT_TYPE_EMAIL = "email";
export declare const INPUT_TYPE_FULL_NAME = "fullName";
export declare const INPUT_TYPE_MOBILE = "mobile";
export declare const INPUT_TYPE_HKID = "hkid";
export declare const INPUT_TYPE_CHECKDIGIT = "checkDigit";
export declare const INPUT_TYPE_NUMBER = "number";
export declare const TEXTAREA = "textarea";
