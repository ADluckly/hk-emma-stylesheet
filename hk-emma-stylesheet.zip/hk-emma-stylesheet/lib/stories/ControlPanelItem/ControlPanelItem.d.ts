import React, { Component } from 'react';
import './ControlPanelItem.scss';
declare type ControlPanelItemProps = {
    childrenClassName?: string;
    childrenTips?: string;
    children: React.ReactNode;
};
export default class ControlPanelItem extends Component<ControlPanelItemProps> {
    render(): JSX.Element;
}
export {};
