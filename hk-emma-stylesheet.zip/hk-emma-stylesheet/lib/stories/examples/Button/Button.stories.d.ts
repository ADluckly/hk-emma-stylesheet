import { ComponentStory } from '@storybook/react';
import './button.scss';
declare const _default: {
    title: string;
};
export default _default;
export declare const Primary: ComponentStory<() => JSX.Element>;
export declare const Secondary: ComponentStory<() => JSX.Element>;
export declare const White: ComponentStory<() => JSX.Element>;
