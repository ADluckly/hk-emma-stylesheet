import DemoFormDataContainer from './DemoFormDataContainer';
declare const _default: {
    title: string;
    component: typeof DemoFormDataContainer;
};
export default _default;
export declare const FormPageDemo: () => JSX.Element;
export declare const ReviewPageDemo: () => JSX.Element;
