import React from 'react';
import './demoFormData.scss';
import './demoFormData.scss';
declare type DemoFormDataContainerState = {
    isShowFullNameCorrect: boolean;
    isShowEmailCorrect: boolean;
    isShowMobileCorrect: boolean;
    isShowFullNameError: boolean;
    isShowMobileError: boolean;
    isShowEmailError: boolean;
    countryValue: string | any;
    fullNameValue: string;
    mobileValue: string;
    emailValue: string;
    isEnableButton: boolean;
};
declare class DemoFormDataContainer extends React.Component<any, DemoFormDataContainerState> {
    constructor(props: any);
    onFullNameChange: (e: React.ChangeEvent<HTMLInputElement> | any) => void;
    onFullNameBlur: (e: React.FocusEvent<HTMLInputElement>) => void;
    onFullNameFocus: (e: React.FocusEvent<HTMLInputElement>) => void;
    onEmailChange: (e: React.ChangeEvent<HTMLInputElement> | any) => void;
    onEmailBlur: (e: React.FocusEvent<HTMLInputElement>) => void;
    onEmailFocus: (e: React.FocusEvent<HTMLInputElement>) => void;
    onMobileChange: (e: React.ChangeEvent<HTMLInputElement> | any) => void;
    onMobileBlur: (e: React.FocusEvent<HTMLSelectElement>) => void;
    onMobileFocus: (e: React.FocusEvent<HTMLSelectElement>) => void;
    validationForm: () => boolean;
    render(): JSX.Element;
}
export default DemoFormDataContainer;
