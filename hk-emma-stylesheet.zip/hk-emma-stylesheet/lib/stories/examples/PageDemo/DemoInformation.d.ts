import React from 'react';
import './demoInformation.scss';
import './demoInformation.scss';
declare type DemoInformationContainerState = {
    isCheckRadio: boolean;
    list: any;
};
declare class DemoInformationContainer extends React.Component<any, DemoInformationContainerState> {
    constructor(props: any);
    clickRadioButton: (val: boolean) => void;
    render(): JSX.Element;
}
export default DemoInformationContainer;
