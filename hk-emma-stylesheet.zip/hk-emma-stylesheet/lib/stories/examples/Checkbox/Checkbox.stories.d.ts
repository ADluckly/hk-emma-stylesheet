import { ComponentStory } from '@storybook/react';
import { InputField } from '../../../index';
import './CheckboxButton.scss';
export declare const CheckboxPrimary: ComponentStory<typeof InputField>;
declare const _default: {
    title: string;
    component: ComponentStory<typeof InputField>;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
