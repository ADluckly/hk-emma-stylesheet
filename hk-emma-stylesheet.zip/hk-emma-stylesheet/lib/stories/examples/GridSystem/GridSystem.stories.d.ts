import './GridSystem.scss';
declare const _default: {
    title: string;
    component: () => JSX.Element;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const GridSystemPrimary: () => JSX.Element;
