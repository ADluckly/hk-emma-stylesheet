import { ComponentStory } from '@storybook/react';
import { InputField } from '../../../index';
import './RadioButton.scss';
export declare const RadioPrimary: ComponentStory<typeof InputField>;
declare const _default: {
    title: string;
    component: ComponentStory<typeof InputField>;
};
export default _default;
