import { ComponentStory } from '@storybook/react';
import { InputField } from '../../../index';
import './Loading.scss';
export declare const LoadingPrimary: ComponentStory<typeof InputField>;
declare const _default: {
    title: string;
    component: ComponentStory<typeof InputField>;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
