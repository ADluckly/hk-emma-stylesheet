import React from 'react';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: React.FC<{
        prefix?: JSX.Element | undefined;
        suffix?: JSX.Element | undefined;
        buttonText: string;
    }>;
};
export default _default;
export declare const RedirectBlockButton: ComponentStory<React.FC<{
    prefix?: JSX.Element | undefined;
    suffix?: JSX.Element | undefined;
    buttonText: string;
}>>;
