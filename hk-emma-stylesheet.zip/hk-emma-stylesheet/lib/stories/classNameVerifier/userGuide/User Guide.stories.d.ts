import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: () => JSX.Element;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const UserGuide: ComponentStory<() => JSX.Element>;
