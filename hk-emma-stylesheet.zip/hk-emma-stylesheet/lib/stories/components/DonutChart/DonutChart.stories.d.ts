import { ComponentStory } from '@storybook/react';
import DonutChart from '../../../components/DonutChart/DonutChart';
declare const _default: {
    title: string;
    component: ComponentStory<typeof DonutChart>;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const DonutChartPrimary: ComponentStory<typeof DonutChart>;
