import { ComponentStory } from '@storybook/react';
import ArrowTab from '../../../components/ArrowTab/ArrowTab';
import './ArrowTab.scss';
declare const _default: {
    title: string;
    component: typeof ArrowTab;
};
export default _default;
export declare const ArrowTabPrimary: ComponentStory<typeof ArrowTab>;
