import { ComponentStory } from '@storybook/react';
import Notification from '../../../components/Notification/Notification';
declare const _default: {
    title: string;
    component: typeof Notification;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const NotificationPrimary: ComponentStory<typeof Notification>;
