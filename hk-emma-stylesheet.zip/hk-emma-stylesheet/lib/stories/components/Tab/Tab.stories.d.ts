import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
};
export default _default;
export declare const TabPrimary: ComponentStory<() => JSX.Element>;
