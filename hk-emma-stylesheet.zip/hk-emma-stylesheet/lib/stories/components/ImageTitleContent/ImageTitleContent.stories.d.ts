import React from 'react';
import { ImageTitleContentProps } from '../../../components/ImageTitleContent/ImageTitleContent';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: React.FC<ImageTitleContentProps>;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const ImageTitleContentPrimary: ComponentStory<React.FC<ImageTitleContentProps>>;
