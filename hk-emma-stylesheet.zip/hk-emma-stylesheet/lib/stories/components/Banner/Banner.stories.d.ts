import { ComponentStory } from '@storybook/react';
import Banner from '../../../components/Banner/Banner';
declare const _default: {
    title: string;
    component: typeof Banner;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const BannerPrimary: ComponentStory<typeof Banner>;
