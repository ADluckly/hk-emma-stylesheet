import TransparentButton from '../../../components/TransparentButton/TransparentButton';
import { ComponentStory } from '@storybook/react';
import './TransparentButton.scss';
declare const _default: {
    title: string;
    components: typeof TransparentButton;
};
export default _default;
export declare const TransparentButtonPrimary: ComponentStory<typeof TransparentButton>;
