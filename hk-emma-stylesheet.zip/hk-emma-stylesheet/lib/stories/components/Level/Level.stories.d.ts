import Level from '../../../components/Level/Level';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: typeof Level;
};
export default _default;
export declare const LevelPrimary: ComponentStory<typeof Level>;
