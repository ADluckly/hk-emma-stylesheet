import Dropdown from '../../../components/Dropdown/Dropdown';
import { DateOfBirth } from '../../../index';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: typeof Dropdown;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const DropdownList: ComponentStory<typeof Dropdown>;
export declare const DateofbirthList: ComponentStory<typeof DateOfBirth>;
