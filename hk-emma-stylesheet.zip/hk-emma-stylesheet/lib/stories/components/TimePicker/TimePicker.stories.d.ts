import TimePicker from '../../../components/TimePicker/TimePicker';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
};
export default _default;
export declare const TimePickerPrimary: ComponentStory<typeof TimePicker>;
