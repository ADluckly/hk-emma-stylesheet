import { ComponentStory } from '@storybook/react';
import Step from '../../../components/Step/Step';
declare const _default: {
    title: string;
    component: typeof Step;
};
export default _default;
export declare const StepPrimary: ComponentStory<typeof Step>;
