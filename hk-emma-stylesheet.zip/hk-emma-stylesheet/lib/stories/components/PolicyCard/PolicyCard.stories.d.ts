import { ComponentStory } from '@storybook/react';
import PolicyCard from '../../../components/PolicyCard/PolicyCard';
import GoalCard from '../../../components/GoalCard/GoalCard';
declare const _default: {
    title: string;
    component: () => JSX.Element;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const PolicyCardPrimary: ComponentStory<typeof PolicyCard>;
export declare const GoalCardPrimary: ComponentStory<typeof GoalCard>;
