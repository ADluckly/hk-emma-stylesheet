import Collapsible from '../../../components/Collapsible/Collapsible';
import CollapsibleTwo from '../../../components/Collapsible/CollapsibleTwo';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: typeof Collapsible;
};
export default _default;
export declare const CollapsiblePrimary: ComponentStory<typeof Collapsible>;
export declare const CollapsibleTwoPrimary: ComponentStory<typeof CollapsibleTwo>;
