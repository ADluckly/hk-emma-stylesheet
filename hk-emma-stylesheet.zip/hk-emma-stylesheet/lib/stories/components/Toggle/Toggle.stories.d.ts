import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import Toggle, { ToggleProps } from '../../../components/Toggle/Toggle';
declare const _default: ComponentMeta<React.NamedExoticComponent<ToggleProps>>;
export default _default;
declare const ToggleTemplate: ComponentStory<typeof Toggle>;
export declare const Default: typeof ToggleTemplate;
