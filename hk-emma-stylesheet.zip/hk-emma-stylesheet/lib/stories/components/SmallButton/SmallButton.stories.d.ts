import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import SmallButton from '../../../components/SmallButton/SmallButton';
declare const _default: ComponentMeta<React.ForwardRefExoticComponent<import("../../../components/SmallButton/SmallButton").SmallButtonProps & React.RefAttributes<HTMLButtonElement>>>;
export default _default;
export declare const Default: ComponentStory<typeof SmallButton>;
