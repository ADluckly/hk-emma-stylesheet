declare const HKIDNumberContainer: () => JSX.Element;
export default HKIDNumberContainer;
