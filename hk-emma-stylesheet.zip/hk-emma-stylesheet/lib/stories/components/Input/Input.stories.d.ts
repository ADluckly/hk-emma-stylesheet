import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: () => JSX.Element;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const State: ComponentStory<() => JSX.Element>;
export declare const Type: ComponentStory<() => JSX.Element>;
export declare const PasswordInput: ComponentStory<() => JSX.Element>;
export declare const CountryTelephoneNumberInput: ComponentStory<() => JSX.Element>;
export declare const HKIDNumberInput: ComponentStory<() => JSX.Element>;
export declare const ContextualHelpInput: ComponentStory<() => JSX.Element>;
export declare const SearchInputComponent: ComponentStory<() => JSX.Element>;
