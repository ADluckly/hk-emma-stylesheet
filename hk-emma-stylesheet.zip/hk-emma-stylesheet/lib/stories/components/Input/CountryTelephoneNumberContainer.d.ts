declare const CountryTelephoneNumberContainer: () => JSX.Element;
export default CountryTelephoneNumberContainer;
