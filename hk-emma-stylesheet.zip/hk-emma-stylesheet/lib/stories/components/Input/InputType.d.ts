declare const InputType: () => JSX.Element;
export default InputType;
