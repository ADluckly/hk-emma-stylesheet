import { ComponentStory } from '@storybook/react';
import { Modal } from '../../../components/Modal';
import { Dialog } from '../../../components/Dialog';
declare const _default: {
    title: string;
    component: typeof Modal;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const DialogPrimary: ComponentStory<typeof Dialog>;
export declare const SimpleModal: ComponentStory<typeof Modal>;
export declare const PageModal: ComponentStory<typeof Modal>;
export declare const DetailModal: ComponentStory<typeof Modal>;
