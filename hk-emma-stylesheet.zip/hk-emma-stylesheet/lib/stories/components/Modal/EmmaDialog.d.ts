import './EmmaDialog.scss';
declare const EmmaDialog: () => JSX.Element;
export default EmmaDialog;
