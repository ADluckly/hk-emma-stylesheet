declare const EmmaFullPageModal: () => JSX.Element;
export default EmmaFullPageModal;
