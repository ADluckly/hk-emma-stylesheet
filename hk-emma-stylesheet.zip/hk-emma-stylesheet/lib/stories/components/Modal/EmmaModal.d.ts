declare const EmmaModal: () => JSX.Element;
export default EmmaModal;
