import './EmmaModal.scss';
declare const EmmaModalContainer: () => JSX.Element;
export default EmmaModalContainer;
