import { ListCell, ListTable } from '../../../components/ListTable';
import { ComponentStory } from '@storybook/react';
declare const _default: {
    title: string;
    component: typeof ListTable;
};
export default _default;
export declare const ListCellPrimary: ComponentStory<typeof ListCell>;
export declare const ListTablePrimary: ComponentStory<typeof ListTable>;
