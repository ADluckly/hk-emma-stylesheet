import ProgressBar from '../../../components/Progress/ProgressBar';
import { ComponentStory } from '@storybook/react';
import ProgressCircle from '../../../components/Progress/ProgressCircle';
import ProgressBigBar from '../../../components/Progress/ProgressBigBar';
import ProgressStep from '../../../components/Progress/ProgressStep';
declare const _default: {
    title: string;
    component: typeof ProgressBar;
};
export default _default;
export declare const ProgressBarPrimary: ComponentStory<typeof ProgressBar>;
export declare const ProgressBigBarPrimary: ComponentStory<typeof ProgressBigBar>;
export declare const ProgressCirclePrimary: ComponentStory<typeof ProgressCircle>;
export declare const ProgressStepPrimary: ComponentStory<typeof ProgressStep>;
