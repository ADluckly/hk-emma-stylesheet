import { ComponentStory } from '@storybook/react';
import GeneralErrorPage from '../../../components/Page/GeneralErrorPage';
declare const _default: {
    title: string;
    component: typeof GeneralErrorPage;
};
export default _default;
export declare const GeneralErrorPagePrimary: ComponentStory<typeof GeneralErrorPage>;
