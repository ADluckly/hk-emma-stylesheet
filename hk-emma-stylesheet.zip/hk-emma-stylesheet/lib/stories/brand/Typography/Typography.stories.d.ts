import { ComponentStory } from '@storybook/react';
import './Typography.scss';
declare const _default: {
    title: string;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const Typography: ComponentStory<() => JSX.Element>;
