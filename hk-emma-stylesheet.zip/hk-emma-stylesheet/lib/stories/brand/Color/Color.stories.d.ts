import { ComponentStory } from '@storybook/react';
import './Color.scss';
declare const _default: {
    title: string;
    component: () => JSX.Element;
    parameters: {
        zeplinLink: string;
    };
};
export default _default;
export declare const Color: ComponentStory<() => JSX.Element>;
