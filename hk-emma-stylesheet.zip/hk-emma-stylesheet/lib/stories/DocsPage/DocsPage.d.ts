import React from 'react';
declare type DocsPageProps = {
    title?: string;
    subTitle?: string;
    description?: string;
    templateName?: string;
};
export default class DocsPage extends React.Component<DocsPageProps> {
    constructor(props: DocsPageProps);
    render(): JSX.Element;
}
export {};
