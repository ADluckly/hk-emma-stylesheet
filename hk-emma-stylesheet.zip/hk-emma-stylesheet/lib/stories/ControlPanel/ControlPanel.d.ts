import { Component, ReactNode } from 'react';
import './ControlPanel.scss';
declare type ControlPanelItemProps = {
    children: ReactNode;
};
export default class ControlPanel extends Component<ControlPanelItemProps> {
    render(): JSX.Element;
}
export {};
