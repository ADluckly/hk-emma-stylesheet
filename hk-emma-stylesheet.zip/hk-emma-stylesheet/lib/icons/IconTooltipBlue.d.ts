import { PureComponent } from 'react';
export default class IconTooltipBlue extends PureComponent {
    render(): JSX.Element;
}
