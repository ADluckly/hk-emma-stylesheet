import { PureComponent } from 'react';
export default class IconUpTriangleBlue extends PureComponent {
    render(): JSX.Element;
}
