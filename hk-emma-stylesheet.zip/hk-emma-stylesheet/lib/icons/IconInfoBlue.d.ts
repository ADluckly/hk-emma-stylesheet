import { PureComponent } from 'react';
export default class IconInfoBlue extends PureComponent {
    render(): JSX.Element;
}
