import { PureComponent } from 'react';
export default class IconClockDark extends PureComponent {
    render(): JSX.Element;
}
