import { PureComponent } from 'react';
export default class IconArrowLeft extends PureComponent {
    render(): JSX.Element;
}
