import { PureComponent } from 'react';
export default class IconEyeBlue extends PureComponent {
    render(): JSX.Element;
}
