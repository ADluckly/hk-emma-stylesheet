import { PureComponent } from 'react';
export default class IconEyeCloseBlue extends PureComponent {
    render(): JSX.Element;
}
