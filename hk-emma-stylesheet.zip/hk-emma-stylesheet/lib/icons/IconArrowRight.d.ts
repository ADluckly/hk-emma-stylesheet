import { PureComponent } from 'react';
export default class IconArrowRight extends PureComponent {
    render(): JSX.Element;
}
