import { PureComponent } from 'react';
declare type IconUpArrowBlueProps = {
    normalIconSize: string;
};
export default class IconUpArrowBlue extends PureComponent<IconUpArrowBlueProps> {
    static defaultProps: {
        normalIconSize: string;
    };
    render(): JSX.Element;
}
export {};
