import React, { Component } from 'react';
export declare type GoalCardProps = {
    title: string;
    desc: string;
    iconPath: string;
    children?: React.ReactNode;
    isBoxShadow?: boolean;
};
declare class GoalCard extends Component<GoalCardProps> {
    static defaultProps: {
        isBoxShadow: boolean;
    };
    constructor(props: GoalCardProps);
    render(): JSX.Element;
}
export default GoalCard;
