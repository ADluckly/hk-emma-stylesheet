import GoalCard from './GoalCard';
export default GoalCard;
