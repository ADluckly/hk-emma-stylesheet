import { Component } from 'react';
import { DropdownOption } from '../Dropdown/Dropdown';
export declare type DateOfBirthProps = {
    dayList?: DropdownOption[];
    monthList?: DropdownOption[];
    yearList?: DropdownOption[];
    dayValue?: string;
    monthValue?: string;
    yearValue?: string;
    dayTitle?: string;
    monthTitle?: string;
    yearTitle?: string;
    isValidateInitValue?: boolean;
    onChange?: (dayValue?: string, monthValue?: string, yearValue?: string, errorMessage?: string | boolean) => void;
    onHandleValidation?: (dayValue?: string, monthValue?: string, yearValue?: string) => string | boolean;
};
declare type DateOfBirthState = {
    dayValue?: string;
    monthValue?: string;
    yearValue?: string;
    isShowDayOptionList: boolean;
    isShowMonthOptionList: boolean;
    isShowYearOptionList: boolean;
    errorMessage?: string | boolean;
};
declare class DateOfBirth extends Component<DateOfBirthProps, DateOfBirthState> {
    static defaultProps: {
        isValidateInitValue: boolean;
    };
    constructor(props: DateOfBirthProps);
    componentWillReceiveProps(nextProps: DateOfBirthProps): void;
    componentDidMount(): void;
    setOpenOption(type: string, val: string | boolean): void;
    onChangeValue(): void;
    onClickAction(type: string, val: string): void;
    validateValue(): string | boolean | undefined;
    render(): JSX.Element;
}
export default DateOfBirth;
