import React, { Component } from 'react';
export declare type CollapsibleTwoProps = {
    title?: React.ReactNode;
    children?: React.ReactNode;
    isShowDot?: boolean;
    dotColor?: string;
    isExpand?: boolean;
    dataGaTitleText?: string;
    collapsibleClassName?: string;
    onChangeToggle?: (isExpand: boolean) => void;
};
declare class CollapsibleTwo extends Component<CollapsibleTwoProps> {
    static defaultProps: {
        isShowDot: boolean;
        dotColor: string;
        isExpand: boolean;
        dataGaTitleText: string;
        collapsibleClassName: string;
    };
    constructor(props: CollapsibleTwoProps);
    render(): JSX.Element;
}
export default CollapsibleTwo;
