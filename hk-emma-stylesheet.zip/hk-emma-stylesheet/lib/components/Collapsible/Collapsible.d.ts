import React, { Component } from 'react';
export declare type CollapsibleProps = {
    type?: string;
    title?: React.ReactNode;
    isExpand?: boolean;
    showText?: string;
    hideText?: string;
    dataGaTitleText?: string;
    normalIconSize?: string;
    collapsibleClassName?: string;
    onChangeToggle?: (isExpand: boolean) => void;
};
declare class Collapsible extends Component<CollapsibleProps> {
    static defaultProps: {
        type: string;
        title: string;
        isExpand: boolean;
        showText: string;
        hideText: string;
        dataGaTitleText: string;
        normalIconSize: string;
        collapsibleClassName: string;
    };
    content: EventTarget | any;
    contentText: EventTarget | any;
    state: {
        isExpand: boolean;
    };
    constructor(props: CollapsibleProps);
    removeTransitionClass(): void;
    componentDidMount(): void;
    toggle(): void;
    render(): JSX.Element;
}
export default Collapsible;
