import * as React from 'react';
export declare type ToggleProps = {
    onChange?: (isRadio: boolean) => void;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'>;
declare class Toggle extends React.Component<ToggleProps> {
    uuid: string;
    onToggleChange: () => void;
    render(): JSX.Element;
}
declare const _default: React.MemoExoticComponent<typeof Toggle>;
export default _default;
