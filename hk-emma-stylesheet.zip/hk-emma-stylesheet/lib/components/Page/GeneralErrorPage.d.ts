import React, { Component } from 'react';
export declare type GeneralErrorPageProps = {
    title?: string;
    descChildren?: React.ReactNode;
    buttonChildren?: React.ReactNode;
};
declare class GeneralErrorPage extends Component<GeneralErrorPageProps> {
    constructor(props: GeneralErrorPageProps);
    render(): JSX.Element;
}
export default GeneralErrorPage;
