import { Component } from 'react';
declare type BannerProps = {
    bannerIcon?: string;
    title?: string;
    content?: string;
    buttonText?: string;
    onClick?: () => void;
};
declare class Banner extends Component<BannerProps> {
    onClickBanner: () => void;
    render(): JSX.Element;
}
export default Banner;
