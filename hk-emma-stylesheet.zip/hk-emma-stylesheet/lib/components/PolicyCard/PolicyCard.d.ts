import { Component } from 'react';
export declare type PolicyCardProps = {
    planName: string;
    policyNumber: string;
    certificateNumber: string;
    isSelected: boolean;
};
declare class PolicyCard extends Component<PolicyCardProps> {
    static defaultProps: {
        planName: string;
        policyNumber: string;
        certificateNumber: string;
        isSelected: boolean;
    };
    constructor(props: PolicyCardProps);
    render(): JSX.Element;
}
export default PolicyCard;
