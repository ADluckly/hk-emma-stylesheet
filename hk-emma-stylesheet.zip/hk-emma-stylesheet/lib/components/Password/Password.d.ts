import React from 'react';
export declare type PasswordProps = {
    label?: string;
    placeholder?: string;
    isReadOnly?: boolean;
    isDisabled?: boolean;
    isContentDisplayable?: boolean;
    helpText?: React.ReactNode;
    helpTextClass?: any;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onFocus?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    childrenClassName?: string;
    inputClassName?: string;
};
declare type PasswordState = {
    showPassword: boolean;
    inputOnFocus: boolean;
    passwordValue: string;
};
declare class Password extends React.Component<PasswordProps, PasswordState> {
    static defaultProps: {
        label: string;
        placeholder: string;
        isReadOnly: boolean;
        isDisabled: boolean;
        isContentDisplayable: boolean;
        helpText: string;
        helpTextClass: string;
        onChange: () => void;
    };
    constructor(props: PasswordProps);
    passwordOnShow(): void;
    passwordOnChange(e: React.ChangeEvent<HTMLInputElement>): void;
    passwordOnFocus(e: React.ChangeEvent<HTMLInputElement>): void;
    passwordOnBlur(e: React.ChangeEvent<HTMLInputElement>): void;
    render(): JSX.Element;
}
export default Password;
