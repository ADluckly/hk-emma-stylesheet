import { Component } from 'react';
export declare type StoreTimeListItem = {
    key: string;
    label: string;
    value: string;
    disabled: boolean;
    isClosed: boolean;
};
export declare type TimePickerProps = {
    storeTimesList: StoreTimeListItem[];
    selectedTime: string | number;
    onChange: () => void;
    description: string;
    timePickerClassName: string;
};
declare class TimePicker extends Component<TimePickerProps> {
    static defaultProps: {
        storeTimesList: {
            key: string;
            label: string;
            value: string;
            disabled: boolean;
        }[];
        selectedTime: string;
        description: string;
        timePickerClassName: string;
    };
    componentWillReceiveProps(nextProps: TimePickerProps): void;
    render(): JSX.Element;
}
export default TimePicker;
