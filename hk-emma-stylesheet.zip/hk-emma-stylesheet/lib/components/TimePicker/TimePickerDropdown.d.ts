import React, { PureComponent } from 'react';
export declare type TimePickerDropdownProps = {
    onChange: (value: string) => void;
    timePickerClassName: string;
    children: React.ReactNode;
    input: any;
    value: string | number;
    disabled: boolean;
    icon: any;
};
declare class TimePickerDropdown extends PureComponent<TimePickerDropdownProps> {
    static defaultProps: {
        onChange: () => void;
        timePickerClassName: string;
        children: JSX.Element;
        input: {};
        value: string;
        disabled: boolean;
        icon: string;
    };
    constructor(props: TimePickerDropdownProps);
    onChange(e: React.ChangeEvent<HTMLSelectElement> | any): void;
    render(): JSX.Element;
}
export default TimePickerDropdown;
