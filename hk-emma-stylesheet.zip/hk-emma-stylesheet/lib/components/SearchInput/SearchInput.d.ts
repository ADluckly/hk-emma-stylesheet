import React from 'react';
import PropTypes from 'prop-types';
export declare type SearchInputProps = {
    id?: string;
    label?: string;
    placeholder?: string;
    value?: string;
    isReadOnly?: boolean;
    isDisabled?: boolean;
    isShowError?: boolean;
    errorMsg?: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onFocus?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onKeyDown?: (e: any) => void;
    childrenClassName?: string;
    inputClassName?: string;
};
declare type SearchInputState = {
    showSearchInput: boolean;
    inputOnFocus: boolean;
    searchInputValue: string;
    isShowError: boolean;
};
declare class SearchInput extends React.Component<SearchInputProps, SearchInputState> {
    static propTypes: {
        label: PropTypes.Requireable<string>;
        placeholder: PropTypes.Requireable<string>;
        value: PropTypes.Requireable<string>;
        isReadOnly: PropTypes.Requireable<boolean>;
        isDisabled: PropTypes.Requireable<boolean>;
        onChange: PropTypes.Requireable<(...args: any[]) => any>;
        onBlur: PropTypes.Requireable<(...args: any[]) => any>;
        onFocus: PropTypes.Requireable<(...args: any[]) => any>;
        childrenClassName: PropTypes.Requireable<string>;
        inputClassName: PropTypes.Requireable<string>;
    };
    static defaultProps: {
        placeholder: string;
        isReadOnly: boolean;
        isDisabled: boolean;
        isShowError: boolean;
        onChange: () => void;
    };
    constructor(props: SearchInputProps);
    componentWillReceiveProps(nextProps: any): void;
    searchInputOnChange(e: React.ChangeEvent<HTMLInputElement>): void;
    searchInputOnFocus(e: React.ChangeEvent<HTMLInputElement>): void;
    searchInputOnBlur(e: React.ChangeEvent<HTMLInputElement>): void;
    searchInputOnKeyDown: (e: any) => void;
    render(): JSX.Element;
}
export default SearchInput;
