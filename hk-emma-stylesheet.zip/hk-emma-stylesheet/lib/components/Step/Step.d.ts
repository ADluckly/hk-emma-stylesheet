import React from 'react';
export declare type StepListItem = {
    item: any;
    sub_item: any;
    selected?: boolean;
};
export declare type StepContext = {
    title: string;
    list: StepListItem[];
};
export declare type StepProps = {
    itemClassName?: string;
    context?: StepContext | string;
};
declare class Step extends React.Component<StepProps> {
    static defaultProps: {
        itemClassName: string;
        context: {
            title: string;
            list: {
                item: string;
                sub_item: string;
            }[];
        };
    };
    constructor(props: StepProps);
    render(): JSX.Element;
}
export default Step;
