import React, { Component } from 'react';
export declare type DialogHeaderProps = {
    children?: React.ReactNode;
};
declare class DialogHeader extends Component<DialogHeaderProps> {
    static defaultProps: {
        children: string;
    };
    render(): JSX.Element;
}
export default DialogHeader;
