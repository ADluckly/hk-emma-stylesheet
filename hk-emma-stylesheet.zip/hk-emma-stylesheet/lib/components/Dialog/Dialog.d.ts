import React, { Component } from 'react';
export declare type ModalProps = {
    show: boolean;
    children?: React.ReactNode;
    onHide?: (event: React.MouseEvent<HTMLDivElement>) => void;
    type: string;
    zIndex: number;
};
declare class Dialog extends Component<ModalProps> {
    static defaultProps: {
        show: boolean;
        type: string;
        zIndex: number;
    };
    render(): JSX.Element;
}
export default Dialog;
