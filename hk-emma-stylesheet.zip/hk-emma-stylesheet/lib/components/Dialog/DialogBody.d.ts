import React, { Component } from 'react';
export declare type DialogBodyProps = {
    children?: React.ReactNode;
};
declare class DialogBody extends Component<DialogBodyProps> {
    static defaultProps: {
        children: string;
    };
    render(): JSX.Element;
}
export default DialogBody;
