import React, { Component } from 'react';
export declare type DialogFooterProps = {
    children?: React.ReactNode;
};
declare class DialogFooter extends Component<DialogFooterProps> {
    static defaultProps: {
        children: null;
    };
    render(): JSX.Element;
}
export default DialogFooter;
