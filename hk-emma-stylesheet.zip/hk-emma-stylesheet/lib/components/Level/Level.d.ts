import React, { Component } from 'react';
declare type LevelProps = {
    list: string[];
    level: number;
    levelWidth: string;
    levelHeight: string;
    levelLowText: string;
    levelHeightText: string;
    margin: number;
    icon: React.ReactNode;
    curLevelClass: string;
};
export default class Level extends Component<LevelProps> {
    static defaultProps: {
        list: string[];
        level: number;
        levelWidth: string;
        levelHeight: string;
        levelLowText: string;
        levelHeightText: string;
        margin: number;
        icon: JSX.Element;
        curLevelClass: string;
    };
    render(): JSX.Element;
}
export {};
