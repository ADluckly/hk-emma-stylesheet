import { Component } from 'react';
declare type CountryOption = {
    optionVal: string;
    optionTitle: string;
};
export declare type CountryTelephoneNumberProps = {
    countryCode?: string;
    mobileValue?: string;
    isValidateInitValue?: boolean;
    onHandleValidateInitValue?: (value: any) => void;
    onChange?: (value: any) => void;
    onBlur?: (value: any) => void;
    onFocus?: (value: any) => void;
    placeholder?: string;
    dropdownPlaceholder?: string;
    errorMessage?: string;
    countryOption?: CountryOption[];
    hideDropdown?: boolean;
    disabled?: boolean;
    disabledDropdown?: boolean;
    mandatory?: boolean;
};
declare type CountryTelephoneNumberState = {
    countryValue: string;
    isShowCountryOption: boolean;
};
declare class CountryTelephoneNumber extends Component<CountryTelephoneNumberProps, CountryTelephoneNumberState> {
    static defaultProps: {
        countryCode: string;
        placeholder: string;
        dropdownPlaceholder: string;
        errorMessage: string;
        countryOption: {
            optionVal: string;
            optionTitle: string;
        }[];
        isValidateInitValue: boolean;
        hideDropdown: boolean;
        disabled: boolean;
        disabledDropdown: boolean;
        mandatory: boolean;
    };
    constructor(props: CountryTelephoneNumberProps);
    componentWillReceiveProps(nextProps: CountryTelephoneNumberProps): void;
    returnValToProps: (val: any) => any;
    setOpenOption: (val: boolean) => void;
    chooseOption: (val: string) => void;
    onMobileChange: (val: any) => void;
    onMobileBlur: (val: any) => void;
    onMobileFocus: (val: any) => void;
    onHandleCountryChange: (val: any) => void;
    onHandleValidateInitValue: (val: any) => void;
    render(): JSX.Element;
}
export default CountryTelephoneNumber;
