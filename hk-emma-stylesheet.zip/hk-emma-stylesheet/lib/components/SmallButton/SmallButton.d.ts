import * as React from 'react';
export interface SmallButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    varient?: 'default' | 'white' | 'ghost';
    isLoading?: boolean;
    icon?: 'download-left' | 'download-right' | 'email-left' | 'unset';
    disabled?: boolean;
}
declare const SmallButton: React.ForwardRefExoticComponent<SmallButtonProps & React.RefAttributes<HTMLButtonElement>>;
export declare const defaultProps: SmallButtonProps;
export default SmallButton;
