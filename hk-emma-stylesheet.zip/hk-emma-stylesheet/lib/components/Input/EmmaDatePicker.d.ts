import React, { Component } from 'react';
export default class EmmaDatePicker extends Component {
    state: {
        value: string;
        focus: boolean;
    };
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onFocus: (e: React.FocusEvent<HTMLInputElement>) => void;
    render(): JSX.Element;
}
