import React, { Component } from 'react';
export declare type SearchInputFieldProps = {
    placeholder?: string;
    onChange?: (value: string) => void;
    childrenClassName?: string;
};
declare type SearchInputFieldState = {
    placeholder?: string;
    onChange?: (value: string) => void;
    value?: string;
};
declare class SearchInputField extends Component<SearchInputFieldProps, SearchInputFieldState> {
    constructor(props: SearchInputFieldProps);
    getStatusClassName(value?: string): {
        childrenSubClassName: string;
        inputClassName: string;
    };
    handleOnChange(e: React.ChangeEvent<HTMLInputElement>): void;
    deleteText(): void;
    render(): JSX.Element;
}
export default SearchInputField;
