import React, { Component } from 'react';
export declare type TypeaheadProps = {
    placeholder: string;
    onSelect: () => void;
    options: any[];
    type: string;
    label: React.ReactNode;
};
declare class Typeahead extends Component<TypeaheadProps> {
    static defaultProps: {
        placeholder: string;
        type: string;
        label: string;
        options: never[];
    };
    state: {
        value: string;
    };
    constructor(props: TypeaheadProps);
    handleOnChange(e: React.ChangeEvent<HTMLInputElement>): void;
    render(): JSX.Element;
}
export default Typeahead;
