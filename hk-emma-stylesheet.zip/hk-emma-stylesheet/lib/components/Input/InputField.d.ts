import React, { Component } from 'react';
export declare type InputFieldProps = {
    id?: string;
    type?: string;
    value?: string;
    placeholder?: string;
    childrenClassName?: string;
    errorMessage?: string;
    enableCount?: boolean;
    maxLength?: number;
    isValidateInitValue?: boolean;
    labelTitle?: string | React.ReactNode;
    onHandleValidateInitValue?: (value: any) => void;
    isCustomValidation?: boolean;
    onHandleCustomValidation?: (value: any) => InputFieldState;
    mandatory?: boolean;
    countryCode?: string;
    onChange?: (value: any) => void;
    onBlur?: (value: any) => void;
    onFocus?: (value: any) => void;
    onHandleCountryChange?: (value: any) => void;
    disabled?: boolean;
};
declare type InputFieldState = {
    hidePlaceholder?: boolean;
    value?: string;
    characterCount?: number;
    onFocus?: boolean;
    isError?: boolean;
    isCorrect?: boolean;
};
declare class InputField extends Component<InputFieldProps, InputFieldState> {
    static defaultProps: {
        placeholder: string;
        type: string;
        errorMessage: string;
        enableCount: boolean;
        maxLength: number;
        isCustomValidation: boolean;
        mandatory: boolean;
        countryCode: string;
        isValidateInitValue: boolean;
        disabled: boolean;
    };
    constructor(props: InputFieldProps);
    componentDidMount(): void;
    componentWillReceiveProps(nextProps: InputFieldProps): void;
    initValidateData(value: string): void;
    getMobileMaxLength(): number;
    onInputEmail(targeValue: string): {
        value: string;
        isEmpty: boolean;
        isError: boolean;
        isCorrect: boolean;
    };
    onInputText(targetValue: string): InputFieldState;
    onInputFullName(targeValue: string): InputFieldState;
    onInputMobile(targeValue: string): InputFieldState;
    validMobile: (countryCode?: string | undefined, value?: string | undefined) => InputFieldState;
    onInputNumber(targeValue: string): {
        value: string;
        isEmpty: boolean;
        isError: boolean;
        isCorrect: boolean;
    };
    validNumber: (value: string) => {
        value: string;
        isEmpty: boolean;
        isError: boolean;
        isCorrect: boolean;
    };
    onInput(value: string): InputFieldState;
    handleOnChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>): void;
    onFocusInput(e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>): void;
    onBlurInput(e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>): void;
    getStatusClassName(): {
        childrenSubClassName: string;
        inputClassName: string;
        textClassName: string;
    };
    onUpdateCount(targeValue: string): void;
    render(): JSX.Element;
}
export default InputField;
