import { FC } from "react";
declare type Record = {
    name: string;
    content: string;
    searchText?: string | Array<string> | {
        [key: string]: string;
    };
};
declare type Section = {
    title: string;
    records: Array<Record>;
};
declare type EmmaSearchSectionListProps = {
    searchPlaceHolder?: string;
    sections?: Array<Section>;
};
declare const EmmaSearchSectionList: FC<EmmaSearchSectionListProps>;
export default EmmaSearchSectionList;
