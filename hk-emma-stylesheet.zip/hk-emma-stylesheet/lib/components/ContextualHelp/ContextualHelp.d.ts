import React, { Component } from 'react';
declare type ContextualHelpProps = {
    label: string;
    placeholder: string;
    isReadOnly: boolean;
    isDisabled: boolean;
    desc: string;
    tipClassName: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    inputClassName: string;
};
declare type ContextualHelpState = {
    isToolTipShow?: boolean;
};
declare class ContextualHelp extends Component<ContextualHelpProps, ContextualHelpState> {
    static defaultProps: {
        label: string;
        placeholder: string;
        isReadOnly: boolean;
        isDisabled: boolean;
        desc: string;
        tipClassName: string;
        onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    };
    constructor(props: ContextualHelpProps);
    onContentChange(e: React.ChangeEvent<HTMLInputElement>): void;
    onToolTipDisplay(): void;
    render(): JSX.Element;
}
export default ContextualHelp;
