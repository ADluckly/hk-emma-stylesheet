import { Component } from 'react';
declare type ProgressBigBarProps = {
    percentage: number;
    percentageText?: string;
    percentageTextColor?: string;
    scalePercentage?: number;
    scalePercentageText?: string;
    progressBigBarBgColor?: string;
    percentageProgressBigBarBgColor?: string;
    scalePercentageColor?: string;
};
export default class ProgressBigBar extends Component<ProgressBigBarProps> {
    static defaultProps: {
        percentageTextColor: string;
        progressBigBarBgColor: string;
        percentageProgressBigBarBgColor: string;
        scalePercentageColor: string;
    };
    render(): JSX.Element;
}
export {};
