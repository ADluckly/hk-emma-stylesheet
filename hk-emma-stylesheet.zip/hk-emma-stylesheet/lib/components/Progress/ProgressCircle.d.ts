import { Component } from 'react';
declare type ProgressCircleProps = {
    percentage: number;
    text?: string;
    textColor?: string;
    pathColor?: string;
    trailColor?: string;
};
export default class ProgressCircle extends Component<ProgressCircleProps> {
    static defaultProps: {
        textColor: string;
        pathColor: string;
        trailColor: string;
    };
    render(): JSX.Element;
}
export {};
