import React, { Component } from 'react';
declare type stepListOption = {
    title: string | React.ReactNode;
    value: number;
    description?: string | React.ReactNode;
};
declare type ProgressStepProps = {
    current: number;
    stepList: stepListOption[];
    direction?: string;
};
export default class ProgressStep extends Component<ProgressStepProps> {
    static defaultProps: {
        current: number;
        stepList: never[];
        direction: string;
    };
    render(): JSX.Element;
}
export {};
