import { Component } from 'react';
declare type ProgressBarProps = {
    percentage: number;
    rightText?: string;
};
export default class ProgressBar extends Component<ProgressBarProps> {
    render(): JSX.Element;
}
export {};
