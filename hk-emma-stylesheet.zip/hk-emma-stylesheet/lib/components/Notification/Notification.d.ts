import { Component } from 'react';
export declare type NotificationProps = {
    isShowRedDot: boolean;
    title: string;
    content: string;
    category: string;
    hoursClock: string;
    onClick: () => void;
};
declare class Notification extends Component<NotificationProps> {
    constructor(props: NotificationProps);
    onClickBanner: () => void;
    transferText: (text: string, maxlength: number) => string;
    render(): JSX.Element;
}
export default Notification;
