import { FC } from 'react';
declare type EmmaBlockButtonProps = {
    prefix?: JSX.Element;
    suffix?: JSX.Element;
    buttonText: string;
};
declare const EmmaBlockButton: FC<EmmaBlockButtonProps>;
export default EmmaBlockButton;
