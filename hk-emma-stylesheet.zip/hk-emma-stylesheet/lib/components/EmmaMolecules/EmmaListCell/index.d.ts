import React, { FC } from "react";
declare type EmmaListCellProps = {
    title?: React.ReactNode;
    value?: React.ReactNode;
    hasBottomLine?: boolean;
};
declare const EmmaListCell: FC<EmmaListCellProps>;
export default EmmaListCell;
