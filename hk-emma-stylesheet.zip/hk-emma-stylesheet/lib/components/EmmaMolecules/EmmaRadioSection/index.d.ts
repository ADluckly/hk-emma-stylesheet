import { FC } from "react";
declare type RadioSectionType = {
    id: string;
    name: string;
    children?: JSX.Element;
};
declare type EmmaRadioSectionProps = {
    items: Array<RadioSectionType>;
    onChange: (id: string) => void;
    value?: string;
};
declare const EmmaRadioSection: FC<EmmaRadioSectionProps>;
export default EmmaRadioSection;
