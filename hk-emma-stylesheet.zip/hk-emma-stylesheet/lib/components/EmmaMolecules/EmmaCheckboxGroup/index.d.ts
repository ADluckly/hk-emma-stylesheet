import { FC } from "react";
declare type CheckboxSectionType = {
    id: string;
    content: string;
    children?: JSX.Element;
};
declare type EmmaCheckboxGroupProps = {
    items: Array<CheckboxSectionType>;
    onChange: (id: Array<string>) => void;
    values?: Array<string>;
    direction?: 'row' | 'column';
};
declare const EmmaCheckboxGroup: FC<EmmaCheckboxGroupProps>;
export default EmmaCheckboxGroup;
