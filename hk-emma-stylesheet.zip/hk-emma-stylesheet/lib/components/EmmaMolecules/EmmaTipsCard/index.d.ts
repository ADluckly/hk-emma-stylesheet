import { FC } from 'react';
export declare type TextAlignType = 'left' | 'right' | 'center' | 'justify';
export interface TipsCardProps {
    textAlign?: TextAlignType;
    content?: string;
}
declare const EmmaTipsCard: FC<TipsCardProps>;
export default EmmaTipsCard;
