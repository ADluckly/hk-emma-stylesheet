import { FC } from 'react';
export declare type StoreTimeListItem = {
    key: string;
    label: string;
    value: string;
    disabled: boolean;
    isClosed?: boolean;
};
export declare type TimePickerProps = {
    description: string;
    selectedTime: string | number;
    storeTimesList: StoreTimeListItem[];
    timePickerClassName: string;
    onChange: (value: string) => void;
};
declare const EmmaTimePicker: FC<TimePickerProps>;
export default EmmaTimePicker;
