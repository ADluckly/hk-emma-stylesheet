import { FC } from "react";
export interface File {
    dataUrl: string;
    file: any;
}
declare type EmmaUploadCardProps = {
    index: number;
    fileTitle: string;
    fileDesc: string;
    isRequired: boolean;
    maxFileSize: number;
    maxFileCount: number;
    acceptedExt: string;
    imageCompressClient?: any;
    onFileUpdate: (file: File[]) => void;
};
declare const EmmaUploadCard: FC<EmmaUploadCardProps>;
export default EmmaUploadCard;
