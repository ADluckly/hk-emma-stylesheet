import React, { FC } from "react";
declare type EmmaListingProps = {
    title?: React.ReactNode;
    children?: React.ReactNode;
};
declare const EmmaListing: FC<EmmaListingProps>;
export default EmmaListing;
