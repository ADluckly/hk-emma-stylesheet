import React, { FC } from "react";
declare type EmmaStepperVerticalProps = {
    title?: React.ReactNode;
    description?: React.ReactNode;
    status?: 'Wait' | 'Finish' | 'Active';
    icon?: React.ReactNode;
    line?: React.ReactNode;
    type?: 'Default';
    className?: string;
};
declare const EmmaStepperVertical: FC<EmmaStepperVerticalProps>;
export default EmmaStepperVertical;
