import { FC } from "react";
declare type RadioSectionType = {
    id: string;
    content: string;
    children?: JSX.Element;
};
declare type EmmaRadioGroupProps = {
    items: Array<RadioSectionType>;
    onChange: (id: string) => void;
    value?: string;
    direction?: 'row' | 'column';
};
declare const EmmaRadioGroup: FC<EmmaRadioGroupProps>;
export default EmmaRadioGroup;
