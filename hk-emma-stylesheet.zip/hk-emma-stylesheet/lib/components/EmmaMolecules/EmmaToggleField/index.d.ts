import React, { FC } from "react";
declare type EmmaToggleFieldProps = {
    label?: React.ReactNode;
    component?: React.ReactNode;
};
declare const EmmaToggleField: FC<EmmaToggleFieldProps>;
export default EmmaToggleField;
