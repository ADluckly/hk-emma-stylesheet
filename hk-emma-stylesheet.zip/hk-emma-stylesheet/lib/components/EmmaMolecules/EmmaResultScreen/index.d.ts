import React, { FC } from "react";
declare type EmmaResultScreenProps = {
    status?: 'success' | 'info';
    title?: React.ReactNode;
    icon?: React.ReactNode;
    extra?: React.ReactNode;
};
declare const EmmaResultScreen: FC<EmmaResultScreenProps>;
export default EmmaResultScreen;
