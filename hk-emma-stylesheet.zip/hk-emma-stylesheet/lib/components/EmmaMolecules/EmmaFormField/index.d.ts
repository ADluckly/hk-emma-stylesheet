import React, { FC } from "react";
declare type EmmaFormFieldProps = {
    title?: string;
    subtitle?: string;
    compulsory?: boolean;
} & React.HTMLProps<HTMLDivElement>;
declare const EmmaFormField: FC<EmmaFormFieldProps>;
export default EmmaFormField;
