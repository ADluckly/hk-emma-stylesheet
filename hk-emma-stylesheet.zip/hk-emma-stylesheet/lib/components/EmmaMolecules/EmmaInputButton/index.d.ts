import React, { FC } from "react";
declare type EmmaInputButtonProps = {
    placeholder?: string;
    value?: string;
    onClick?: () => void;
    icon?: string;
} & React.HTMLProps<HTMLDivElement>;
declare const EmmaInputButton: FC<EmmaInputButtonProps>;
export default EmmaInputButton;
