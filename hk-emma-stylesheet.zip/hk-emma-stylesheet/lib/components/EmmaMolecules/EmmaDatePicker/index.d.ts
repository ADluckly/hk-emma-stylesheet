import { FC } from 'react';
export declare type DatePickerProps = {
    label?: string;
    placeholder?: string;
};
declare const EmmaDatePicker: FC<DatePickerProps>;
export default EmmaDatePicker;
