import React, { FC } from "react";
declare type EmmaListWithIconProps = {
    icon?: React.ReactNode;
    text?: React.ReactNode;
};
declare const EmmaListWithIcon: FC<EmmaListWithIconProps>;
export default EmmaListWithIcon;
