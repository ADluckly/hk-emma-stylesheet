import React, { Component } from 'react';
export declare type ListCellProps = {
    title: React.ReactNode;
    value: React.ReactNode | number;
    titleClass?: string;
    valueClass?: string;
    cellClass?: string;
    iconClick?: () => void;
    icon?: React.ReactNode;
    isShowIcon?: boolean;
};
declare class ListCell extends Component<ListCellProps> {
    static defaultProps: {
        title: string;
        value: string;
        titleClass: string;
        valueClass: string;
        cellClass: string;
        isShowIcon: boolean;
    };
    constructor(props: ListCellProps);
    render(): JSX.Element;
}
export default ListCell;
