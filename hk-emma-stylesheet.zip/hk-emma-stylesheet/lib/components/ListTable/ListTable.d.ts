import React, { Component } from 'react';
export declare type ListTableProps = {
    children: React.ReactNode;
};
declare class ListTable extends Component<ListTableProps> {
    constructor(props: ListTableProps);
    render(): JSX.Element;
}
export default ListTable;
