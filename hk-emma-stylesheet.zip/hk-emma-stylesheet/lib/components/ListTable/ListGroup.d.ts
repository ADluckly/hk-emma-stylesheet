import { Component } from 'react';
export declare type ListGroupContent = {
    key: string;
    value: string;
};
export declare type ListGroupProps = {
    content?: ListGroupContent[];
    highLightText?: string;
    isFilterByHighLightText?: boolean;
    cssClass?: string;
    onRowClick?: (content: ListGroupContent) => void;
    errorMessage?: string;
    errorDetail?: string;
    isShowArrow?: boolean;
};
declare type ListGroupState = {
    displayContentList?: ListGroupContent[];
};
declare class ListGroup extends Component<ListGroupProps, ListGroupState> {
    static defaultProps: {
        content: never[];
        highLightText: string;
        isFilterByHighLightText: boolean;
        cssClass: string;
        onRowClick: null;
        errorMessage: string;
        errorDetail: string;
        isShowArrow: boolean;
    };
    constructor(props: ListGroupProps);
    componentDidUpdate(prevProps: ListGroupProps): void;
    contentFilter: () => ListGroupContent[] | undefined;
    render(): JSX.Element;
}
export default ListGroup;
