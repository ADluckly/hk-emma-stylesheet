import React from 'react';
declare type Step = {
    label: string;
    status?: 'done' | 'active' | 'pending';
};
declare type StepBannerProps = {
    steps: Step[];
};
declare const StepBanner: React.FC<StepBannerProps>;
export default StepBanner;
