import React, { FC } from "react";
declare type EmmaStepVerticalProps = {
    current: number;
    children?: React.ReactNode;
};
declare const EmmaStepVertical: FC<EmmaStepVerticalProps>;
export default EmmaStepVertical;
