import { FC } from 'react';
interface IconWrapperProps {
}
declare const IconWrapper: FC<IconWrapperProps>;
export default IconWrapper;
