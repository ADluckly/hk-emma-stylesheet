import { FC } from 'react';
declare const IconsList: {
    'clock-dark': JSX.Element;
    document: JSX.Element;
    'eye-blue': JSX.Element;
    'eye-close-blue': JSX.Element;
    'eye-grey': JSX.Element;
    'info-blue': JSX.Element;
    'left-arrow': JSX.Element;
    'right-arrow': JSX.Element;
    'tooltip-blue': JSX.Element;
    'up-arrow-blue': JSX.Element;
    'up-triangle-blue': JSX.Element;
    'loading-snipper': JSX.Element;
    'success-blue': JSX.Element;
};
declare type IconKeys = keyof typeof IconsList;
export interface EmmaIconProps {
    iconKey: IconKeys;
}
declare const EmmaIcon: FC<EmmaIconProps>;
export default EmmaIcon;
