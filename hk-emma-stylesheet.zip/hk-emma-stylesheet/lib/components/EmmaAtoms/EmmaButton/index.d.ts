import { FC, ReactNode } from "react";
declare type EmmaButtonProps = {
    variant?: "primary" | "secondary" | "white";
    outline?: boolean;
    size?: "normal" | "small";
    loading?: boolean;
    icon?: string;
    iconPosition?: "left" | "right";
    disabled?: boolean;
    children?: ReactNode | undefined;
};
declare const EmmaButton: FC<EmmaButtonProps>;
export default EmmaButton;
