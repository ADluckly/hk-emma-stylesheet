import { FC } from "react";
declare type EmmaRadioButtonProps = {
    checked?: boolean;
    onClick?: () => void;
    disabled?: boolean;
    size?: 'normal' | 'big';
};
declare const EmmaRadioButton: FC<EmmaRadioButtonProps>;
export default EmmaRadioButton;
