import { FC, FocusEvent } from "react";
declare type InputFieldState = {
    hidePlaceholder?: boolean;
    value?: string;
    characterCount?: number;
    onFocus?: boolean;
    isError?: boolean;
    isCorrect?: boolean;
};
declare type InputEventData = {
    value: string;
    isEmpty: boolean;
    isError: boolean;
    isCorrect: boolean;
};
declare type EmmaInputProps = {
    id?: string;
    type?: string;
    value?: string;
    placeholder?: string;
    childrenClassName?: string;
    errorMessage?: string;
    enableCount?: boolean;
    maxLength?: number;
    isValidateInitValue?: boolean;
    onHandleValidateInitValue?: (value: any) => void;
    isCustomValidation?: boolean;
    onHandleCustomValidation?: (value: any) => InputFieldState;
    mandatory?: boolean;
    countryCode?: string;
    onChange?: (value: InputEventData) => void;
    onBlur?: (value: InputEventData) => void;
    onFocus?: (event: FocusEvent<HTMLInputElement>) => void;
    onHandleCountryChange?: (value: any) => void;
    disabled?: boolean;
};
declare const EmmaInput: FC<EmmaInputProps>;
export default EmmaInput;
