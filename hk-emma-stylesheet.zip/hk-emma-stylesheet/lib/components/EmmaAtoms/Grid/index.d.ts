import React from 'react';
import './styles.scss';
export declare type Range1To6 = 1 | 2 | 3 | 4 | 5 | 6;
export declare type Range1To12 = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
export declare type FormattedColBreakpointOptions<GridNumbers> = {
    span: GridNumbers;
    order?: GridNumbers;
    offset?: GridNumbers;
};
declare type ColBreakpointOptions<GridNumbers> = true | GridNumbers | FormattedColBreakpointOptions<GridNumbers>;
declare type RowBreakpointOptions = {
    noGutters?: boolean;
};
export declare type RowProps = {
    sm?: RowBreakpointOptions;
    lg?: RowBreakpointOptions;
} & React.HTMLProps<HTMLDivElement>;
export declare type ColProps = {
    sm?: ColBreakpointOptions<Range1To6>;
    lg?: ColBreakpointOptions<Range1To12>;
} & React.HTMLProps<HTMLDivElement>;
export declare const Row: React.FC<RowProps>;
export declare const formatColBreakpointOptions: <T>(o: ColBreakpointOptions<T>, maxCol: T) => FormattedColBreakpointOptions<T>;
export declare const Col: React.FC<ColProps>;
export {};
