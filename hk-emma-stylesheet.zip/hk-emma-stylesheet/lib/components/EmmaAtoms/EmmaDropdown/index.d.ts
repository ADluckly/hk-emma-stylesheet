import React, { Component } from 'react';
export declare type DropdownOption = {
    optionVal: string;
    optionTitle: string | any;
    disabled?: boolean;
};
export declare type DropdownProps = {
    value?: string | any;
    optionList?: DropdownOption[];
    title?: string;
    labelTitle?: string | React.ReactNode;
    onClickAction?: ((value: string) => void) | Function;
    isShowOptionList?: boolean;
    setOption?: ((value: boolean) => void) | Function;
    dropDownClassName?: string;
    onBlurOptions?: ((value: boolean | string) => void) | Function;
    isError?: boolean;
    mandatory?: boolean;
    disabled?: boolean;
    isEnableGa?: boolean;
    dropdownIcon?: React.ReactNode;
};
declare type DropdownState = {
    value: string;
    isClickOpenOption: boolean;
    isMandatoryError: boolean;
    isShowOptionList: boolean;
};
declare class Dropdown extends Component<DropdownProps, DropdownState> {
    static defaultProps: {
        mandatory: boolean;
        disabled: boolean;
    };
    state: {
        value: any;
        isClickOpenOption: boolean;
        isMandatoryError: boolean;
        isShowOptionList: boolean;
    };
    keyUpTitle: string;
    constructor(props: DropdownProps);
    componentWillReceiveProps(nextProps: DropdownProps): void;
    onOpenOptions(): void;
    onCloseOptions(): void;
    onItemClick: (val: string) => void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    handleKeyUp(): (e: any) => void;
    keyUpChooseOption(e: any): void;
    render(): JSX.Element;
}
export default Dropdown;
