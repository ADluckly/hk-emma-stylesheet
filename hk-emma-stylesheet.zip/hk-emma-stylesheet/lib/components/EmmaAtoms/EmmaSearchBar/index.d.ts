import React, { FC } from "react";
declare type EmmaSearchBarProps = {
    id?: string;
    label?: string;
    placeholder?: string;
    value?: string;
    isReadOnly?: boolean;
    isDisabled?: boolean;
    isShowError?: boolean;
    errorMsg?: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onFocus?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    childrenClassName?: string;
};
declare const EmmaSearchBar: FC<EmmaSearchBarProps>;
export default EmmaSearchBar;
