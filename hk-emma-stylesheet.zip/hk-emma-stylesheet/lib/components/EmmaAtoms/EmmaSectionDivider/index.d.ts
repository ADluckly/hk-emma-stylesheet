import { FC } from "react";
declare type EmmaSectionDividerProps = {};
declare const EmmaSectionDivider: FC<EmmaSectionDividerProps>;
export default EmmaSectionDivider;
