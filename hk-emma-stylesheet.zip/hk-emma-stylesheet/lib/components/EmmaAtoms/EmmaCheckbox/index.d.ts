import { FC } from "react";
declare type EmmaCheckboxProps = {
    checked?: boolean;
    onChange?: (checked: boolean) => void;
    disabled?: boolean;
    size?: number;
    content?: string;
};
declare const EmmaCheckbox: FC<EmmaCheckboxProps>;
export default EmmaCheckbox;
