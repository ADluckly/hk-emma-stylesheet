import React from 'react';
export declare type ImageTitleContentProps = {
    title?: React.ReactNode | string;
    content?: React.ReactNode | string;
    image?: React.ReactNode | string;
};
declare const ImageTitleContent: React.FC<ImageTitleContentProps>;
export default ImageTitleContent;
