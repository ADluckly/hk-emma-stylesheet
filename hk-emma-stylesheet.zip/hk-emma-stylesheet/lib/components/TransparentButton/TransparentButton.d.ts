import React, { Component } from 'react';
export declare type TransparentButtonProps = {
    id: string;
    iconPath: string;
    settingDesc: string;
    isShowActiveIcon: boolean;
    onMouse: (isOver: boolean) => void;
    onClick: (e: React.MouseEvent<HTMLDivElement>) => void;
};
declare class TransparentButton extends Component<TransparentButtonProps> {
    render(): JSX.Element;
}
export default TransparentButton;
