import { Component } from 'react';
declare type DonutDataType = {
    label: string;
    data: number;
};
declare type DonutTooltipType = {
    maxWebWidth: string;
    maxMobileWidth: string;
    background: string;
    padding: string;
    color: string;
    fontSize: string;
    fontFamily: string;
    fontWeight: string;
    lineHeight: number;
};
export declare type DonutChartProps = {
    donutData: DonutDataType[];
    hoverBackgroundColor: string[];
    backgroundColor: string[];
    legendDisplay: boolean;
    hoverOffset: number;
    layout: any;
    tooltipExternal: DonutTooltipType;
    unitLabel: string;
    responsive: boolean;
    width: number;
    height: number;
    maintainAspectRatio: boolean;
    cutoutPercentage: number;
    tooltip: string;
};
declare type DonutChartState = {
    tooltip: string;
};
declare class DonutChart extends Component<DonutChartProps, DonutChartState> {
    static defaultProps: {
        hoverBackgroundColor: string[];
        backgroundColor: string[];
        legendDisplay: boolean;
        tooltipExternal: {
            maxWebWidth: string;
            maxMobileWidth: string;
            background: string;
            padding: string;
            color: string;
            fontSize: string;
            fontFamily: string;
            fontWeight: string;
            lineHeight: number;
        };
        hoverOffset: number;
        layout: {
            padding: number;
        };
        unitLabel: string;
        responsive: boolean;
        width: number;
        height: number;
        maintainAspectRatio: boolean;
        cutoutPercentage: number;
    };
    constructor(props: DonutChartProps);
    componentWillReceiveProps(nextProps: DonutChartProps): void;
    componentWillUnmount(): void;
    render(): JSX.Element;
}
export default DonutChart;
