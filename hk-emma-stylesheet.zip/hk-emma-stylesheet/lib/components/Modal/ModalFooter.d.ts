import React, { Component } from 'react';
export declare type ModalFooterProps = {
    children?: React.ReactNode;
    onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
    className?: string;
    wrapperClassName?: string;
};
declare class ModalFooter extends Component<ModalFooterProps> {
    static defaultProps: {
        children: null;
    };
    render(): JSX.Element;
}
export default ModalFooter;
