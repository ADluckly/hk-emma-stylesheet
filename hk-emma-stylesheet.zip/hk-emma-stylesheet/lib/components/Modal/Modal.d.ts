import React, { Component } from 'react';
export declare type ModalProps = {
    show?: boolean;
    children?: React.ReactNode;
    onHide?: (event: React.MouseEvent<HTMLDivElement>) => void;
    type?: string;
    zIndex?: number;
    onClick?: () => void;
    className?: string;
};
export declare type ModalState = {
    show: boolean;
    type: string;
};
declare class Modal extends Component<ModalProps, ModalState> {
    static defaultProps: {
        show: boolean;
        type: string;
    };
    render(): JSX.Element;
}
export default Modal;
