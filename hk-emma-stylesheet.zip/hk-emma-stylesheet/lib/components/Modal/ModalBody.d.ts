import React, { Component } from 'react';
export declare type ModalBodyProps = {
    children?: React.ReactNode;
    onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
    className?: string;
};
declare class ModalBody extends Component<ModalBodyProps> {
    static defaultProps: {
        children: string;
    };
    render(): JSX.Element;
}
export default ModalBody;
