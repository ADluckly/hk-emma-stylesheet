import React, { Component } from 'react';
export declare type ModalHeaderProps = {
    children?: React.ReactNode;
    onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
    className?: string;
};
declare class ModalHeader extends Component<ModalHeaderProps> {
    static defaultProps: {
        children: string;
    };
    render(): JSX.Element;
}
export default ModalHeader;
