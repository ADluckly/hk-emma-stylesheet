import React from 'react';
declare type ConditionalProps = {
    children: React.ReactNode;
    test: boolean;
};
declare const Conditional: {
    ({ test, children }: ConditionalProps): {} | null;
    defaultProps: {
        children: null;
    };
};
export default Conditional;
