import React, { Component } from 'react';
declare type ErrorMessage = {
    errorHKIDEmptyMessage: string;
    errorcheckDigitEmptyMessage: string;
    errorHKIDMessage: string;
    errorcheckDigitMessage: string;
};
declare type HKIDPlaceHolder = {
    hkidPlaceholder: string;
    checkDigitPlaceholder: string;
};
export declare type HKIDNumberProps = {
    hkidValue?: string;
    checkDigitValue?: string;
    isValidateInitValue?: boolean;
    onHandleValidateInitValue?: (value: any) => void;
    errorMessage?: ErrorMessage;
    placeholder?: HKIDPlaceHolder;
    onChange: (value: any) => void;
    onBlur?: () => void;
    onFocus?: () => void;
};
declare type HKIDNumberState = {
    hkidStateValue?: string;
    checkDigitStateValue?: string;
    isHkidError?: boolean;
    isHkidCorrect?: boolean;
    isCheckDigitError?: boolean;
    isCheckDigitCorrect?: boolean;
    errorHKIDMessage?: string;
    errorcheckDigitMessage?: string;
};
declare class HKIDNumber extends Component<HKIDNumberProps, HKIDNumberState> {
    static defaultProps: {
        placeholder: {
            hkidPlaceholder: string;
            checkDigitPlaceholder: string;
        };
        errorMessage: {
            errorHKIDEmptyMessage: string;
            errorcheckDigitEmptyMessage: string;
            errorHKIDMessage: string;
            errorcheckDigitMessage: string;
        };
        isValidateInitValue: boolean;
    };
    constructor(props: HKIDNumberProps);
    componentDidMount(): void;
    componentWillReceiveProps(nextProps: HKIDNumberProps): void;
    initValidateData(hkidValue?: string, checkDigitValue?: string, isHKid?: boolean): void;
    checkHKIDRule: (value?: string | undefined, errorMsg?: string | undefined) => {
        errorMessage: string;
        isError: boolean;
        isCorrect: boolean;
    };
    checkDigitRule: (value?: string | undefined, errorMsg?: string | undefined) => {
        errorMessage: string;
        isError: boolean;
        isCorrect: boolean;
    };
    checkValidation: (hkid?: string | undefined, digit?: string | undefined, isHkid?: boolean | undefined) => {
        hkidValue: string | undefined;
        checkDigitValue: string | undefined;
        isCorrect: boolean | undefined;
    };
    onInputHKID: (e: React.FocusEvent<HTMLInputElement> | React.ChangeEvent<HTMLInputElement>) => {
        hkidValue: string | undefined;
        checkDigitValue: string | undefined;
        isCorrect: boolean | undefined;
    };
    onHKIDChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onHKIDBlur: (e: React.FocusEvent<HTMLInputElement>) => void;
    onHKIDFocus: (e: React.FocusEvent<HTMLInputElement>) => void;
    onInputCheckDigit: (e: React.FocusEvent<HTMLInputElement> | React.ChangeEvent<HTMLInputElement>) => {
        hkidValue: string | undefined;
        checkDigitValue: string | undefined;
        isCorrect: boolean | undefined;
    };
    onCheckDigitChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onCheckDigitBlur: (e: React.FocusEvent<HTMLInputElement>) => void;
    onCheckDigitFocus: (e: React.FocusEvent<HTMLInputElement>) => void;
    getStatusClassName(isError: boolean, isCorrect: boolean): {
        childrenSubClassName: string;
        inputClassName: string;
    };
    render(): JSX.Element;
}
export default HKIDNumber;
