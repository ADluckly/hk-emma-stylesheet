import React, { Component } from 'react';
export declare type SwitchTabProps = {
    currentTab: string;
    currentTabIndex: number;
};
declare type ArrowTabProps = {
    tabList: string[];
    onSwitchTab: (props: SwitchTabProps) => void;
    value: string;
};
declare type ArrowTabState = {
    currentTabIndex: number;
    currentTab: string;
    leftArrow: boolean;
    rightArrow: boolean;
};
declare class ArrowTab extends Component<ArrowTabProps, ArrowTabState> {
    static defaultProps: {
        tabList: string[];
    };
    scrollRef: Element;
    constructor(props: ArrowTabProps);
    componentDidMount(): void;
    initTab: (tabList: string[], value: string) => void;
    componentWillReceiveProps(nextProps: ArrowTabProps): void;
    onSwitchTab(event: React.MouseEvent<HTMLDivElement>): void;
    onScrollHandle: () => void;
    render(): JSX.Element;
}
export default ArrowTab;
