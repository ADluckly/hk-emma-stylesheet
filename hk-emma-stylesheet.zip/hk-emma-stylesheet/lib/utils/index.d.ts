export declare const isApp: () => boolean;
