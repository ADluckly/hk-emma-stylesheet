export = warning;
export = warning;
declare function warning(): void;
