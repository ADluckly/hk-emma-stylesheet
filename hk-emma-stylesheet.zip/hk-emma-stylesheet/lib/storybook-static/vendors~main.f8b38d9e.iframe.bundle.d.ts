export = g;
export = g;
declare var g: any;
