export = graphql;
export = graphql;
declare function graphql(Prism: any): void;
declare namespace graphql {
    export { displayName, aliases, boolean, booleanish, overloadedBoolean, number, spaceSeparated, commaSeparated, commaOrSpaceSeparated, _default as default, __esModule, parse, stringify };
}
declare var displayName: string;
declare var aliases: any[];
declare var boolean: number;
declare var booleanish: number;
declare var overloadedBoolean: number;
declare var number: number;
declare var spaceSeparated: number;
declare var commaSeparated: number;
declare var commaOrSpaceSeparated: number;
declare var __esModule: boolean;
declare function parse(value: any): string[];
declare function stringify(values: any): any;
