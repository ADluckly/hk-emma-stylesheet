export = warning;
declare function warning(): void;
