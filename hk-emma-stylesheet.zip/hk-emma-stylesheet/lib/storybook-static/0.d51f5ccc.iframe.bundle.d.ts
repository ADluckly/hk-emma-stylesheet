export = yaml;
export = yaml;
declare function yaml(Prism: any): void;
declare namespace yaml {
    export { displayName, aliases, parse, stringify, boolean, booleanish, overloadedBoolean, number, spaceSeparated, commaSeparated, commaOrSpaceSeparated, _default as default, __esModule };
}
declare var displayName: string;
declare var aliases: string[];
declare function parse(value: any): string[];
declare function stringify(values: any, options: any): any;
declare var boolean: number;
declare var booleanish: number;
declare var overloadedBoolean: number;
declare var number: number;
declare var spaceSeparated: number;
declare var commaSeparated: number;
declare var commaOrSpaceSeparated: number;
declare var __esModule: boolean;
