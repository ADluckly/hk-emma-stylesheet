export = rng;
export = rng;
declare var rng: any;
