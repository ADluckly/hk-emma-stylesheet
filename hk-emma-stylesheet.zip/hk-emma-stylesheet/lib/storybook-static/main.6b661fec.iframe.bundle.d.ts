export = webpackEmptyContext;
export = webpackEmptyContext;
declare function webpackEmptyContext(req: any): void;
declare namespace webpackEmptyContext {
    export function keys(): never[];
    export { webpackEmptyContext as resolve };
    export const id: string;
}
