export = convert;
export = convert;
declare var convert: {};
