export = __WEBPACK_AMD_DEFINE_RESULT__;
declare var __WEBPACK_AMD_DEFINE_RESULT__: any;
