declare function _exports(e: any, n: any): Promise<any>;
export = _exports;
