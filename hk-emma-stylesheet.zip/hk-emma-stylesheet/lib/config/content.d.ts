export namespace PrimaryButtonContent {
    const title: string;
    const subTitle: string;
    const description: string;
}
export namespace SecondaryButtonContent {
    const title_1: string;
    export { title_1 as title };
    const subTitle_1: string;
    export { subTitle_1 as subTitle };
    const description_1: string;
    export { description_1 as description };
}
export namespace WhiteButtonContent {
    const title_2: string;
    export { title_2 as title };
    const subTitle_2: string;
    export { subTitle_2 as subTitle };
    const description_2: string;
    export { description_2 as description };
}
export namespace TabContent {
    const title_3: string;
    export { title_3 as title };
    const subTitle_3: string;
    export { subTitle_3 as subTitle };
    const description_3: string;
    export { description_3 as description };
}
export namespace ArrowTabContent {
    const title_4: string;
    export { title_4 as title };
    const subTitle_4: string;
    export { subTitle_4 as subTitle };
    const description_4: string;
    export { description_4 as description };
}
export namespace ListCellContent {
    const title_5: string;
    export { title_5 as title };
    const subTitle_5: string;
    export { subTitle_5 as subTitle };
    const description_5: string;
    export { description_5 as description };
}
export namespace ListTableContent {
    const title_6: string;
    export { title_6 as title };
    const subTitle_6: string;
    export { subTitle_6 as subTitle };
    const description_6: string;
    export { description_6 as description };
}
export namespace PrimaryGhostButtonContent {
    const title_7: string;
    export { title_7 as title };
    const subTitle_7: string;
    export { subTitle_7 as subTitle };
    const description_7: string;
    export { description_7 as description };
}
export namespace SecondaryGhostButtonContent {
    const title_8: string;
    export { title_8 as title };
    const subTitle_8: string;
    export { subTitle_8 as subTitle };
    const description_8: string;
    export { description_8 as description };
}
export namespace StepContent {
    const title_9: string;
    export { title_9 as title };
    const subTitle_9: string;
    export { subTitle_9 as subTitle };
    const description_9: string;
    export { description_9 as description };
}
export namespace CheckboxContent {
    const title_10: string;
    export { title_10 as title };
    const subTitle_10: string;
    export { subTitle_10 as subTitle };
    const description_10: string;
    export { description_10 as description };
}
export namespace ModalContent {
    const title_11: string;
    export { title_11 as title };
    const subTitle_11: string;
    export { subTitle_11 as subTitle };
    const description_11: string;
    export { description_11 as description };
}
export namespace EmmaModalContent {
    const title_12: string;
    export { title_12 as title };
    const subTitle_12: string;
    export { subTitle_12 as subTitle };
    const description_12: string;
    export { description_12 as description };
}
export namespace RadioButtonContent {
    const title_13: string;
    export { title_13 as title };
    const subTitle_13: string;
    export { subTitle_13 as subTitle };
    const description_13: string;
    export { description_13 as description };
}
export namespace DateOfBirthContent {
    const title_14: string;
    export { title_14 as title };
    const subTitle_14: string;
    export { subTitle_14 as subTitle };
    const description_14: string;
    export { description_14 as description };
}
export namespace DropdownListContent {
    const title_15: string;
    export { title_15 as title };
    const subTitle_15: string;
    export { subTitle_15 as subTitle };
    const description_15: string;
    export { description_15 as description };
}
export namespace StateInputContent {
    const title_16: string;
    export { title_16 as title };
    const subTitle_16: string;
    export { subTitle_16 as subTitle };
    const description_16: string;
    export { description_16 as description };
}
export namespace PasswordInputContent {
    const title_17: string;
    export { title_17 as title };
    const subTitle_17: string;
    export { subTitle_17 as subTitle };
    const description_17: string;
    export { description_17 as description };
}
export namespace collapsibleContent {
    const title_18: string;
    export { title_18 as title };
    const subTitle_18: string;
    export { subTitle_18 as subTitle };
    const description_18: string;
    export { description_18 as description };
}
export namespace collapsibleContentTwo {
    const title_19: string;
    export { title_19 as title };
    const subTitle_19: string;
    export { subTitle_19 as subTitle };
    const description_19: string;
    export { description_19 as description };
}
export namespace CountryTelephoneNumberInputContent {
    const title_20: string;
    export { title_20 as title };
    const subTitle_20: string;
    export { subTitle_20 as subTitle };
    const description_20: string;
    export { description_20 as description };
}
export namespace HKIDNumberContent {
    const title_21: string;
    export { title_21 as title };
    const subTitle_21: string;
    export { subTitle_21 as subTitle };
    const description_21: string;
    export { description_21 as description };
}
export namespace ContextualHelpInputContent {
    const title_22: string;
    export { title_22 as title };
    const subTitle_22: string;
    export { subTitle_22 as subTitle };
    const description_22: string;
    export { description_22 as description };
}
export namespace RadioButtonComponentContent {
    const title_23: string;
    export { title_23 as title };
    const subTitle_23: string;
    export { subTitle_23 as subTitle };
    const description_23: string;
    export { description_23 as description };
}
export namespace TypeInputContent {
    const title_24: string;
    export { title_24 as title };
    const subTitle_24: string;
    export { subTitle_24 as subTitle };
    const description_24: string;
    export { description_24 as description };
}
export namespace ContentListingContent {
    const title_25: string;
    export { title_25 as title };
    const subTitle_25: string;
    export { subTitle_25 as subTitle };
    const description_25: string;
    export { description_25 as description };
}
export namespace DialogContent {
    const title_26: string;
    export { title_26 as title };
    const subTitle_26: string;
    export { subTitle_26 as subTitle };
    const description_26: string;
    export { description_26 as description };
}
export namespace DialogUIContent {
    const title_27: string;
    export { title_27 as title };
    const subTitle_27: string;
    export { subTitle_27 as subTitle };
    const description_27: string;
    export { description_27 as description };
}
export namespace EmmaColorDemoContent {
    const title_28: string;
    export { title_28 as title };
    const subTitle_28: string;
    export { subTitle_28 as subTitle };
    const description_28: string;
    export { description_28 as description };
}
export namespace fullPageTnCDemo {
    const title_29: string;
    export { title_29 as title };
    const subTitle_29: string;
    export { subTitle_29 as subTitle };
    const description_29: string;
    export { description_29 as description };
}
export namespace TypographyContent {
    const title_30: string;
    export { title_30 as title };
    const subTitle_30: string;
    export { subTitle_30 as subTitle };
    const description_30: string;
    export { description_30 as description };
}
export namespace TimePickerContent {
    const title_31: string;
    export { title_31 as title };
    const subTitle_31: string;
    export { subTitle_31 as subTitle };
    const description_31: string;
    export { description_31 as description };
}
export namespace TransparentButtonContent {
    const title_32: string;
    export { title_32 as title };
    const subTitle_32: string;
    export { subTitle_32 as subTitle };
    const description_32: string;
    export { description_32 as description };
}
export namespace BannerContent {
    const title_33: string;
    export { title_33 as title };
    const subTitle_33: string;
    export { subTitle_33 as subTitle };
    const description_33: string;
    export { description_33 as description };
}
export namespace NotificationContent {
    const title_34: string;
    export { title_34 as title };
    const subTitle_34: string;
    export { subTitle_34 as subTitle };
    const description_34: string;
    export { description_34 as description };
}
export namespace LevelContent {
    const title_35: string;
    export { title_35 as title };
    const subTitle_35: string;
    export { subTitle_35 as subTitle };
    const description_35: string;
    export { description_35 as description };
}
export namespace DonutChartContent {
    const title_36: string;
    export { title_36 as title };
    const subTitle_36: string;
    export { subTitle_36 as subTitle };
    const description_36: string;
    export { description_36 as description };
}
export namespace PolicyCardContent {
    const title_37: string;
    export { title_37 as title };
    const subTitle_37: string;
    export { subTitle_37 as subTitle };
    const description_37: string;
    export { description_37 as description };
}
export namespace LoadingContent {
    const title_38: string;
    export { title_38 as title };
    const subTitle_38: string;
    export { subTitle_38 as subTitle };
    const description_38: string;
    export { description_38 as description };
}
export namespace ImageTitleContentContent {
    const title_39: string;
    export { title_39 as title };
    export const content: string;
    export const image: string;
}
export namespace progressBarContent {
    const title_40: string;
    export { title_40 as title };
    const subTitle_39: string;
    export { subTitle_39 as subTitle };
    const description_39: string;
    export { description_39 as description };
}
export namespace progressCircleContent {
    const title_41: string;
    export { title_41 as title };
    const subTitle_40: string;
    export { subTitle_40 as subTitle };
    const description_40: string;
    export { description_40 as description };
}
export namespace progressBigBarContent {
    const title_42: string;
    export { title_42 as title };
    const subTitle_41: string;
    export { subTitle_41 as subTitle };
    const description_41: string;
    export { description_41 as description };
}
export namespace ProgressStepContent {
    const title_43: string;
    export { title_43 as title };
    const subTitle_42: string;
    export { subTitle_42 as subTitle };
    const description_42: string;
    export { description_42 as description };
}
export namespace goalCardContent {
    const title_44: string;
    export { title_44 as title };
    const subTitle_43: string;
    export { subTitle_43 as subTitle };
    const description_43: string;
    export { description_43 as description };
}
export namespace generalErrorPageContent {
    const title_45: string;
    export { title_45 as title };
    const subTitle_44: string;
    export { subTitle_44 as subTitle };
    const description_44: string;
    export { description_44 as description };
}
export namespace RadioContent {
    const title_46: string;
    export { title_46 as title };
    const subTitle_45: string;
    export { subTitle_45 as subTitle };
    const description_45: string;
    export { description_45 as description };
}
export namespace SearchInputContent {
    const title_47: string;
    export { title_47 as title };
    const subTitle_46: string;
    export { subTitle_46 as subTitle };
    const description_46: string;
    export { description_46 as description };
}
