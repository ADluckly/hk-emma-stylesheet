/* eslint-disable @typescript-eslint/no-var-requires */
const listSelectors = require('list-selectors');
const fs = require('fs');
const path = require('path');

const EMMA_CLASS_NAME_PREFIX = '.emma-';

// ref: https://www.npmjs.com/package/list-selectors
class ClassSelector {
  constructor(folderPath, cssFileName) {
    this.folderPath = folderPath;
    this.cssFileName = cssFileName;

    this.validation();
  }

  validation() {
    const cssFilePath = path.join(this.folderPath, this.cssFileName);
    fs.stat(cssFilePath, (err) => {
      if (err) {
        throw new Error(`${cssFilePath} not found`);
      }
    });
  }

  async getClasses() {
    const filePath = path.join(this.folderPath, this.cssFileName);
    return new Promise((resolve, reject) => {
      try {
        listSelectors(
          [filePath], // source
          { include: ['classes'] }, // options
          function (selectors) {
            resolve(selectors.classes);
          }
        );
      } catch (err) {
        reject(err);
      }
    });
  }

  saveResult(arr) {
    const classListEmma = arr.filter((ele) => this.startsWithEmma(ele));
    const classListNonEmma = arr.filter((ele) => !this.startsWithEmma(ele));
    this.saveArrayToFile(classListEmma, 'emma-classes.json');
    this.saveArrayToFile(classListNonEmma, 'position-classes.json');
  }
  saveArrayToFile(arr, fileName) {
    const filePath = path.join(this.folderPath, fileName);
    const file = fs.createWriteStream(filePath);
    file.on('error', function (err) {
      /* error handling */
      console.error(err);
    });
    const processedArr = arr.map((ele) => this.postProcessor(ele));
    const arrStr = processedArr.filter((ele) => !!ele);
    // file.write(arrStr.join('\n'));
    file.write(JSON.stringify(arrStr));
    file.end(() => {
      console.log(`Array[${arr.length}] saved into file ${filePath}`);
    });
  }

  startsWithEmma(str) {
    if (str.startsWith(EMMA_CLASS_NAME_PREFIX)) {
      return true;
    }
    return false;
  }
  postProcessor(str) {
    str = this.replaceDot(str);
    return str;
  }
  replaceDot(str) {
    return str.substr(1);
  }
}

(async () => {
  const classSelector = new ClassSelector(
    'src/api/classNameVerifier',
    'classes.css'
  );
  const classList = await classSelector.getClasses();
  console.log(classList);
  classSelector.saveResult(classList);
})();
