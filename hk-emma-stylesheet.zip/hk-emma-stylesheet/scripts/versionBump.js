const fs = require('fs');

fs.readFile('./package.json', (err, data) => {  
  const jsonString = data.toString('utf-8');
  const packageJson = JSON.parse(jsonString);
  const version = packageJson.version;
  const parserWithBuild = /^\d{1,2}\.\d{1,2}\.\d{1,2}-\w+\.\d{1,2}$/;
  const parserWithoutBuild = /^\d{1,2}\.\d{1,2}\.\d{1,2}$/;
  const resultWithBuild = version.match(parserWithBuild);
  let versionString = '';
  if (resultWithBuild) {
    const splits = version.split('-');
    for (let i = 0; i < splits.length - 1; i++) {
      versionString += splits[i];
      if (i < splits.length - 2) {
        versionString += '.';
      }
    }
  } else if (version.match(parserWithoutBuild)) {
    const splits = version.split('.');
    const buildVersion = splits[splits.length - 1];
    let versionNumber = parseInt(buildVersion);
    versionNumber += 1;
    for (let i = 0; i < splits.length - 1; i++) {
      versionString += splits[i];
      versionString += '.';
    }
    versionString += versionNumber;
  } else {
    versionString = version;
  }
  console.log(`Convert from version ${version} to ${versionString}`);
  packageJson.version = versionString;
  let resultJsonString = `${JSON.stringify(packageJson, null, 2)}\n`;
  fs.writeFile('./package.json', resultJsonString, (err) => {
    if (err) {
      console.log(err);
    } else {
      console.log('json file saved success');
    }
  });
});
