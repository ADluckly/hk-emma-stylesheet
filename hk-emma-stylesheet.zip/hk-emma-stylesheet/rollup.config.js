import {exec} from "child_process";
import externals from 'rollup-plugin-node-externals';
// import resolve from '@rollup/plugin-node-resolve';
// import commonjs from '@rollup/plugin-commonjs';
import typescript from 'rollup-plugin-typescript2';
import postcss from 'rollup-plugin-postcss';
import copy from 'rollup-plugin-copy';
import glob from 'glob';
import url from 'postcss-url';

// https://github.com/ezolenko/rollup-plugin-typescript2/issues/201#issuecomment-1014261983
const tscAlias = () => {
  return {
      name: "tsAlias",
      writeBundle: () => {
          return new Promise((resolve, reject) => {
              exec("tsc-alias", function callback(error, stdout, stderr) {
                  if (stderr || error) {
                      reject(stderr || error);
                  } else {
                      resolve(stdout);
                  }
              });
          });
      },
  };
};


export default {
  input: glob.sync('src/web/**/index.t*'),
  output: [
    {
      dir: 'lib',
      format: 'cjs',
      preserveModules: true,
      preserveModulesRoot: 'src/web',
      sourcemap: true,
      entryFileNames: '[name].js',
    },
    {
      dir: 'lib',
      format: 'esm',
      preserveModules: true,
      preserveModulesRoot: 'src/web',
      sourcemap: true,
      entryFileNames: '[name].esm.js',
    },
  ],
  plugins: [
    externals({
      builtins: true,
      deps: true,
      devDeps: true,
    }),
    // Since we external all deps, nodeResolve is not needed
    // resolve(),
    // commonjs(),
    typescript({
      useTsconfigDeclarationDir: true,
      exclude: [
        'src/web/.storybook/**/*',
        'src/web/stories/**/*',
        'src/web/storybook-static/**/*',
        'src/web/config/**/*',
        'src/app/**/*'
      ],
      declarationDir: 'lib'
    }),
    tscAlias(),
    postcss({
      modules: true,
      inject: true,
      plugins: [
        url({
          url: "inline", // enable inline assets using base64 encoding
          maxSize: 10, // maximum file size to inline (in kilobytes)
          fallback: "copy", // fallback method to use if max size is exceeded
        }),
      ],
      use: [
        [
          'sass',
          {
            includePaths: ['../styles']
          }
        ]
      ]
    }),
    copy({
      targets: [{ src: 'styles/**/*', dest: 'lib/styles' }]
    })
  ],
  external: ['tslib']
};
