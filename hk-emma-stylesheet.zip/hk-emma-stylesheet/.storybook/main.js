module.exports = {
  // your Storybook configuration
  refs: (config, { configType }) => {
    if (configType === 'DEVELOPMENT') {
      return {
        web: {
          title: 'Web',
          url: 'http://localhost:6006',
        },
        mobile: {
          title: 'Mobile APP',
          url: 'http://localhost:6007',
        },
      };
    }
    if(process.env.BUILD_VER === 'local') {
      return {
        web: {
          title: 'Web',
          url: `/web`,
        },
        mobile: {
          title: 'Mobile APP',
          url: `/app`,
        },
      };
    }
    return {
      web: {
        title: 'Web',
        url: `${process.env.STORYBOOK_HOST_URL}/web`,
      },
      mobile: {
        title: 'Mobile APP',
        url: `${process.env.STORYBOOK_HOST_URL}/app`,
      },
    };
  },
  "stories": [
    "./**/*.stories.mdx"
  ],
  "addons": [
    "@storybook/addon-links",
    "@storybook/addon-essentials",
    "@storybook/preset-scss"
  ]
};