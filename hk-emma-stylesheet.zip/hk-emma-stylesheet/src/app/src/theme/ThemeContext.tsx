import React, { useContext } from 'react';
import THEMES from './_theme';

type buttonThemeType = {
  background: string;
  border: string;
  text: string;
};
type keyValueType = {
  [key: string]: string;
};
export interface ThemeType {
  color: {
    button: {
      primary: buttonThemeType;
      secondary: buttonThemeType;
      error?: buttonThemeType;
    };
    common?: keyValueType;
  };
  spacing?: {
    [key: string]: number | string;
  };
}

export interface ThemeProviderType {
  theme: ThemeType;
  handleThemeChange?: (newTheme: ThemeType) => void;
}

const defaultState = {
  theme: THEMES,
};
const ThemeContext = React.createContext<ThemeProviderType>(defaultState);

export const useThemeContext = () => useContext(ThemeContext);
export default ThemeContext;
