import React, { useState, FC } from 'react';
import ThemeContext, { ThemeType } from './ThemeContext';
import THEMES from './_theme';

export const ThemeProvider: FC = ({ children }) => {
  const [theme, setTheme] = useState<ThemeType>(THEMES);

  const handleThemeChange = (newTheme: ThemeType) => {
    setTheme({ ...theme, ...newTheme });
  };

  return (
    <ThemeContext.Provider
      value={{
        theme,
        handleThemeChange,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};
