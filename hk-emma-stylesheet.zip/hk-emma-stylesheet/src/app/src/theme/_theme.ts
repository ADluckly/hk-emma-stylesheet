import Color from '../styles/_colors';

// const THEMES = {
//   buttonPrimaryColor: Color.primary.indigo[1],
//   titlePrimaryColor: Color.mineShaft,
// };

export default {
  color: {
    button: {
      primary: {
        background: Color.primary.indigo[1],
        border: Color.primary.indigo[1],
        text: Color.mineShaft,
      },
      secondary: {
        background: Color.primary.indigo[2],
        border: Color.primary.indigo[2],
        text: Color.mineShaft,
      },
    },
    titlePrimary: Color.mineShaft,
    white: Color.white,
  },
};
