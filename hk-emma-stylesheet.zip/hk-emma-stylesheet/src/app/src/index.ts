// styles
import * as styles from './styles';
// Theme
import * as Theme from './theme';
//Atoms
import {
  Button,
  Text,
  Heading,
  Card,
  TouchableOpacity,
} from './components/atoms';
//organisms
import { Banner, LoadingView } from './components/organisms';
import { img } from './utils/img';

export {
  styles,
  Theme,
  Banner,
  LoadingView,
  Card,
  Heading,
  Text,
  Button,
  img,
  TouchableOpacity,
};
