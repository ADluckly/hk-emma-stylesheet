import device from './_device';
import colors from './_colors';
import fontSizes from './_fontSizes';
import fontWeights from './_fontWeights';
import spaces from './_spaces';
import fontFamilies from './_fontFamilies';

export { device, colors, fontSizes, fontWeights, spaces, fontFamilies };
