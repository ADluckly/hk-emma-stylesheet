const FONTSIZE = {
  xlarge: 28,
  large: 24,
  medium: 20,
  default: 16,
  small: 14,
  xsmall: 12,
  xxsmall: 10,
};
export default {
  heading1: FONTSIZE.xlarge,
  heading2: FONTSIZE.large,
  heading3: FONTSIZE.medium,
  heading4: FONTSIZE.default,
  heading5: FONTSIZE.small,
  bodyLarge: FONTSIZE.default,
  bodySmall: FONTSIZE.small,
  remarkLarge: FONTSIZE.xsmall,
  remarkSmall: FONTSIZE.xxsmall,
};
