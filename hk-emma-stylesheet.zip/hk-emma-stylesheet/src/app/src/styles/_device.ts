import { Dimensions } from 'react-native';

// Pre-fetch device dimensions for better performance
const x = Dimensions.get('window').width;
const y = Dimensions.get('window').height;

// Calculate ratio from iPhone breakpoints
const ratioX = x < 375 ? (x < 320 ? 0.75 : 0.875) : 1;
const ratioY = y < 568 ? (y < 480 ? 0.75 : 0.875) : 1;

// Base fond size
const baseUnit = 16;
export const maxFontSizeMultiplier = 1.2;

// We are simulating EM by changing font size according to Ratio
const unit = baseUnit * ratioX;
const em = (value: number) => unit * value;

const device = {
  width: x,
  height: y,
  ratioX,
  ratioY,
  unit: em(1),
  maxFontSizeMultiplier,
};

export default device;
