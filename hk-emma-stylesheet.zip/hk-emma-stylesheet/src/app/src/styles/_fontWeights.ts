export default {
  bold: 'bold',
  normal: 'normal',
};
