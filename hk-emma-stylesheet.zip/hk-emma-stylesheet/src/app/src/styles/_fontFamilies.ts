export default {
  normal: 'Source Sans Pro',
  semiBold: 'Source Sans Pro',
  bold: 'Source Sans Pro',
};
