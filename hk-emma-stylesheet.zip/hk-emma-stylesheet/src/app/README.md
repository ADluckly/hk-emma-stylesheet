# hk-emma-components

React components

## Installation

Make sure you have installed the following fonts:

1. SourceSansPro-Bold
2. SourceSansPro-Regular
3. SourceSansPro-SemiBold
4. SourceSansPro

```sh
npm install hk-emma-components
```

## Usage

```js
import HkEmmaComponents from 'hk-emma-components';

// ...

const result = await HkEmmaComponents.multiply(3, 7);
```

## Contributing

See the [contributing guide](CONTRIBUTING.md) to learn how to contribute to the repository and the development workflow.

## License

MIT
