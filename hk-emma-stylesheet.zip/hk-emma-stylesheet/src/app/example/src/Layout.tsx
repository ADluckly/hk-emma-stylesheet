import React from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';

export type LayoutProps = {
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
};

const Layout: React.FC<LayoutProps> = ({ style, children }) => {
  return <View style={[styles.container, style]}>{children}</View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default Layout;
