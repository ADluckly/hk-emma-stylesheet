export const lorem = {
  short: 'Lorem ipsum dolor',
  medium: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  long: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis ligula eget augue pellentesque efficitur lacinia sed purus. Pellentesque ac.',
  paragraph:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras at imperdiet ipsum. Ut eu ultrices magna. Donec finibus justo quis dolor lacinia, vitae dapibus erat vulputate. Quisque vestibulum purus sit amet dui pulvinar convallis. Ut blandit risus sed ligula consequat, quis tincidunt libero congue. Phasellus accumsan at mauris pellentesque feugiat. Aenean magna nibh, feugiat ut volutpat et, viverra et nibh. Vestibulum sit amet lacus metus. Quisque a magna elit. Donec pretium, neque sit amet iaculis tempus, metus sem placerat nisl, quis facilisis mauris turpis vel est. Etiam posuere iaculis tellus quis fermentum. Ut maximus, lectus ut laoreet lobortis, mi ex dapibus metus, ut lacinia est erat eget leo. Nulla luctus est nec tellus elementum convallis. Praesent facilisis tortor vel elit pellentesque, eget dapibus ex vestibulum. Aenean placerat dui ipsum, varius sodales ligula vehicula eget. Morbi vulputate porta dictum.',
};
