import React from 'react';
import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

import Home from './screens/Home';
import Card from './screens/Card';
import Heading from './screens/Heading';
import Text from './screens/Text';

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={Home} />
        <Drawer.Screen name="Card" component={Card} />
        <Drawer.Screen name="Heading" component={Heading} />
        <Drawer.Screen name="Text" component={Text} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
