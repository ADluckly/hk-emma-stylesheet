import React from 'react';
import ReactDOM from 'react-dom';

import App from './App.web';

ReactDOM.render(<App />, document.getElementById('app'));
