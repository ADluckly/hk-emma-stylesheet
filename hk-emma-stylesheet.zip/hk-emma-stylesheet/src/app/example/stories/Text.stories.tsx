import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Text } from 'hk-emma-components';
import { lorem } from '../src/constants';

export default {
  title: 'Atom/Text',
  component: Text,
} as ComponentMeta<typeof Text>;

const Template: ComponentStory<typeof Text> = args => (
  <Text {...args}>{lorem.medium}</Text>
);
export const Default = Template.bind({});
export const Primary = Template.bind({});
Primary.args = {
  fontColor: 'primary',
};

export const Error = Template.bind({});
Error.args = {
  fontColor: 'error',
};

export const optional = Template.bind({});
optional.args = {
  bold: true,
  underline: true,
  size: 'heading1',
};
