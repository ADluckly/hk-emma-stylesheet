import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Banner, img } from 'hk-emma-components';

export default {
  title: 'organisms/Banner',
  component: Banner,
} as ComponentMeta<typeof Banner>;

const Template: ComponentStory<typeof Banner> = args => <Banner {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  title: 'Welcome to Notifications Inbox',
  description:
    'Enable “PUSH” notifications to stay on top of your account activity.',
  buttonText: 'GO TO SETTING',
  bannerImage: img('banner'),
};
