import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Text, TouchableOpacity } from 'hk-emma-components';
import { lorem } from '../src/constants';

export default {
  title: 'Atom/TouchableOpacity',
  component: TouchableOpacity,
} as ComponentMeta<typeof TouchableOpacity>;

const Template: ComponentStory<typeof TouchableOpacity> = args => (
  <TouchableOpacity {...args}>
    <Text>{lorem.medium}</Text>
  </TouchableOpacity>
);
export const Default = Template.bind({});
Default.args = {};
