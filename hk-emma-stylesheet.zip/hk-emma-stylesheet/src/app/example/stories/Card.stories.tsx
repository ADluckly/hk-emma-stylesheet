import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Card } from 'hk-emma-components';
import { lorem } from '../src/constants';

export default {
  title: 'Atom/Card',
  component: Card,
} as ComponentMeta<typeof Card>;

const Template: ComponentStory<typeof Card> = args => (
  <Card {...args}>{args.children}</Card>
);
export const Primary = Template.bind({});
Primary.args = {
  children: lorem.paragraph,
  style: { minHeight: 200, minWidth: 200 },
};
