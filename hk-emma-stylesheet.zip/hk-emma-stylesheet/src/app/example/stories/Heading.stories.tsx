import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Heading } from 'hk-emma-components';
import { lorem } from '../src/constants';

export default {
  title: 'Atom/Heading',
  component: Heading,
} as ComponentMeta<typeof Heading>;

const Template: ComponentStory<typeof Heading> = args => (
  <Heading {...args}>{args.children}</Heading>
);
export const Primary = Template.bind({});
Primary.args = {
  children: lorem.short,
  // style: { minHeight: 200, minWidth: 200 },
};
export const large = Template.bind({});
large.args = {
  children: lorem.short,
  size: 'heading1',
};
