// import React from 'react';
// import { storiesOf } from '@storybook/react-native';
// import HomeScreen from '../src/screens/Home';

// storiesOf('Components/Home', module).add('Home Primary', () => <HomeScreen />);
