import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Card, LoadingView } from 'hk-emma-components';

export default {
  title: 'organisms/LoadingView',
  component: LoadingView,
} as ComponentMeta<typeof LoadingView>;

const Template: ComponentStory<typeof LoadingView> = args => (
  <Card style={{ width: '100%', height: '100%' }}>
    <LoadingView {...args} />
  </Card>
);

export const Primary = Template.bind({});
Primary.args = {
  style: { flex: 1, zIndex: 0, position: 'relative' },
};
