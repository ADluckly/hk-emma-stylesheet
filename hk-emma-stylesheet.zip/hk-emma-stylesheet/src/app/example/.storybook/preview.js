import React from 'react';
import Layout from '../src/Layout';

export const decorators = [
  Story => (
      <Layout style={{
        minWidth: '300px',
        width: '100%',
        height: '100%',
      }}>
        <Story />
      </Layout>
  ),
];

export const parameters = {
  actions: { argTypesRegex: "^on[A-Z].*" },
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
  docs: {
    source: {
      type: 'dynamic',
      excludeDecorators: true,
    },
  },
}