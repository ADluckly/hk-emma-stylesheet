/* eslint-disable indent */
'use strict';

async function init() {
  try {
    console.log('Class Name Selector Running');
    setDisplayLabel('Getting EMMA Class names');
    const SITE_URL =
      'https://hk-emmastylesheet-emma-dv-h.axa-hk-preprod-hpl-int.berry.eastasia.azure.openpaas.axa-cloud.com';
    const emmaClassNames = await sendRequest(
      `${SITE_URL}/api/static/verifier/emma-classes.json`
    );
    const positionClasses = await sendRequest(
      `${SITE_URL}/api/static/verifier/position-classes.json`
    );
    setDisplayLabel('Checking Styles');
    if (
      !emmaClassNames ||
      !positionClasses ||
      !emmaClassNames.length ||
      !positionClasses.length
    ) {
      setDisplayLabel('Storybook API returned undefined, aborting');
      return;
    }
    for (const className of emmaClassNames) {
      await checkStyle(className, emmaClassNames, positionClasses);
    }
    setDisplayLabel('Result Shown');
  } catch (err) {
    setDisplayLabel(err.message || err);
  }
}

function setDisplayLabel(text) {
  document.getElementById('status-label').innerHTML += '<br/>- ' + text;
}

function sendRequest(url, method = 'GET', headers = {}) {
  return new Promise((resolve, reject) => {
    try {
      var xhr = new XMLHttpRequest();
      xhr.withCredentials = false;

      xhr.addEventListener('readystatechange', function () {
        if (this.readyState === 4) {
          try {
            if (!this.responseText) {
              reject('API returned empty response');
              return;
            }
            resolve(JSON.parse(this.responseText));
          } catch (err) {
            reject(`the response is not a JSON object: ${this.responseText}`);
          }
          return;
        }
      });

      xhr.open(method, url);
      Object.entries(headers).forEach((key, value) => {
        xhr.setRequestHeader(key, value);
      });

      xhr.send();
    } catch (err) {
      // eslint-disable-next-line no-alert
      alert(JSON.stringify(err));
      reject(err);
    }
  });
}

const CORRECT_CLASS_NAME = 'emma-correct-class';
const OVERRIDE_CLASS_NAME = 'emma-override-class';
async function checkStyle(value, emmaClassNames, positionClasses) {
  await executeJs(`
  function runScriptOnFrameWindow(document) {
    CORRECT_CLASS_NAME = '${CORRECT_CLASS_NAME}';
    OVERRIDE_CLASS_NAME = '${OVERRIDE_CLASS_NAME}';
    function removeContentOnContainer() {
      elem = document.getElementById("emma-validate-class");
      if (elem) {
        elem.parentNode.removeChild(elem);
      }
      window.removingContentOnContainer = false;
    }
    function showContentOnContainer(content) {
      removeContentOnContainer();
      document.body.insertAdjacentHTML('afterend', '<div id="emma-validate-class"  style="color:red;position:fixed;right:0;top:40px;text-align:right;padding:1rem;"><pre>'+content+'</pre></div>');
    }
    function showContent(event) {
      const result = getResult(event.target);
      let str = '';
      for (const r of result) {
        str += 'override class: ' + r.overrideClass + '\\n';
        str += r.css.map(v => v.cssText).join('\\n') + '\\n';
      }
      showContentOnContainer(str);
    }
    function removeContentWithDelay() {
      window.removingContentOnContainer = true;
      if (window.removingContentOnContainer) {
        return;
      }
      setTimeout(removeContentOnContainer, 2000);
    }
    function getResult(node) {
      const classList = node.classList;
      if (classList.length <= 1) {
          return [];
      }
      const result = [];
      for (const className of classList) {
          if (className === CORRECT_CLASS_NAME || className === window.targetClassName || className === OVERRIDE_CLASS_NAME) { continue; }
          if (${JSON.stringify([
            ...emmaClassNames,
            ...positionClasses
          ])}.includes(className)) { continue }
          const css = getStyle(className);
          if (!css.length) {
              continue;
          }
          const overrideInfo = {
              overrideClass: className,
              css,
              node,
          };
          result.push(overrideInfo);
      }
      return result;
    }
    function getStyle(className) {
      const result = [];
      const selector = '.' + className;
      for (let j = 0; j < document.styleSheets.length; j++) {
        try {
          r = document.styleSheets[j].rules;
          for (let i = 0; i < r.length; i++ ) {
            const selectorText = r[i].selectorText;
            if (selectorText && selectorText.split(',').indexOf(selector) !== -1) {
              const cssText = r[i].cssText.replace(selectorText, '').trim();
              if (cssText === "{ }") {
                continue;
              }
              result.push({
                selectorText,
                cssText,
              });
            }
          }
        } catch (err) {
          //console.warn(err);
        }
      }
      return result;
    }
    function checkOverride(targetClassName) {
      window.targetClassName = targetClassName;
      if (false) {
        document.querySelectorAll('.'+CORRECT_CLASS_NAME).forEach(e => {
          e.classList.remove(CORRECT_CLASS_NAME);
        });
        document.querySelectorAll('.'+OVERRIDE_CLASS_NAME).forEach(e => {
          e.classList.remove(OVERRIDE_CLASS_NAME);
        });
      }
      // document.querySelector('#emma-validate-class').innerHTML = '<pre></pre>';
      const nodes = document.querySelectorAll('[class*="'+targetClassName+'"]');
      for (const node of nodes) {
          const result = getResult(node);
          if (result.length) {
            // console.log(node); console.log(result);
            node.classList.add(OVERRIDE_CLASS_NAME);
            node.addEventListener('mouseenter', showContent);
            node.addEventListener('mouseleave', removeContentWithDelay);
          } else {
            node.classList.add(CORRECT_CLASS_NAME);
          }
      }
    }
    checkOverride('${value}');
  }

  document.querySelectorAll('iframe').forEach(frame => {
    try {
      if (frame.className.includes('chatbot')) {
        console.log('skipping chatbot');
        return;
      }
      runScriptOnFrameWindow(frame.contentWindow.document);
    } catch (err) {
      console.error(err);
    }
  });
  runScriptOnFrameWindow(window.document);

  `);
}

async function wait(second) {
  return new Promise((resolve, reject) => {
    setTimeout(resolve, second * 1000);
  });
}
async function executeJs(command) {
  return new Promise((resolve, reject) => {
    try {
      if (window.currentTab) {
        executeJsWithTab(window.currentTab, command, resolve);
        return;
      }
      // eslint-disable-next-line no-undef
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        executeJsWithTab(tabs[0], command, resolve);
      });
    } catch (err) {
      resolve('');
    }
  });
}

function executeJsWithTab(tab, command, resolve) {
  // eslint-disable-next-line no-undef
  chrome.tabs.executeScript(tab.id, { code: command }, function (results) {
    try {
      resolve(results[0] || '');
    } catch (err) {
      // if have no results?
    }
    if (!results && results !== false) {
      throw new Error('executeScript return null with command: ' + command);
    }
    resolve(results || '');
  });
}

init();
