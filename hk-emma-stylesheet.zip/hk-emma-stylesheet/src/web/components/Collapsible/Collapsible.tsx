import React, { Component } from 'react';
import IconUpArrowBlue from '../../icons/IconUpArrowBlue';

export type CollapsibleProps = {
  type?: string;
  title?: React.ReactNode;
  isExpand?: boolean;
  showText?: string;
  hideText?: string;
  dataGaTitleText?: string;
  normalIconSize?: string;
  collapsibleClassName?: string;
  onChangeToggle?: (isExpand: boolean) => void;
};

type CollapsibleState = {
  isExpand: boolean;
};

class Collapsible extends Component<CollapsibleProps> {
  static defaultProps = {
    type: 'normal',
    title: '',
    isExpand: false,
    showText: 'SHOW MORE',
    hideText: 'SHOW LESS',
    dataGaTitleText: '',
    normalIconSize: '28',
    collapsibleClassName: '',
  };

  content!: EventTarget | any;
  contentText!: EventTarget | any;

  state = {
    isExpand: false,
  };

  constructor(props: CollapsibleProps) {
    super(props);
    const { isExpand } = this.props;
    this.state = {
      isExpand: !!isExpand,
    };
    // this.content = React.createRef()
    // this.contentText = React.createRef()
    this.toggle = this.toggle.bind(this);
  }

  removeTransitionClass() {
    const { isExpand } = this.state;
    this.content.classList.remove(
      'emma-stylesheet-collapsible_content_transition'
    );
    if (isExpand) {
      this.content.style.height = 'auto';
    }
  }

  componentDidMount() {
    const { isExpand } = this.state;
    if (!isExpand) {
      this.content.style.height = '0px';
    }
    this.content.addEventListener(
      'transitionend',
      this.removeTransitionClass.bind(this)
    );
    this.content.addEventListener(
      'webkitTransitionEnd',
      this.removeTransitionClass.bind(this)
    );
  }

  toggle() {
    const height = this.contentText.offsetHeight;
    this.content.style.height = this.state.isExpand ? `${height}px` : '0px';
    this.content.classList.add(
      'emma-stylesheet-collapsible_content_transition'
    );
    this.setState(
      (prevState: CollapsibleState) => {
        return {
          isExpand: !prevState.isExpand,
        };
      },
      () => {
        const { onChangeToggle } = this.props
        const { isExpand } = this.state;
        const height = this.contentText.offsetHeight;
        this.content.style.height = isExpand ? `${height}px` : '0px';
        onChangeToggle && onChangeToggle(isExpand)
      }
    );
  }

  render() {
    const {
      title,
      children,
      type,
      showText,
      hideText,
      dataGaTitleText,
      normalIconSize,
      collapsibleClassName,
    } = this.props;
    const { isExpand } = this.state;
    return (
      <div>
        {type === 'showMore' ? (
          <div
            className={`emma-stylesheet-collapsible_show_more ${
              isExpand ? '' : 'emma-stylesheet-collapsible_narrow'
            } ${collapsibleClassName}`}
          >
            <div
              className="emma-stylesheet-collapsible_show_more_content"
              ref={(divElement: HTMLDivElement) => {
                this.content = divElement;
              }}
            >
              <div
                className="emma-stylesheet-collapsible_show_more_content_txt"
                ref={(divElement: HTMLDivElement) => {
                  this.contentText = divElement;
                }}
              >
                {React.Children.map(children, (children) => children)}
              </div>
            </div>
            <div
              className="emma-stylesheet-collapsible_show_more_button"
              onClick={this.toggle}
              data-enable-ga="true"
              data-ga-type="button"
            >
              <div className="emma-stylesheet-collapsible_show_more_button_txt">
                {isExpand ? hideText : showText}
              </div>
              <div className="emma-stylesheet-collapsible_show_more_button_icon">
                <IconUpArrowBlue />
              </div>
            </div>
          </div>
        ) : (
          <div
            className={`emma-stylesheet-collapsible ${
              isExpand ? '' : 'emma-stylesheet-collapsible_narrow'
            } ${collapsibleClassName}`}
          >
            <div
              className="emma-stylesheet-collapsible_header"
              onClick={this.toggle}
              data-enable-ga="true"
              data-ga-type="button"
              data-ga-text={dataGaTitleText}
            >
              <div className="emma-stylesheet-collapsible_header_title">
                {title}
              </div>
              <div className="emma-stylesheet-collapsible_header_icon">
                <IconUpArrowBlue normalIconSize={normalIconSize} />
              </div>
            </div>
            <div
              className="emma-stylesheet-collapsible_content"
              ref={(divElement: HTMLDivElement) => {
                this.content = divElement;
              }}
            >
              <div
                className="emma-stylesheet-collapsible_content_txt"
                ref={(divElement: HTMLDivElement) => {
                  this.contentText = divElement;
                }}
              >
                {React.Children.map(children, (children) => children)}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default Collapsible;
