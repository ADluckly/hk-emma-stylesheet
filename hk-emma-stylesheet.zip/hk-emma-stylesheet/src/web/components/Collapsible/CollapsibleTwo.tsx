import React, { Component, FC } from 'react';
import Collapsible from './Collapsible';

export type CollapsibleTwoProps = {
  title?: React.ReactNode;
  children?: React.ReactNode;
  isShowDot?: boolean;
  dotColor?: string;
  isExpand?: boolean;
  dataGaTitleText?: string;
  collapsibleClassName?: string;
  onChangeToggle?: (isExpand: boolean) => void;
};

type CollapsibleTwoTitleProps = {
  title?: React.ReactNode;
  isShowDot?: boolean;
  dotColor?: string;
};

const CollapsibleTwoTitle = ({
  title,
  isShowDot,
  dotColor,
}: CollapsibleTwoTitleProps) => {
  return (
    <div className="emma-stylesheet-collapsible-two_title_wrap">
      {isShowDot && (
        <div
          className="emma-stylesheet-collapsible-two_dot"
          style={{ background: `${dotColor}` }}
        />
      )}
      <div className="emma-stylesheet-collapsible-two_wrap_right">{title}</div>
    </div>
  );
};

class CollapsibleTwo extends Component<CollapsibleTwoProps> {
  static defaultProps = {
    isShowDot: false,
    dotColor: 'rgba(95,95,95,0.9)',
    isExpand: false,
    dataGaTitleText: '',
    collapsibleClassName: '',
  };

  constructor(props: CollapsibleTwoProps) {
    super(props);
    this.state = {};
  }

  render() {
    const { children, isExpand, dataGaTitleText, collapsibleClassName, onChangeToggle } =
      this.props;
    const props = {
      title: <CollapsibleTwoTitle {...this.props} />,
      normalIconSize: '16',
      isExpand,
      dataGaTitleText,
      collapsibleClassName,
      onChangeToggle
    };
    return (
      <div className="emma-stylesheet-collapsible-two">
        <Collapsible {...props}>
          <div className="emma-stylesheet-collapsible-two_content">
            {React.Children.map(children, (child) => child)}
          </div>
        </Collapsible>
      </div>
    );
  }
}

export default CollapsibleTwo;
