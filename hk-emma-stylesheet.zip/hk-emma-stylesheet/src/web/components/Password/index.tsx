import Password from './Password';

export default Password;
