import React from 'react';
import { filterPasswordValue } from '../../common/common';
import IconEyeGrey from '../../icons/IconEyeGrey';
import IconEyeBlue from '../../icons/IconEyeBlue';
import IconEyeCloseBlue from '../../icons/IconEyeCloseBlue';

export type PasswordProps = {
  label?: string;
  placeholder?: string;
  isReadOnly?: boolean;
  isDisabled?: boolean;
  isContentDisplayable?: boolean;
  helpText?: React.ReactNode;
  helpTextClass?: any;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onFocus?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  childrenClassName?: string;
  inputClassName?: string;
};

type PasswordState = {
  showPassword: boolean;
  inputOnFocus: boolean;
  passwordValue: string;
};

class Password extends React.Component<PasswordProps, PasswordState> {
  static defaultProps = {
    label: 'Password',
    placeholder: 'Enter Password',
    isReadOnly: false,
    isDisabled: false,
    isContentDisplayable: true,
    helpText: '',
    helpTextClass: '',
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onChange: () => {},
  };

  constructor(props: PasswordProps) {
    super(props);
    this.state = {
      showPassword: false,
      inputOnFocus: false,
      passwordValue: '',
    };
    this.passwordOnShow = this.passwordOnShow.bind(this);
    this.passwordOnChange = this.passwordOnChange.bind(this);
    this.passwordOnFocus = this.passwordOnFocus.bind(this);
    this.passwordOnBlur = this.passwordOnBlur.bind(this);
  }

  passwordOnShow() {
    const { inputOnFocus } = this.state;
    if (inputOnFocus) {
      this.setState({
        showPassword: !this.state.showPassword,
      });
    }
  }

  passwordOnChange(e: React.ChangeEvent<HTMLInputElement>) {
    let inputOnFocus = false;
    if (e && e.target && e.target.value) {
      inputOnFocus = true;
    }
    const passwordValue = filterPasswordValue(e.target.value)
    e.persist()
    this.setState({
      inputOnFocus: inputOnFocus,
      passwordValue
    },() => {
      this.props.onChange(e);
    });   
  }

  passwordOnFocus(e: React.ChangeEvent<HTMLInputElement>) {
    // this.setState({
    //   inputOnFocus: !this.state.inputOnFocus,
    // });
    const { onFocus } = this.props
    const passwordValue = filterPasswordValue(e.target.value)
    e.persist()
    this.setState({
      passwordValue
    }, () => {
      onFocus && onFocus(e)
    });    
  }

  passwordOnBlur(e: React.ChangeEvent<HTMLInputElement>) {
    // this.setState({
    //   inputOnFocus: !this.state.inputOnFocus,
    // });
    const { onBlur } = this.props
    const passwordValue = filterPasswordValue(e.target.value)
    e.persist()
    this.setState({
      passwordValue
    }, () => {
      onBlur && onBlur(e)
    });    
  }

  render() {
    const {
      label,
      placeholder,
      isReadOnly,
      isDisabled,
      isContentDisplayable,
      helpText,
      helpTextClass,
      childrenClassName,
      inputClassName,
    } = this.props;
    const { showPassword, inputOnFocus, passwordValue } = this.state;

    return (
      <div className={childrenClassName ? childrenClassName : ''}>
        <div className="row emma-stylesheet-password-input-container">
          <input
            id="password"
            className={`emma-stylesheet-password-input__content ${
              inputClassName ? inputClassName : ''
            }`}
            value={passwordValue}
            maxLength={16}
            type={showPassword ? 'text' : 'password'}
            placeholder={placeholder}
            disabled={isDisabled}
            readOnly={isReadOnly}
            onChange={this.passwordOnChange}
            autoComplete="off"
            onFocus={this.passwordOnFocus}
            onBlur={this.passwordOnBlur}
          />
          <div
            className="emma-stylesheet-password-input__icon"
            onClick={this.passwordOnShow}
          >
            {isContentDisplayable &&
              (showPassword ? (
                <IconEyeCloseBlue />
              ) : inputOnFocus ? (
                <IconEyeBlue />
              ) : (
                <IconEyeGrey />
              ))}
          </div>
        </div>
        {!!helpText && (
          <div className="row emma-stylesheet-password-other-container">
            {/* {helpTextChildren} */}
            <span className={helpTextClass}>{helpText}</span>
          </div>
        )}
      </div>
    );
  }
}
export default Password;
