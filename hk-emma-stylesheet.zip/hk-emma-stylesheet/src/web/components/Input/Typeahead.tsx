import React, { Component } from 'react';

export type TypeaheadProps = {
  placeholder: string;
  onSelect: () => void;
  options: any[];
  type: string;
  label: React.ReactNode;
};

class Typeahead extends Component<TypeaheadProps> {
  static defaultProps = {
    placeholder: 'Placeholder Text',
    type: 'text',
    label: 'Label',
    options: [],
  };

  state = {
    value: '',
  };

  constructor(props: TypeaheadProps) {
    super(props);
    this.handleOnChange = this.handleOnChange.bind(this);
  }

  handleOnChange(e: React.ChangeEvent<HTMLInputElement>) {
    const value = e.target.value;
    this.setState({ value });
  }

  render() {
    const { placeholder, label, options, type } = this.props;
    const { value } = this.state;
    return (
      <React.Fragment>
        <div className="typeahead-container">
          <div className="typeahead-label-container">
            <span className="typeahead-label-text">{label}</span>
          </div>
          <input
            {...{ placeholder, type, value }}
            onChange={this.handleOnChange}
          />
        </div>
      </React.Fragment>
    );
  }
}

export default Typeahead;
