import React, { Component } from 'react';

export type SearchInputFieldProps = {
  placeholder?: string;
  onChange?: (value: string) => void;
  childrenClassName?: string;
};

type SearchInputFieldState = {
  placeholder?: string;
  onChange?: (value: string) => void;
  value?: string;
};

class SearchInputField extends Component<
  SearchInputFieldProps,
  SearchInputFieldState
> {
  constructor(props: SearchInputFieldProps) {
    super(props);
    this.state = {
      placeholder: '',
      onChange: undefined,
      value: '',
    };
    this.getStatusClassName = this.getStatusClassName.bind(this);
    this.handleOnChange = this.handleOnChange.bind(this);
    this.deleteText = this.deleteText.bind(this);
  }

  getStatusClassName(value?: string) {
    const childrenClassName = {
      childrenSubClassName: 'emma-stylesheet-input-search',
      inputClassName: 'emma-stylesheet-input-search-field',
    };
    childrenClassName.childrenSubClassName = value
      ? 'emma-stylesheet-input-close'
      : childrenClassName.childrenSubClassName;

    childrenClassName.inputClassName = value
      ? 'emma-stylesheet-input-close-field'
      : childrenClassName.inputClassName;
    return childrenClassName;
  }

  handleOnChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { value } = e.target;
    this.setState({
      value: value,
    });
    this.props.onChange && this.props.onChange(value);
  }

  deleteText() {
    this.setState({
      value: '',
    });
    this.props.onChange && this.props.onChange('');
  }

  render() {
    const { placeholder, childrenClassName } = this.props;
    const { value } = this.state;
    const statusClassName = this.getStatusClassName(value);
    return (
      <div className={childrenClassName ? childrenClassName : ''}>
        <div className="row">
          <div className={`col-12 ${statusClassName.childrenSubClassName}`}>
            <input
              value={value}
              className={`col-12 ${statusClassName.inputClassName}`}
              placeholder={placeholder}
              onChange={this.handleOnChange}
            />
            {value ? (
              <span className="input-close-btn" onClick={this.deleteText} />
            ) : (
              <span />
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default SearchInputField;
