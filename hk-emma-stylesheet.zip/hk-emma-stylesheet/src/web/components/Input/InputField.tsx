import React, { Component } from 'react';
import {
  INPUT_TYPE_TEXT,
  INPUT_TYPE_EMAIL,
  INPUT_TYPE_FULL_NAME,
  INPUT_TYPE_MOBILE,
  INPUT_TYPE_NUMBER,
  TEXTAREA,
} from '../../common/constants';
import {
  getIsValidEmail,
  getFullName,
  getIsValidFullName,
  getIsValidMobileNumber,
  intNumberInMaxLength,
  validateFormatInput,
  getIsValidNumber,
} from '../../common/common';

export type InputFieldProps = {
  id?: string;
  type?: string;
  value?: string;
  placeholder?: string;
  childrenClassName?: string;
  errorMessage?: string;
  enableCount?: boolean;
  maxLength?: number;
  isValidateInitValue?: boolean;
  labelTitle?: string | React.ReactNode;
  onHandleValidateInitValue?: (value: any) => void;
  isCustomValidation?: boolean;
  onHandleCustomValidation?: (value: any) => InputFieldState;
  mandatory?: boolean;
  countryCode?: string;
  onChange?: (value: any) => void;
  onBlur?: (value: any) => void;
  onFocus?: (value: any) => void;
  onHandleCountryChange?: (value: any) => void;
  disabled?: boolean;
  inputProps?: React.HTMLProps<HTMLInputElement>;
};

type InputFieldState = {
  hidePlaceholder?: boolean;
  value?: string;
  characterCount?: number;
  onFocus?: boolean;
  isError?: boolean;
  isCorrect?: boolean;
};

class InputField extends Component<InputFieldProps, InputFieldState> {
  static defaultProps = {
    placeholder: 'Placeholder Text',
    type: 'text',
    errorMessage: '',
    enableCount: false,
    maxLength: 200,
    isCustomValidation: false,
    mandatory: false,
    countryCode: '852',
    isValidateInitValue: false,
    disabled: false,
  };

  constructor(props: InputFieldProps) {
    super(props);
    this.state = {
      hidePlaceholder: false,
      value: this.props.value ? this.props.value : '',
      characterCount: 0,
      onFocus: false,
      isError: false,
      isCorrect: false,
    };
    this.onInput = this.onInput.bind(this);
    this.onBlurInput = this.onBlurInput.bind(this);
    this.onFocusInput = this.onFocusInput.bind(this);
    this.handleOnChange = this.handleOnChange.bind(this);
    this.getStatusClassName = this.getStatusClassName.bind(this);
    this.onUpdateCount = this.onUpdateCount.bind(this);
    this.onInputEmail = this.onInputEmail.bind(this);
    this.onInputMobile = this.onInputMobile.bind(this);
    this.getMobileMaxLength = this.getMobileMaxLength.bind(this);
    this.onInputNumber = this.onInputNumber.bind(this);
  }

  componentDidMount() {
    // when user want to init data and validate value
    if (this.props.isValidateInitValue) {
      this.initValidateData(this.props.value || '');
    }
  }

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: InputFieldProps) {
    if (nextProps.value !== this.props.value) {
      this.setState({
        value: nextProps.value,
      });
      const returnValue = this.onInput(nextProps.value || '');
      this.props.onChange && this.props.onChange(returnValue);
    }
    if (
      !!nextProps.countryCode &&
      nextProps.countryCode !== this.props.countryCode
    ) {
      const returnValue = this.validMobile(
        nextProps.countryCode,
        this.state.value || ''
      );
      this.props.onHandleCountryChange &&
        this.props.onHandleCountryChange(returnValue);
    }
    // for asyn update isValidateInitValue
    if (nextProps.isValidateInitValue !== this.props.isValidateInitValue) {
      this.initValidateData(nextProps.value || '');
    }
  }

  initValidateData(value: string) {
    const returnValue = this.onInput(value);
    this.props.onHandleValidateInitValue &&
      this.props.onHandleValidateInitValue(returnValue);
  }

  getMobileMaxLength() {
    const { type, countryCode, maxLength } = this.props;
    let maxlength = maxLength || 8;
    if (type && type === INPUT_TYPE_MOBILE) {
      maxlength = 8;
      if (countryCode === '86') {
        maxlength = 11;
      }
      if (countryCode === '886') {
        maxlength = 10;
      }
    }
    return maxlength;
  }

  // Email
  onInputEmail(targeValue: string) {
    // emoji RegExp
    const reg = /[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/g
    const value = targeValue.trim().replace(reg, '').toLowerCase();
    const isValidEmail = getIsValidEmail(value);
    const returnValue = {
      value: value,
      isEmpty: false,
      isError: !isValidEmail,
      isCorrect: isValidEmail,
    };
    this.setState({ ...returnValue });
    return returnValue;
  }

  // text
  onInputText(targetValue: string) {
    const isMandatoryText = targetValue && targetValue.length > 0;
    const returnValue = {
      value: targetValue,
      isEmpty: false,
      isError: !isMandatoryText,
      isCorrect: isMandatoryText,
    } as InputFieldState;
    this.setState({ ...returnValue });
    return returnValue;
  }

  // FullName
  onInputFullName(targeValue: string) {
    const value = getFullName(targeValue);
    const isValidFullName = getIsValidFullName(value);
    const returnValue = {
      value: value,
      isEmpty: false,
      isError: !isValidFullName,
      isCorrect: isValidFullName,
    } as InputFieldState;
    this.setState({ ...returnValue });
    return returnValue;
  }

  // mobile
  onInputMobile(targeValue: string) {
    const { countryCode } = this.props;
    let value = targeValue.trim();
    const mobileMaxLength = this.getMobileMaxLength();
    // limit mobile input for max length
    value = intNumberInMaxLength(mobileMaxLength, value);
    const returnValue = this.validMobile(countryCode, value);
    return returnValue;
  }

  validMobile = (countryCode?: string, value?: string) => {
    const { disabled, mandatory } = this.props;
    let isValidMobile = false;
    let returnValue = null
    if (countryCode) {
      isValidMobile = getIsValidMobileNumber(countryCode, value || '');
    }
    if(!mandatory && !value) {
      returnValue = {
        value: value,
        isEmpty: false,
        isError: false,
        isCorrect: false,
      } as InputFieldState;
    } else {
      returnValue = {
        value: value,
        isEmpty: false,
        isError: !isValidMobile && !disabled,
        isCorrect: isValidMobile && !disabled,
      } as InputFieldState;
    }
    
    this.setState({ ...returnValue });
    return returnValue;
  };

  //Number
  onInputNumber(targeValue: string) {
    const { maxLength } = this.props;
    let value = targeValue.trim();
    // limit number input for max length
    value = intNumberInMaxLength(maxLength || 8, value);
    const returnValue = this.validNumber(value);
    return returnValue;
  }

  validNumber = (value: string) => {
    const isValidNumber = getIsValidNumber(value);
    const returnValue = {
      value: value,
      isEmpty: false,
      isError: !isValidNumber,
      isCorrect: isValidNumber,
    };
    this.setState({ ...returnValue });
    return returnValue;
  };

  // input:deal with different type
  onInput(value: string) {
    const {
      type,
      enableCount,
      isCustomValidation,
      onHandleCustomValidation,
      mandatory,
    } = this.props;
    let returnValue = {
      value,
      isEmpty: false,
      isError: false,
      isCorrect: false,
    } as InputFieldState;
    // update value count
    enableCount && this.onUpdateCount(value);
    if (isCustomValidation && !!onHandleCustomValidation) {
      // for custom validation
      returnValue = onHandleCustomValidation(value);
      returnValue && this.setState({ ...returnValue });
    } else {
      // when user input empty and is not mandatory
      if (!mandatory && !value) {
        this.setState({ ...returnValue });
        return returnValue;
      }
      if (mandatory && !value) {
        returnValue = {
          value,
          isEmpty: true,
          isError: true,
          isCorrect: false,
        } as InputFieldState;
        this.setState({ ...returnValue });
        return returnValue;
      }
      // for axa system validation
      switch (type) {
        case INPUT_TYPE_TEXT:
          returnValue = this.onInputText(value);
          break;
        case INPUT_TYPE_EMAIL:
          returnValue = this.onInputEmail(value);
          break;
        case INPUT_TYPE_FULL_NAME:
          returnValue = this.onInputFullName(value);
          break;
        case INPUT_TYPE_MOBILE:
          returnValue = this.onInputMobile(value);
          break;
        case INPUT_TYPE_NUMBER:
          returnValue = this.onInputNumber(value);
          break;
        case TEXTAREA:
          returnValue = this.onInputText(value);
          break;
        default:
          break;
      }
    }

    return returnValue;
  }

  handleOnChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const returnValue = this.onInput(e.target.value);
    this.props.onChange && this.props.onChange(returnValue);
  }

  onFocusInput(e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) {
    this.setState({ hidePlaceholder: true, onFocus: true });
    this.props.onFocus && this.props.onFocus(e);
  }

  onBlurInput(e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const returnValue = this.onInput(e.target.value);
    this.setState({ hidePlaceholder: false, onFocus: false });
    this.props.onBlur && this.props.onBlur(returnValue);
  }

  getStatusClassName() {
    const { isError, isCorrect } = this.state;
    const childrenClassName = {
      childrenSubClassName: 'emma-stylesheet-input',
      inputClassName: 'emma-stylesheet-input-field',
      textClassName: 'emma-stylesheet-input-field-text',
    };
    childrenClassName.childrenSubClassName = isError
      ? 'emma-stylesheet-input-error'
      : childrenClassName.childrenSubClassName;
    childrenClassName.childrenSubClassName = isCorrect
      ? 'emma-stylesheet-input-success'
      : childrenClassName.childrenSubClassName;
    childrenClassName.inputClassName = isError
      ? 'emma-stylesheet-input-error-field'
      : childrenClassName.inputClassName;
    childrenClassName.inputClassName = isCorrect
      ? 'emma-stylesheet-input-success-field'
      : childrenClassName.inputClassName;
    childrenClassName.textClassName = isError
      ? 'emma-stylesheet-input-error-field-text'
      : childrenClassName.textClassName;
    childrenClassName.textClassName = isCorrect
      ? 'emma-stylesheet-input-success-field-text'
      : childrenClassName.textClassName;
    return childrenClassName;
  }

  // EnableCount
  onUpdateCount(targeValue: string) {
    const value = targeValue;
    const { maxLength } = this.props;
    const characterCount =
      value.length <= (maxLength || 8) ? value.length : maxLength;
    this.setState({
      value,
      characterCount,
    });
  }

  render() {
    const {
      type,
      placeholder,
      errorMessage,
      enableCount,
      childrenClassName,
      maxLength,
      id,
      disabled,
      labelTitle,
      inputProps = {},
    } = this.props;
    const { characterCount, value, onFocus, hidePlaceholder, isError } =
      this.state;
    const characterCountTest = `${characterCount} / ${maxLength}`;
    const statusClassName = this.getStatusClassName();
    return (
      <div style={{ width: '100%' }}>
        {
          labelTitle && <div className="emma-stylesheet-label">
            <label className="emma-stylesheet-label__text">
              {labelTitle}
            </label>
          </div>
        }
      <div className={childrenClassName ? childrenClassName : ''}>
        <div className="row">
          <div className={`col-12 ${statusClassName.childrenSubClassName}`}>
            {type === TEXTAREA ? (
              <textarea
                value={value}
                className={`col-12 ${statusClassName.textClassName}`}
                placeholder={hidePlaceholder ? '' : placeholder}
                maxLength={maxLength}
                onBlur={this.onBlurInput}
                onFocus={this.onFocusInput}
                onChange={this.handleOnChange}
                disabled={disabled}
              />
            ) : (
              <input
                type={
                  type === INPUT_TYPE_MOBILE || type === INPUT_TYPE_NUMBER
                    ? 'tel'
                    : type === INPUT_TYPE_EMAIL ? 'text' : type // if type==="email" can not check out emoji by regepx
                }
                value={value}
                className={`col-12 ${statusClassName.inputClassName}`}
                placeholder={hidePlaceholder ? '' : placeholder}
                maxLength={maxLength}
                onBlur={this.onBlurInput}
                onFocus={this.onFocusInput}
                onChange={this.handleOnChange}
                disabled={disabled}
                autoCapitalize='off'
                {...inputProps}
              />
            )}
          </div>
        </div>
        <div className="row">
          <div className="col-12 content-align-right">
            {isError && errorMessage ? (
              <div className="input-mandatoryText-container">
                <span className="emma-stylesheet-input-tip-error">
                  {errorMessage}
                </span>
              </div>
            ) : (
              <div />
            )}
            {enableCount && (
              <div
                className={`input-characterCount-container${
                  onFocus ? '-active' : ''
                }`}
              >
                <div
                  className={`input-characterCount-text${
                    onFocus ? '-active' : ''
                  }`}
                >
                  {characterCountTest}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      </div>
    );
  }
}

export default InputField;
