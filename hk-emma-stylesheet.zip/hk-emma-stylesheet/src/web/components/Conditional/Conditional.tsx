import React from 'react';

type ConditionalProps = {
  children: React.ReactNode;
  test: boolean;
};

const Conditional = ({ test, children }: ConditionalProps) => {
  if (test && children) {
    if (children instanceof Array) return <div>{children}</div>;
    if (typeof children === 'string') return <span>{children}</span>;
    return React.Children.only(children);
  }
  return null;
};

Conditional.defaultProps = {
  children: null,
};

export default Conditional;
