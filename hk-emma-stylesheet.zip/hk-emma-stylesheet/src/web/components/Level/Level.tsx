import React, { Component } from 'react';
import IconUpTriangleBlue from '../../icons/IconUpTriangleBlue';

type LevelProps = {
  list: string[];
  level: number;
  levelWidth: string;
  levelHeight: string;
  levelLowText: string;
  levelHeightText: string;
  margin: number;
  icon: React.ReactNode;
  curLevelClass: string;
};

export default class Level extends Component<LevelProps> {
  static defaultProps = {
    list: ['#027180', '#668980', '#fcd385', '#f07662', '#c91432'],
    level: 1,
    levelWidth: '124px',
    levelHeight: '4px',
    levelLowText: 'Low',
    levelHeightText: 'High',
    margin: 1,
    icon: <IconUpTriangleBlue />,
    curLevelClass: '',
  };

  render() {
    const {
      list,
      levelLowText,
      levelHeightText,
      levelWidth,
      levelHeight,
      icon,
      margin,
      level,
      curLevelClass,
    } = this.props;
    const length = list.length;
    return (
      <div
        className="emma-stylesheet-level"
        style={{
          width: levelWidth,
        }}
      >
        <div
          className="emma-stylesheet-level_list"
          style={{
            height: levelHeight,
          }}
        >
          {list.map((item, index) => (
            <span
              key={index}
              style={{
                background: `${item}`,
                marginRight: index === length - 1 ? '0px' : `${margin}px`,
              }}
              className={level === index + 1 ? curLevelClass : ''}
            >
              {level === index + 1 && (
                <span className="emma-stylesheet-level_icon">{icon}</span>
              )}
            </span>
          ))}
        </div>
        <div className="emma-stylesheet-level_text">
          <span>{levelLowText}</span>
          <span>{levelHeightText}</span>
        </div>
      </div>
    );
  }
}
