import React, { Component } from 'react';

export type ListTableProps = {
  children: React.ReactNode;
};

class ListTable extends Component<ListTableProps> {
  constructor(props: ListTableProps) {
    super(props);
    this.state = {};
  }

  render() {
    const { children } = this.props;
    return (
      <div className="emma-stylesheet-list-table">
        {React.Children.map(children, (c) => c)}
      </div>
    );
  }
}

export default ListTable;
