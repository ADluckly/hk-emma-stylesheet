import React, { Component } from 'react';

export type ListGroupContent = {
  key: string;
  value: string;
};

export type ListGroupProps = {
  content?: ListGroupContent[];
  highLightText?: string;
  isFilterByHighLightText?: boolean;
  cssClass?: string;
  onRowClick?: (content: ListGroupContent) => void;
  errorMessage?: string;
  errorDetail?: string;
  isShowArrow?: boolean;
};

type ListGroupState = {
  displayContentList?: ListGroupContent[];
};

class ListGroup extends Component<ListGroupProps, ListGroupState> {
  static defaultProps = {
    content: [],
    highLightText: '',
    isFilterByHighLightText: false,
    cssClass: '',
    onRowClick: null,
    errorMessage: '',
    errorDetail: '',
    isShowArrow: false,
  };

  constructor(props: ListGroupProps) {
    super(props);
    this.state = {
      displayContentList: [],
    };
  }

  componentDidUpdate(prevProps: ListGroupProps) {
    if (this.props !== prevProps) {
      const displayContentList = this.props.isFilterByHighLightText
        ? this.contentFilter()
        : this.props.content;
      this.setState({ displayContentList });
    }
  }

  contentFilter = () => {
    const { content, highLightText } = this.props;
    return content?.filter(
      (data) =>
        !highLightText ||
        (!!highLightText &&
          data.value.toLowerCase().includes(highLightText.toLowerCase()))
    );
  };

  render() {
    const { highLightText, cssClass, errorMessage, errorDetail, isShowArrow } =
      this.props;
    const { displayContentList } = this.state;
    const cursorStyle = this.props.onRowClick ? 'list-cursor' : '';

    return (
      <div className={`emma-stylesheet-list-group ${cssClass || ''}`}>
        <ul>
          {displayContentList && displayContentList.length > 0 ? (
            displayContentList.map((item) => {
              return (
                <li
                  className={cursorStyle}
                  key={item.key}
                  onClick={() => {
                    this.props.onRowClick && this.props.onRowClick(item);
                  }}
                >
                  <div>
                    {highLightText && highLightText.trim() ? (
                      <span className="list-text-align">
                        {item.value
                          .split(new RegExp(`(${highLightText})`, 'i'))
                          .map((part, i) => (
                            <span
                              key={i}
                              style={
                                part.toLowerCase() ===
                                highLightText.toLowerCase()
                                  ? { color: '#494df4' }
                                  : {}
                              }
                            >
                              {part}
                            </span>
                          ))}
                      </span>
                    ) : (
                      <span className="list-text-align">{item.value}</span>
                    )}
                    {isShowArrow ? <span className="arrow-right" /> : <span />}
                  </div>
                </li>
              );
            })
          ) : errorMessage ? (
            <div className="emma-stylesheet-list-group-error">
              <div className="emma-stylesheet-heading-3">{errorMessage}</div>

              {errorDetail ? (
                <div className="line-break emma-stylesheet-bodyText-L">
                  {errorDetail}
                </div>
              ) : (
                <div />
              )}
            </div>
          ) : (
            <div className="emma-stylesheet-list-group-error">
              {errorDetail ? (
                <div className="line-break emma-stylesheet-bodyText-L">
                  {errorDetail}
                </div>
              ) : (
                <div />
              )}
            </div>
          )}
        </ul>
      </div>
    );
  }
}

export default ListGroup;
