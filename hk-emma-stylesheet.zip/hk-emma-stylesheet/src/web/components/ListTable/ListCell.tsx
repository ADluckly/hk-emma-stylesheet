import React, { Component } from 'react';
import IconInfoBlue from '../../icons/IconInfoBlue';

export type ListCellProps = {
  title: React.ReactNode;
  value: React.ReactNode | number;
  titleClass?: string;
  valueClass?: string;
  cellClass?: string;
  iconClick?: () => void;
  icon?: React.ReactNode;
  isShowIcon?: boolean;
};

class ListCell extends Component<ListCellProps> {
  static defaultProps = {
    title: '',
    value: '',
    titleClass: '',
    valueClass: '',
    cellClass: '',
    isShowIcon: false,
  };

  constructor(props: ListCellProps) {
    super(props);
    this.state = {};
  }

  render() {
    const {
      title,
      value,
      cellClass,
      titleClass,
      valueClass,
      iconClick,
      icon,
      isShowIcon,
    } = this.props;
    return (
      <div
        className={`emma-stylesheet-list-cell ${cellClass ? cellClass : ''}`}
      >
        <div
          className={`emma-stylesheet-list-cell_title ${
            titleClass ? titleClass : ''
          }`}
        >
          {title}
          {isShowIcon && (
            <span
              className="emma-stylesheet-list-cell_icon"
              onClick={iconClick}
              data-enable-ga="true"
              data-ga-type="button"
            >
              {icon ? icon : <IconInfoBlue />}
            </span>
          )}
        </div>
        <div
          className={`emma-stylesheet-list-cell_content ${
            valueClass ? valueClass : ''
          }`}
        >
          {value}
        </div>
      </div>
    );
  }
}

export default ListCell;
