import React, { Component } from 'react';

type stepListOption = {
  title: string | React.ReactNode;
  value: number;
  description?: string | React.ReactNode;
};

type ProgressStepProps = {
  current: number;
  stepList: stepListOption[];
  direction?: string;
};

export default class ProgressStep extends Component<ProgressStepProps> {
  static defaultProps = {
    current: 0,
    stepList: [],
    direction: 'horizontal'
  };

  render() {
    const { current, stepList, direction } = this.props;
    const lastItem = stepList[stepList?.length - 1] || {};
    const maxValue = lastItem.value || 100
    const progress = current / maxValue * 100
    const activeItem = stepList?.find((item) => item.value === current)
    return (
      direction === 'vertical' ? <div className='emma-stylesheet-progress-step-vertical'>
        <div className={ activeItem ||  current > lastItem.value ? 'emma-stylesheet-progress-step-vertical_current-line--active' : 'emma-stylesheet-progress-step-vertical_current-line'} style={{ height: `${progress < 0 ? 0 : progress > 100 ? 100 : progress}%` }}></div>
        <div className='emma-stylesheet-progress-step-vertical_wrap'>
          {
            stepList?.map((item) => (
              <div className='emma-stylesheet-progress-step-vertical_wrap-item'>
                <div
                  className={`emma-stylesheet-progress-step_dot-item ${item.value <= current ? 'emma-stylesheet-progress-step_dot-item--active' : ''}`}>
                </div>
                <div className='emma-stylesheet-progress-step-vertical_content-item'>
                  {
                    item.title && <div className='emma-stylesheet-progress-step-vertical_content-item-title'>{item.title}</div>
                  }
                  {
                    item.description && <div className='emma-stylesheet-progress-step-vertical_content-item-description'>{item.description}</div>
                  }
                </div>
              </div>
            ))
          }
        </div>
      </div> :
      <div className='emma-stylesheet-progress-step-horizontal'>
        <div className='emma-stylesheet-progress-step-horizontal_line'></div>
        <div
          className={activeItem ||  current > lastItem.value ? 'emma-stylesheet-progress-step-horizontal_current-line--active' : 'emma-stylesheet-progress-step-horizontal_current-line'}
          style={{ width: `${progress < 0 ? 0 : progress > 100 ? 100 : progress}%` }}>
        </div>
        <div className='emma-stylesheet-progress-step-horizontal_wrap'>
          {
            stepList?.map((item) => (
              <div className='emma-stylesheet-progress-step-horizontal_wrap-item'>
                <div
                  className={`emma-stylesheet-progress-step_dot-item ${item.value <= current ? 'emma-stylesheet-progress-step_dot-item--active' : ''}`}>
                </div>
                <div className='emma-stylesheet-progress-step-horizontal_content-item'>
                  {
                    item.title && <div className='emma-stylesheet-progress-step-horizontal_content-item-title'>{item.title}</div>
                  }
                  {
                    item.description && <div className='emma-stylesheet-progress-step-horizontal_content-item-description'>{item.description}</div>
                  }
                </div>
              </div>
            ))
          }
        </div>
      </div>
    );
  }
}
