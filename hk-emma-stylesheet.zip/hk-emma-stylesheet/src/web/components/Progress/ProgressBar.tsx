import React, { Component } from 'react';

type ProgressBarProps = {
  percentage: number;
  rightText?: string;
};

export default class ProgressBar extends Component<ProgressBarProps> {
  render() {
    const { percentage, rightText } = this.props;
    return (
      <div className="emma-stylesheet-progress-bar">
        <div className="emma-stylesheet-progress-bar-content">
          <div
            className={`emma-stylesheet-progress-bar-content-size ${
              percentage === 100
                ? 'emma-stylesheet-progress-bar-content-size-completed'
                : ''
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>
        {!!rightText && (
          <div className="emma-stylesheet-progress-bar-right-content content-align-right">
            <div></div>
            <div>{rightText}</div>
          </div>
        )}
      </div>
    );
  }
}
