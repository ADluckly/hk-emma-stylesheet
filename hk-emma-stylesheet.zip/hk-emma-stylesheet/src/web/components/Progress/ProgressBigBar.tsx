/* eslint-disable react-native/no-inline-styles */
import React, { Component } from 'react';

type ProgressBigBarProps = {
  percentage: number;
  percentageText?: string;
  percentageTextColor?: string;
  scalePercentage?: number;
  scalePercentageText?: string;
  progressBigBarBgColor?: string;
  percentageProgressBigBarBgColor?: string;
  scalePercentageColor?: string;
};

export default class ProgressBigBar extends Component<ProgressBigBarProps> {
  static defaultProps = {
    percentageTextColor: "#494df4",
    progressBigBarBgColor: "#CCC",
    percentageProgressBigBarBgColor: "#e8f0f9",
    scalePercentageColor: "#C91432"
  };

  render() {
    const {
      percentage,
      percentageText,
      percentageTextColor,
      scalePercentage,
      scalePercentageText,
      progressBigBarBgColor,
      percentageProgressBigBarBgColor,
      scalePercentageColor
    } = this.props;
    return (
      <div className="emma-stylesheet-progress-big-bar">
        <div
          className="emma-stylesheet-progress-big-bar-bg"
          style={{
            backgroundColor: progressBigBarBgColor
              ? `${progressBigBarBgColor}`
              : ''
          }}
        />
        <div
          className="emma-stylesheet-progress-big-bar-container content-align"
          style={{
            width: `${percentage}%`,
            backgroundColor: percentageProgressBigBarBgColor
              ? `${percentageProgressBigBarBgColor}`
              : '',
            color: `${percentageTextColor}`
          }}
        >
          {percentageText}
        </div>
        {!!scalePercentageText && (
          <div
            className="emma-stylesheet-progress-big-bar-scale"
            style={{ left: `${scalePercentage}%` }}
          >
            <div
              className="emma-stylesheet-progress-big-bar-scale-span"
              style={{
                backgroundColor: scalePercentageColor
                  ? `${scalePercentageColor}`
                  : ''
              }}
            >
              {scalePercentageText}
            </div>
            <div
              className="emma-stylesheet-progress-big-bar-scale-line"
              style={{
                borderLeftColor: scalePercentageColor
                  ? `${scalePercentageColor}`
                  : ''
              }}
            />
          </div>
        )}
      </div>
    );
  }
}
