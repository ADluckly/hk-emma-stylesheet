import React, { Component } from 'react';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';

type ProgressCircleProps = {
  percentage: number;
  text?: string;
  textColor?: string;
  pathColor?: string;
  trailColor?: string;
};

export default class ProgressCircle extends Component<ProgressCircleProps> {
  static defaultProps = {
    textColor: "#00ADC6",
    pathColor: "#00ADC6",
    trailColor: "#ccc"
  };

  render() {
    const {
      percentage,
      text,
      textColor,
      pathColor,
      trailColor,
    }=this.props;
    return (
        <CircularProgressbar
          value={percentage}
          text={text}
          styles={buildStyles({
            textColor: `${textColor}`,
            pathColor: `${pathColor}`,
            trailColor: `${trailColor}`
          })}
        />
    );
  }
}
