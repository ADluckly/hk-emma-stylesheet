import React, { Component } from 'react';
import Dropdown, { DropdownOption, DropdownProps } from '../Dropdown/Dropdown';
import { getDayList, getMonthList, getYearList } from '../../common/common';

export type DateOfBirthProps = {
  dayList?: DropdownOption[];
  monthList?: DropdownOption[];
  yearList?: DropdownOption[];
  dayValue?: string;
  monthValue?: string;
  yearValue?: string;
  dayTitle?: string;
  monthTitle?: string;
  yearTitle?: string;
  isValidateInitValue?: boolean;
  onChange?: (
    dayValue?: string,
    monthValue?: string,
    yearValue?: string,
    errorMessage?: string | boolean
  ) => void;
  onHandleValidation?: (
    dayValue?: string,
    monthValue?: string,
    yearValue?: string
  ) => string | boolean;
};

type DateOfBirthState = {
  dayValue?: string;
  monthValue?: string;
  yearValue?: string;
  isShowDayOptionList: boolean;
  isShowMonthOptionList: boolean;
  isShowYearOptionList: boolean;
  errorMessage?: string | boolean;
};

class DateOfBirth extends Component<DateOfBirthProps, DateOfBirthState> {
  static defaultProps = {
    isValidateInitValue: false,
  };

  constructor(props: DateOfBirthProps) {
    super(props);
    const { dayValue, monthValue, yearValue } = this.props;
    this.state = {
      isShowDayOptionList: false,
      isShowMonthOptionList: false,
      isShowYearOptionList: false,
      dayValue,
      monthValue,
      yearValue,
      errorMessage: '',
    };
  }

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: DateOfBirthProps) {
    const { dayValue, monthValue, yearValue } = nextProps;
    if(dayValue !== this.props.dayValue) {
      this.setState({
        dayValue
      }, () => {
        dayValue && this.validateValue()
      });
    }
    if(monthValue !== this.props.monthValue) {
      this.setState({
        monthValue
      }, () => {
        monthValue && this.validateValue()
      });
    }
    if(yearValue !== this.props.yearValue) {
      this.setState({
        yearValue
      }, () => {
        yearValue && this.validateValue()
      });
    }
    
  }

  componentDidMount() {
    const { isValidateInitValue } = this.props;
    if (isValidateInitValue) {
      this.validateValue();
    }
  }

  setOpenOption(type: string, val: string | boolean) {
    if (type === 'day') {
      this.setState({ isShowDayOptionList: !!val });
    } else if (type === 'month') {
      this.setState({ isShowMonthOptionList: !!val });
    } else if (type === 'year') {
      this.setState({ isShowYearOptionList: !!val });
    }
  }

  onChangeValue() {
    const { dayValue, monthValue, yearValue } = this.state;
    const { onChange } = this.props;
    const errorMessage = this.validateValue();
    onChange && onChange(dayValue, monthValue, yearValue, !!errorMessage);
  }

  onClickAction(type: string, val: string) {
    if (type === 'day') {
      this.setState({ dayValue: val }, () => {
        this.onChangeValue();
      });
    } else if (type === 'month') {
      this.setState({ monthValue: val }, () => {
        this.onChangeValue();
      });
    } else if (type === 'year') {
      this.setState({ yearValue: val }, () => {
        this.onChangeValue();
      });
    }
  }

  validateValue() {
    const { dayValue, monthValue, yearValue } = this.state;
    const { onHandleValidation } = this.props;
    const errorMessage =
      onHandleValidation && onHandleValidation(dayValue, monthValue, yearValue);
    this.setState({ errorMessage });
    return errorMessage;
  }

  render() {
    const { dayList, monthList, yearList, dayTitle, monthTitle, yearTitle } =
      this.props;
    const {
      isShowDayOptionList,
      isShowMonthOptionList,
      isShowYearOptionList,
      dayValue,
      monthValue,
      yearValue,
      errorMessage,
    } = this.state;
    const dayOptionList = dayList || getDayList();
    const monthOptionList = monthList || getMonthList();
    const yearOptionList = yearList || getYearList();
    const dayDropdownProps = {
      optionList: dayOptionList,
      value: dayValue || '',
      title: dayTitle || 'Day',
      isShowOptionList: isShowDayOptionList,
      onClickAction: (val: string) => this.onClickAction('day', val),
      setOption: (val: boolean) => this.setOpenOption('day', val),
      isError: !!errorMessage,
    } as DropdownProps;
    const monthDropdownProps = {
      optionList: monthOptionList,
      value: monthValue || '',
      title: monthTitle || 'Month',
      isShowOptionList: isShowMonthOptionList,
      onClickAction: (val: string) => this.onClickAction('month', val),
      setOption: (val: boolean) => this.setOpenOption('month', val),
      isError: !!errorMessage,
    } as DropdownProps;
    const yearDropdownProps = {
      optionList: yearOptionList,
      value: yearValue || '',
      title: yearTitle || 'Year',
      isShowOptionList: isShowYearOptionList,
      onClickAction: (val: string) => this.onClickAction('year', val),
      setOption: (val: boolean) => this.setOpenOption('year', val),
      isError: !!errorMessage,
    } as DropdownProps;
    return (
      <div>
        <div className="emma-stylesheet-dateOfBirth">
          <div className="emma-stylesheet-dateOfBirth-dropDown">
            <Dropdown {...yearDropdownProps} />
          </div>
          <span className="emma-stylesheet-dateOfBirth-sapn">/</span>
          <div className="emma-stylesheet-dateOfBirth-dropDown">
            <Dropdown {...monthDropdownProps} />
          </div>
          <span className="emma-stylesheet-dateOfBirth-sapn">/</span>
          <div className="emma-stylesheet-dateOfBirth-dropDown">
            <Dropdown {...dayDropdownProps} />
          </div>
        </div>
        {errorMessage && (
          <div className="emma-stylesheet-input-tip-error">{errorMessage}</div>
        )}
      </div>
    );
  }
}

export default DateOfBirth;
