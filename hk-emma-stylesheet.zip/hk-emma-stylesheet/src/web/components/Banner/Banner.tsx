import React, { Component } from 'react';

type BannerProps = {
  bannerIcon?: string;
  title?: string;
  content?: string;
  buttonText?: string;
  onClick?: () => void;
};

class Banner extends Component<BannerProps> {
  onClickBanner = () => {
    this.props.onClick && this.props.onClick();
  };

  render() {
    const { bannerIcon, title, content, buttonText } = this.props;
    return (
      <div className="emma-stylesheet-banner content-align-level">
        <div className="emma-stylesheet-banner-left">
          <div className="emma-stylesheet-banner-left-img content-align-vertical">
            {bannerIcon && <img src={bannerIcon} />}
          </div>
        </div>
        <div className="emma-stylesheet-banner-right">
          {title && (
            <div className="emma-stylesheet-banner-right-title">{title}</div>
          )}
          {content && (
            <div className="emma-stylesheet-banner-right-desc">{content}</div>
          )}
          {buttonText && (
            <div className="emma-stylesheet-banner-right-button">
              <button
                className="emma-stylesheet-banner-right-button-text"
                onClick={this.onClickBanner}
              >
                {buttonText}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default Banner;
