import React, { Component } from 'react';

export type DialogFooterProps = {
  children?: React.ReactNode;
};

class DialogFooter extends Component<DialogFooterProps> {
  static defaultProps = {
    children: null,
  };

  render() {
    const { children } = this.props;
    return (
      <div className="emma-stylesheet-dialog-footer">
        <div className="emma-stylesheet-dialog-footer__wrapper">{children}</div>
      </div>
    );
  }
}

export default DialogFooter;
