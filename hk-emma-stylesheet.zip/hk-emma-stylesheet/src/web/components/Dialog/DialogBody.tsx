import React, { Component } from 'react';

export type DialogBodyProps = {
  children?: React.ReactNode;
};

class DialogBody extends Component<DialogBodyProps> {
  static defaultProps = {
    children: 'This the content of modal.',
  };

  render() {
    const { children } = this.props;
    return <div className="emma-stylesheet-dialog-body">{children}</div>;
  }
}

export default DialogBody;