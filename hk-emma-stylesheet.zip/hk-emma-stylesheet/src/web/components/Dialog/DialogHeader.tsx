import React, { Component } from 'react';

export type DialogHeaderProps = {
  children?: React.ReactNode;
};

class DialogHeader extends Component<DialogHeaderProps> {
  static defaultProps = {
    children: 'This the title of modal.',
  };

  render() {
    const { children } = this.props;
    return (
      <div className="emma-stylesheet-dialog-header">
        <div className="emma-stylesheet-dialog-header__title">{children}</div>
      </div>
    );
  }
}

export default DialogHeader;
