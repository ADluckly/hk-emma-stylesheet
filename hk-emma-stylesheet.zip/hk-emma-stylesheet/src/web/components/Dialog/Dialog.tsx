import React, { Component } from 'react';
import { sidecar } from 'use-sidecar';
import { RemoveScroll } from 'react-remove-scroll/UI';

const Sidecar = sidecar(() => import('react-remove-scroll/sidecar'));

export type ModalProps = {
  show: boolean;
  children?: React.ReactNode;
  onHide?: (event: React.MouseEvent<HTMLDivElement>) => void;
  type: string;
  zIndex: number;
};

class Dialog extends Component<ModalProps> {
  static defaultProps = {
    show: false,
    type: 'default',
    zIndex: 9998,
  };

  render() {
    const { show, children, type, zIndex, onHide } = this.props;
    return (
      <div>
        <div
          className="emma-stylesheet-dialog-overlay"
          hidden={!show}
          style={{ zIndex: zIndex }}
          onClick={onHide}
        />
        {show && (
          <RemoveScroll sideCar={Sidecar}>
            <div
              className={
                type === 'emma'
                  ? 'emma-stylesheet-dialog-container-emma'
                  : 'emma-stylesheet-dialog-container'
              }
            >
              <div
                className={
                  type === 'emma'
                    ? 'emma-stylesheet-dialog-wrapper-emma'
                    : 'emma-stylesheet-dialog-wrapper'
                }
              >
                {children}
              </div>
            </div>
          </RemoveScroll>
        )}
      </div>
    );
  }
}

export default Dialog;
