import React, { Component } from 'react';

export type NotificationProps = {
  isShowRedDot: boolean;
  title: string;
  content: string;
  category: string;
  hoursClock: string;
  onClick: () => void;
};

class Notification extends Component<NotificationProps> {
  constructor(props: NotificationProps) {
    super(props);
  }

  onClickBanner = () => {
    this.props.onClick && this.props.onClick();
  };

  transferText = (text: string, maxlength: number) => {
    return text.length <= maxlength
      ? text
      : `${text.substring(0, maxlength)}...`;
  };

  render() {
    const { title, content, isShowRedDot, category, hoursClock } = this.props;
    return (
      <div className="emma-stylesheet-notification content-level-wrap">
        <div className="emma-stylesheet-notification-left content-align-vertical">
          {isShowRedDot && (
            <div className="emma-stylesheet-notification-left-red-dot" />
          )}
        </div>
        <div className="emma-stylesheet-notification-center">
          {title && (
            <div className="emma-stylesheet-notification-center-title">
              {this.transferText(title, 80)}
            </div>
          )}
          {content && (
            <div className="emma-stylesheet-notification-center-desc">
              {this.transferText(content, 120)}
            </div>
          )}
          <div className="emma-stylesheet-notification-center-bottom content-align-right">
            {category && (
              <div className="emma-stylesheet-notification-center-bottom-left">
                {category}
              </div>
            )}
            {hoursClock && (
              <div className="emma-stylesheet-notification-center-bottom-right">
                {hoursClock}
              </div>
            )}
          </div>
        </div>
        <div className="emma-stylesheet-notification-right" />
      </div>
    );
  }
}

export default Notification;
