import React, { Component } from 'react';
import Dropdown, { DropdownProps } from '../Dropdown/Dropdown';
import InputField, { InputFieldProps } from '../Input/InputField';

type CountryOption = {
  optionVal: string;
  optionTitle: string;
};

export type CountryTelephoneNumberProps = {
  countryCode?: string;
  mobileValue?: string;
  isValidateInitValue?: boolean;
  onHandleValidateInitValue?: (value: any) => void;
  onChange?: (value: any) => void;
  onBlur?: (value: any) => void;
  onFocus?: (value: any) => void;
  placeholder?: string;
  dropdownPlaceholder?: string;
  errorMessage?: string;
  countryOption?: CountryOption[];
  hideDropdown?: boolean;
  disabled?: boolean;
  disabledDropdown?: boolean;
  mandatory?: boolean;
};

type CountryTelephoneNumberState = {
  countryValue: string;
  isShowCountryOption: boolean;
};

class CountryTelephoneNumber extends Component<
  CountryTelephoneNumberProps,
  CountryTelephoneNumberState
> {
  static defaultProps = {
    countryCode: '852',
    placeholder: 'your mobile no',
    dropdownPlaceholder: 'Choose from multiple options',
    errorMessage: 'Please provide a valid mobile no',
    countryOption: [
      {
        optionVal: '852',
        optionTitle: '852',
      },
      {
        optionVal: '853',
        optionTitle: '853',
      },
      {
        optionVal: '86',
        optionTitle: '86',
      },
    ],
    isValidateInitValue: false,
    hideDropdown: false,
    disabled: false,
    disabledDropdown: false,
    mandatory: false,
  };

  constructor(props: CountryTelephoneNumberProps) {
    super(props);
    this.state = {
      // Mobile no.
      isShowCountryOption: false,
      countryValue: this.props.countryCode || '',
    };
  }

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: CountryTelephoneNumberProps) {
    if (nextProps.countryCode !== this.props.countryCode) {
      this.setState({
        countryValue: nextProps.countryCode || '',
      });
    }
  }

  returnValToProps = (val: any) => {
    const { countryValue } = this.state;
    return {
      countryValue,
      ...val,
    };
  };

  setOpenOption = (val: boolean) => {
    this.setState({
      isShowCountryOption: val,
    });
  };

  chooseOption = (val: string) => {
    this.setState({
      countryValue: val,
    });
  };

  onMobileChange = (val: any) => {
    const returnVal = this.returnValToProps(val);
    this.props.onChange && this.props.onChange(returnVal);
  };

  onMobileBlur = (val: any) => {
    const returnVal = this.returnValToProps(val);
    this.props.onBlur && this.props.onBlur(returnVal);
  };

  onMobileFocus = (val: any) => {
    const returnVal = this.returnValToProps(val);
    this.props.onFocus && this.props.onFocus(returnVal);
  };

  onHandleCountryChange = (val: any) => {
    const returnVal = this.returnValToProps(val);
    this.props.onChange && this.props.onChange(returnVal);
  };

  onHandleValidateInitValue = (val: any) => {
    const returnVal = this.returnValToProps(val);
    this.props.onHandleValidateInitValue &&
      this.props.onHandleValidateInitValue(returnVal);
  };

  render() {
    const {
      countryOption,
      placeholder,
      dropdownPlaceholder,
      errorMessage,
      mobileValue,
      isValidateInitValue,
      hideDropdown,
      disabled,
      disabledDropdown,
      mandatory,
    } = this.props;
    const { isShowCountryOption, countryValue } = this.state;

    const dropdownProps = {
      dropDownClassName: 'col-12',
      optionList: countryOption,
      isShowOptionList: isShowCountryOption,
      setOption: this.setOpenOption,
      value: countryValue,
      title: dropdownPlaceholder,
      onClickAction: this.chooseOption,
      disabled: disabledDropdown,
    } as DropdownProps;

    const inputMobileProps = {
      type: 'mobile',
      childrenClassName: 'col-12',
      errorMessage: errorMessage,
      placeholder: placeholder,
      countryCode: countryValue,
      value: mobileValue,
      isValidateInitValue: isValidateInitValue,
      disabled: disabled,
      onHandleValidateInitValue: this.onHandleValidateInitValue,
      onChange: this.onMobileChange,
      onBlur: this.onMobileBlur,
      onFocus: this.onMobileFocus,
      onHandleCountryChange: this.onHandleCountryChange,
      mandatory: mandatory,
    } as InputFieldProps;
    return (
      <div className="emma-stylesheet-country-telephone-number">
        <div className="row emma-stylesheet-country-telephone-number-level">
          {!hideDropdown && (
            <div className="country">
              <Dropdown {...dropdownProps} />
            </div>
          )}
          <div
            className={`telephone-number ${hideDropdown ? 'full-width' : ''}`}
          >
            <InputField {...inputMobileProps} />
          </div>
        </div>
      </div>
    );
  }
}

export default CountryTelephoneNumber;
