import React, { Component } from 'react';
import { isApp } from '../../utils'

export type DropdownOption = {
  optionVal: string;
  optionTitle: string | any;
  disabled?: boolean;
};

export type DropdownProps = {
  value?: string | any;
  optionList?: DropdownOption[];
  title?: string;
  labelTitle?: string | React.ReactNode;
  // eslint-disable-next-line @typescript-eslint/ban-types
  onClickAction?: ((value: string) => void) | Function;
  isShowOptionList?: boolean;
  // eslint-disable-next-line @typescript-eslint/ban-types
  setOption?: ((value: boolean) => void) | Function;
  description?: string;
  dropDownClassName?: string;
  // eslint-disable-next-line @typescript-eslint/ban-types
  onBlurOptions?: ((value: boolean | string) => void) | Function;
  isError?: boolean;
  mandatory?: boolean;
  disabled?: boolean;
  isEnableGa?: boolean;
};

type DropdownState = {
  value: string;
  isClickOpenOption: boolean;
  isMandatoryError: boolean;
};

class Dropdown extends Component<DropdownProps, DropdownState> {
  static defaultProps = {
    mandatory: false,
    disabled: false,
  };

  state = {
    value: '',
    isClickOpenOption: false,
    isMandatoryError: false,
  };

  keyUpTitle!: string;

  constructor(props: DropdownProps) {
    super(props);
    this.keyUpTitle = ''
  }

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: DropdownProps) {
    if (nextProps.value !== this.props.value) {
      this.setState({
        value: nextProps.value,
      });
    }
  }

  onOpenOptions() {
    const { isClickOpenOption } = this.state;
    this.setState({
      isClickOpenOption: !isClickOpenOption,
    });
    this.props.setOption && this.props.setOption(!this.props.isShowOptionList);
  }

  onCloseOptions() {
    const { value, mandatory } = this.props;
    const isMandatoryError = !!(mandatory && !value);
    this.setState({
      isClickOpenOption: false,
      isMandatoryError,
    });
    this.props.setOption && this.props.setOption(false);
    this.props.onBlurOptions && this.props.onBlurOptions(value);
  }

  onItemClick = (val: string) => {
    this.props.onClickAction && this.props.onClickAction(val);
    this.onOpenOptions();
  };

  componentDidMount() {
    window.addEventListener('keyup', this.handleKeyUp())
  }

  componentWillUnmount() {
    window.removeEventListener('keyup', this.handleKeyUp())
  }

  handleKeyUp() {
    let timeout: any = null
    return (e: any) => {
      const { isShowOptionList, optionList, disabled } = this.props
      if (!(!isApp() && isShowOptionList && optionList && optionList.length > 0 && !disabled)) {
        return
      }
      clearTimeout(timeout)
      timeout = setTimeout(() => {
        this.keyUpTitle = ''
      }, 1000)
      this.keyUpChooseOption(e)
    }
  }

  keyUpChooseOption(e: any) {
    const { optionList = [] } = this.props
    if (!/[a-zA-Z0-9]/.test(e.key)) {
      return
    }
    this.keyUpTitle = this.keyUpTitle + e.key
    const index: any = optionList && optionList.findIndex((item) => {
      const reg = new RegExp("^" + this.keyUpTitle.toLowerCase())
      return reg.test(item.optionTitle.toLowerCase())
    })
    if (index > -1) {
      this.props.onClickAction && this.props.onClickAction(optionList[index].optionVal)
    }
  }

  render() {
    const { isClickOpenOption, isMandatoryError } = this.state;
    const {
      value,
      optionList,
      title,
      isShowOptionList,
      dropDownClassName,
      isError,
      disabled,
      isEnableGa,
      labelTitle
    } = this.props;
    const selectOption = (optionList &&
      optionList.find((option) => option.optionVal === value)) || {
      optionTitle: null,
    };
    const isShowError = isError || isMandatoryError;
    return (
      <div>
        {
          labelTitle && <div className="emma-stylesheet-label">
            <label className="emma-stylesheet-label__text">
              {labelTitle}
            </label>
          </div>
        }
        {
          isApp() ?
            <div className={`emma-stylesheet-dropdown_wrapper-default ${dropDownClassName ? dropDownClassName : ''}`}>
              <select className={`emma-stylesheet-dropdown_wrapper ${isShowError && 'emma-stylesheet-dropdown_error'}`}
                disabled={disabled}
                value={value || ''}
                onChange={(e) => this.onItemClick(e.target.value)}
                onBlur={() => this.onCloseOptions()}
                data-has-value={value ? 'true' : 'false'}
              >
                <option value="" disabled style={{ display: 'none' }}>{title ? title : ''}</option>
                {
                  optionList && optionList.map((item, index) => {
                    return (
                      <option
                        key={index}
                        value={item.optionVal}
                        data-enable-ga={isEnableGa}
                        data-ga-type="dropdown"
                        disabled={item.disabled ? true : false}
                      >
                        {item.optionTitle}
                      </option>
                    );
                  })
                }
              </select>
              <span className="arrow"></span>
            </div>
            :
            <div
              className={`${!disabled
                ? 'emma-stylesheet-dropdown'
                : 'emma-stylesheet-dropdown_disabled'
                } ${dropDownClassName ? dropDownClassName : ''}`}
              onBlur={() => this.onCloseOptions()}
              tabIndex={0}
            >
              <div
                className={`emma-stylesheet-dropdown_wrapper content-align-right ${isClickOpenOption && !isShowError
                  ? 'emma-stylesheet-dropdown_selected'
                  : ''
                  } ${isShowError && 'emma-stylesheet-dropdown_error'} ${disabled && 'emma-stylesheet-dropdown_wrapper_disabled'
                  }`}
                onClick={() => this.onOpenOptions()}
              >
                <div
                  className={`emma-stylesheet-dropdown_wrapper-label ${value ? 'emma-stylesheet-dropdown_wrapper-label-selected' : ''
                    }`}
                >
                  <span>{selectOption.optionTitle || (title ? title : '')}</span>
                </div>
                <div className="emma-stylesheet-dropdown_wrapper-icon">
                  <span className="arrow" />
                </div>
                <ul
                  className="emma-stylesheet-dropdown_menu"
                  style={{ display: isShowOptionList ? '' : 'none' }}
                >
                  {optionList &&
                    optionList.map((item, index) => {
                      return (
                        <li
                          key={index}
                          onClick={item.disabled ? () => { } : () => this.onItemClick(item.optionVal)}
                          data-enable-ga={isEnableGa}
                          data-ga-type="dropdown"
                          className={`${item.disabled ? 'disabled' : ''}`}
                        >
                          <div
                            className={`li_wrapper ${item.optionVal === value ? 'selected' : ''
                              }`}
                          >
                            {item.optionTitle}
                          </div>
                        </li>
                      );
                    })}
                </ul>
              </div>
            </div>
        }
      </div>
    );
  }
}

export default Dropdown;
