import React, { PureComponent } from 'react';
import IconClock from '../../icons/IconClockDark';

export type TimePickerDropdownProps = {
  onChange: (value: string) => void;
  timePickerClassName: string;
  children: React.ReactNode;
  input: any;
  value: string | number;
  disabled: boolean;
  icon: any;
};

class TimePickerDropdown extends PureComponent<TimePickerDropdownProps> {
  static defaultProps = {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onChange: () => {},
    timePickerClassName: '',
    children: <option />,
    input: {},
    value: '',
    disabled: false,
    icon: '',
  };

  constructor(props: TimePickerDropdownProps) {
    super(props);
    this.onChange = this.onChange.bind(this);
  }

  onChange(e: React.ChangeEvent<HTMLSelectElement> | any) {
    this.props.onChange(e.target.value || '');
  }

  render() {
    const { timePickerClassName, children, input, disabled, value, icon } =
      this.props;
    return (
      <div className="emma-stylesheet-timepicker-emmaWrapDiv">
        <select
          className={`emma-stylesheet-timepicker-emmaAagentSelect ${timePickerClassName} ${
            value !== '' ? 'selected' : ''
          }`}
          onChange={this.onChange}
          disabled={disabled}
          value={value}
          {...input}
        >
          {children}
        </select>
        <div className="icon" onClick={this.onChange}>
          <IconClock />
        </div>
      </div>
    );
  }
}

export default TimePickerDropdown;
