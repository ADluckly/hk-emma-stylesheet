import React, { Component } from 'react';
import TimePickerDropdown from './TimePickerDropdown';

export type StoreTimeListItem = {
  key: string;
  label: string;
  value: string;
  disabled: boolean;
  isClosed: boolean;
};

export type TimePickerProps = {
  storeTimesList: StoreTimeListItem[];
  selectedTime: string | number;
  onChange: () => void;
  description: string;
  timePickerClassName: string;
};

class TimePicker extends Component<TimePickerProps> {
  static defaultProps = {
    storeTimesList: [
      {
        key: '09:30-14:00',
        label: '09:30-14:00',
        value: '09:30-14:00',
        disabled: false,
      },
      {
        key: '15:30-19:00',
        label: '15:30-19:00',
        value: '15:30-19:00',
        disabled: false,
      },
      {
        key: '20:30-22:00',
        label: '20:30-22:00',
        value: '20:30-22:00',
        disabled: false,
      },
    ],
    selectedTime: '',
    description: 'Select Time',
    timePickerClassName: '',
  };

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: TimePickerProps) {
    if (nextProps.selectedTime !== this.props.selectedTime) {
      this.setState({
        selectedTime: nextProps.selectedTime,
      });
    }
  }

  render() {
    const {
      selectedTime,
      storeTimesList,
      onChange,
      description,
      timePickerClassName,
    } = this.props;
    return (
      <div>
        <TimePickerDropdown
          value={selectedTime}
          onChange={onChange}
          timePickerClassName={timePickerClassName}
        >
          {storeTimesList.map((time, index) => {
            if (index === 0) {
              return (
                <option
                  key={-1}
                  className="emma-stylesheet-timepicker-select-placeholder"
                  value=""
                  disabled
                >
                  {description}
                </option>
              );
            }
          })}
          {storeTimesList.map((time, index) => {
            if (!time.isClosed) {
              return (
                <option key={index} value={time.value} disabled={time.disabled}>
                  {time.label}
                </option>
              );
            }
          })}
        </TimePickerDropdown>
      </div>
    );
  }
}

export default TimePicker;
