import React from 'react';

export type StepListItem = {
  item: any;
  sub_item: any;
  selected?: boolean;
};

export type StepContext = {
  title: string;
  list: StepListItem[];
};

export type StepProps = {
  itemClassName?: string;
  context?: StepContext | string;
};

class Step extends React.Component<StepProps> {
  //itemClassName: For customise control item style, like item text style and so on
  //context.list:A list of text for showing
  //item: The main item text of the list
  //sub_item: The sub item text of the list
  static defaultProps = {
    itemClassName: '',
    context: {
      title: 'title',
      list: [
        {
          item: 'item',
          sub_item: 'sub_item',
        },
      ],
    },
  };

  constructor(props: StepProps) {
    super(props);
    this.state = {};
  }

  render() {
    const { itemClassName, context } = this.props;

    return (
      <div className="emma-stylesheet-step">
        {!!context && typeof context === 'object'
          ? context?.list?.map((item, index) => {
            return (
                <div className={'emma-stylesheet-step-item'} key={index}>
                  <div className="emma-stylesheet-step-item-border" />
                  <div
                  className={`emma-stylesheet-step-item-icon ${
                      item.selected
                        ? 'emma-stylesheet-step-item-icon-selected'
                      : ''
                    }`}
                />
                  <div className="emma-stylesheet-step-item-content">
                    {
                      typeof item.item === 'string' ?
                        <div className="emma-stylesheet-step-item-content-title" dangerouslySetInnerHTML={{ __html: item.item }}></div> :
                        <div className="emma-stylesheet-step-item-content-title">{item.item}</div>
                    }
                    {
                      typeof item.sub_item === 'string' ?
                        <div className="emma-stylesheet-step-item-content-sub-title" dangerouslySetInnerHTML={{ __html: item.sub_item }}></div> :
                        <div className="emma-stylesheet-step-item-content-sub-title">{item.sub_item}</div>
                    }
                </div>
                </div>
            );
          })
          : context}
      </div>
    );
  }
}

export default Step;
