import React, { Component } from 'react';

export type PolicyCardProps = {
  planName: string;
  policyNumber: string;
  certificateNumber: string;
  isSelected: boolean;
};

class PolicyCard extends Component<PolicyCardProps> {
  static defaultProps = {
    planName: '',
    policyNumber: '',
    certificateNumber: '',
    isSelected: false,
  };

  constructor(props: PolicyCardProps) {
    super(props);
  }

  render() {
    const { planName, policyNumber, certificateNumber, isSelected } =
      this.props;
    const policyCardClassName = isSelected
      ? 'emma-stylesheet-policy-card emma-stylesheet-policy-card-selected'
      : 'emma-stylesheet-policy-card';
    return (
      <div className={policyCardClassName}>
        <div className="emma-stylesheet-policy-card-plan-name">{planName}</div>
        <div className="emma-stylesheet-policy-card-number">
          <div className="emma-stylesheet-policy-card-pn">
            PN:{policyNumber}
          </div>
          {certificateNumber && (
            <div className="emma-stylesheet-policy-card-cn">
              CN:{certificateNumber}
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default PolicyCard;
