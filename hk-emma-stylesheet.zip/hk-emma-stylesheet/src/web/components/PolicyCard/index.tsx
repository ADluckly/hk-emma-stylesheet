import PolicyCard from './PolicyCard';

export default PolicyCard;
