// https://github.com/storybookjs/storybook/issues/13086#issuecomment-732501050
import * as React from 'react';
import classnames from 'classnames';

export interface SmallButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  varient?: 'default' | 'white' | 'ghost';
  isLoading?: boolean;
  icon?: 'download-left' | 'download-right' | 'email-left' | 'unset';
  disabled?: boolean;
}

const SmallButton = React.forwardRef<HTMLButtonElement, SmallButtonProps>(
  ({ icon, varient, isLoading, className, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={classnames(className, {
          [`emma-stylesheet-small-${varient}-button`]:
            (icon === 'unset' || !icon) && !isLoading,
          [`emma-stylesheet-small-${varient}-${icon}-icon-button`]:
            !!icon && icon !== 'unset',
          [`emma-stylesheet-small-${varient}-loading-icon-button`]: !!isLoading
        })}
        data-enable-ga
        data-ga-type="button"
        {...props}
      >
        {props.children}
      </button>
    );
  }
);

export const defaultProps: SmallButtonProps = {
  type: 'button',
  varient: 'default',
  icon: 'unset',
  isLoading: false,
  disabled: false
};

SmallButton.defaultProps = {
  ...defaultProps
};

export default SmallButton;
