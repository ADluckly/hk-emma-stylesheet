import SmallButton from './SmallButton';

export default SmallButton;
