import * as React from 'react';
import classnames from 'classnames';

let idx = 1;
const name = 'emma-stylesheet-radio-button-toggle-';

export type ToggleProps = {
  onChange?: (isRadio: boolean) => void;
  gaText?: string;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'>;

class Toggle extends React.Component<ToggleProps> {
  uuid = name + idx++;

  onToggleChange = () => {
    const { checked, onChange } = this.props;
    if (typeof onChange !== 'function') return;
    onChange(!checked);
  };

  render() {
    const { id, checked, className, onChange, gaText, ...elseProps } =
      this.props;

    const labelId = id || this.uuid;
    const htmlFor = typeof onChange !== 'function' ? undefined : labelId;

    return (
      <div
        className={classnames('emma-stylesheet-radio-button', className)}
        data-stylesheet="Atoms/Toggle"
      >
        <div className="switch">
          <input
            {...elseProps}
            className="emma-stylesheet-radio-button-toggle emma-stylesheet-radio-button-toggle-round"
            type="checkbox"
            onChange={() => this.onToggleChange()}
            checked={checked}
            id={labelId}
            data-enable-ga="true"
            data-ga-type="button"
            data-ga-text={gaText || 'Toggle'}
          />
          <label htmlFor={htmlFor} />
        </div>
      </div>
    );
  }
}

export default React.memo(Toggle);
