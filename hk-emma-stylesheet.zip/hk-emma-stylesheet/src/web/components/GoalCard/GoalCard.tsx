import React, { Component } from 'react';

export type GoalCardProps = {
  title: string;
  desc: string;
  iconPath: string;
  children?: React.ReactNode;
  isBoxShadow?: boolean;
};

class GoalCard extends Component<GoalCardProps> {
  static defaultProps = {
    isBoxShadow: true
  };

  constructor(props: GoalCardProps) {
    super(props);
  }

  render() {
    const { title, desc, iconPath, children, isBoxShadow } = this.props;

    return (
      <div
        className={`emma-stylesheet-goal-card ${
          isBoxShadow ? 'emma-stylesheet-goal-card-box-shadow' : ''
        }`}
      >
        <div className="emma-stylesheet-goal-card-content content-align-right">
          <div className="emma-stylesheet-goal-card-content-left">
            <div className="emma-stylesheet-goal-card-content-left-title">
              {title}
            </div>
            <div className="emma-stylesheet-goal-card-content-left-desc">
              {desc}
            </div>
          </div>
          <div className="emma-stylesheet-goal-card-content-right">
            <img src={iconPath} />
          </div>
        </div>
        {children && (
          <div className="emma-stylesheet-goal-card-footer">{children}</div>
        )}
      </div>
    );
  }
}

export default GoalCard;
