import React from 'react';

export type ImageTitleContentProps = {
  title?: React.ReactNode | string;
  content?: React.ReactNode | string;
  image?: React.ReactNode | string;
};

const ImageTitleContent: React.FC<ImageTitleContentProps> = ({
  image,
  title,
  content
}) => {
  return (
    <div className="emma-stylesheet-image-title-content">
      {image && (
        <div
          className="emma-stylesheet-image-title-content--image"
          style={{ backgroundImage: `url(${image})` }}
        />
      )}
      {title && (
        <div className="emma-stylesheet-image-title-content--title">
          {title}
        </div>
      )}
      {content && (
        <div className="emma-stylesheet-image-title-content--content">
          {content}
        </div>
      )}
    </div>
  );
};

export default ImageTitleContent;
