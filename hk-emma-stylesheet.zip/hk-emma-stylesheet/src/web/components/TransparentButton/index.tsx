import TransparentButton from './TransparentButton';

export default TransparentButton;
