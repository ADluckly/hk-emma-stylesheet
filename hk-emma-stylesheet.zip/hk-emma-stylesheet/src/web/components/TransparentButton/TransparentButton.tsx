import React, { Component } from 'react';

export type TransparentButtonProps = {
  id: string;
  iconPath: string;
  settingDesc: string;
  isShowActiveIcon: boolean;
  onMouse: (isOver: boolean) => void;
  onClick: (e: React.MouseEvent<HTMLDivElement>) => void;
};

class TransparentButton extends Component<TransparentButtonProps> {
  render() {
    const { id, iconPath, settingDesc, isShowActiveIcon, onMouse, onClick } =
      this.props;

    return (
      <div
        className={`customer-profile-setting content-align-level ${
          isShowActiveIcon ? 'customer-profile-active-setting' : ''
        }`}
        onMouseMove={() => onMouse(true)}
        onMouseOut={() => onMouse(false)}
        onClick={(e) => onClick(e)}
      >
        <div className="customer-profile-setting-icon">
          <img key={id} src={iconPath} alt={id} />
        </div>
        <div
          className={`customer-profile-setting-desc ${
            isShowActiveIcon ? 'customer-profile-setting-active-desc' : ''
          }`}
        >
          {settingDesc}
        </div>
      </div>
    );
  }
}

export default TransparentButton;
