import React, { Component } from 'react';
import { Chart, ArcElement, Tooltip } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

Chart.register(ArcElement, Tooltip);

type DonutDataType = {
  label: string;
  data: number;
};

type DonutTooltipType = {
  maxWebWidth: string;
  maxMobileWidth: string;
  background: string;
  padding: string;
  color: string;
  fontSize: string;
  fontFamily: string;
  fontWeight: string;
  lineHeight: number;
};

export type DonutChartProps = {
  donutData: DonutDataType[];
  hoverBackgroundColor: string[];
  backgroundColor: string[];
  legendDisplay: boolean;
  hoverOffset: number;
  layout: any;
  tooltipExternal: DonutTooltipType;
  unitLabel: string;
  responsive: boolean;
  width: number;
  height: number;
  maintainAspectRatio: boolean;
  cutoutPercentage: number;
  tooltip: string;
};

type DonutChartState = {
  tooltip: string;
};

class DonutChart extends Component<DonutChartProps, DonutChartState> {
  static defaultProps = {
    hoverBackgroundColor: [
      'rgba(73,77,244,1)',
      'rgba(246,170,28,1)',
      'rgba(73,118,186,1)',
      'rgba(52,163,0,1)',
      'rgba(249,199,79,1)',
      'rgba(233,114,116,1)',
      'rgba(181,208,238,1)',
      'rgba(2,113,128,1)',
      'rgba(89,149,217,1)',
      'rgba(95,95,95,1)',
    ],
    backgroundColor: [
      'rgba(73,77,244,0.9)',
      'rgba(246,170,28,0.9)',
      'rgba(73,118,186,0.9)',
      'rgba(52,163,0,0.9)',
      'rgba(249,199,79,0.9)',
      'rgba(233,114,116,0.9)',
      'rgba(181,208,238,0.9)',
      'rgba(2,113,128,0.9)',
      'rgba(89,149,217,0.9)',
      'rgba(95,95,95,0.9)',
    ],
    legendDisplay: false,
    tooltipExternal: {
      maxWebWidth: '400px',
      maxMobileWidth: '150px',
      background: 'rgba(51, 51, 51, 0.8)',
      padding: '8px',
      color: '#FFFFFF',
      fontSize: '12px',
      fontFamily: 'Source Sans Pro',
      fontWeight: 'normal',
      lineHeight: 1.2,
    },
    hoverOffset: 4,
    layout: {
      padding: 20,
    },
    unitLabel: 'HKD',
    // whenn responsive is true,the chart is responsive
    responsive: false,
    // when maintainAspectRatio is false,the width and height is enable
    width: 400,
    height: 400,
    maintainAspectRatio: false,
    cutoutPercentage: 65,
  };

  constructor(props: DonutChartProps) {
    super(props);
    this.state = {
      tooltip: this.props.tooltip,
    };
  }

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: DonutChartProps) {
    if (nextProps.tooltip !== this.props.tooltip) {
      this.setState({
        tooltip: nextProps.tooltip,
      });
    }
  }

  componentWillUnmount() {
    const tooltip = document.getElementById('chartjs-tooltip');
    tooltip && tooltip.remove && tooltip.remove();
  }

  render() {
    const {
      donutData,
      hoverBackgroundColor,
      backgroundColor,
      legendDisplay,
      hoverOffset,
      layout,
      tooltipExternal,
      unitLabel,
      responsive,
      width,
      height,
      maintainAspectRatio,
      cutoutPercentage,
    } = this.props;
    const {
      maxWebWidth,
      maxMobileWidth,
      background,
      padding,
      color,
      fontSize,
      fontFamily,
      fontWeight,
      lineHeight,
    } = tooltipExternal;
    // const dataSetData = donutData
    //   ? donutData.sort((a, b) => b.data - a.data)
    //   : [];
    const dataSetData = donutData || [];
    const paramLabels = dataSetData
      ? dataSetData.map((item) => item.label)
      : [];
    const paramDatas = dataSetData ? dataSetData.map((item) => item.data) : [];
    const data = {
      datasets: [
        {
          labels: paramLabels,
          data: paramDatas,
          hoverBackgroundColor: hoverBackgroundColor,
          backgroundColor: backgroundColor,
          hoverOffset: hoverOffset,
        },
      ],
    };
    return (
      <div>
        {dataSetData && (
          <Doughnut
            data={data}
            width={width}
            height={height}
            options={{
              responsive: responsive,
              maintainAspectRatio: maintainAspectRatio,
              plugins: {
                tooltip: {
                  callbacks: {
                    // @ts-ignore
                    label: function (tooltipItem: TooltipItem) {
                      // console.log(tooltipItem);

                      const index = tooltipItem.dataIndex;

                      const labels = tooltipItem.dataset.labels || [];

                      const data = tooltipItem.dataset.data || [];

                      const label = labels[index] || '';
                      const dataValue = data[index] || '';

                      const formattedValue = dataValue
                        ? `${unitLabel} ${dataValue}`
                        : '';

                      return [label, formattedValue];
                    },
                    // @ts-ignore
                    labelColor: function (tooltipItem) {
                      // console.log(tooltipItem);

                      const index = tooltipItem.dataIndex;

                      const backgroundColors =
                        tooltipItem.dataset.backgroundColor;
                      const hoverBackgroundColors =
                        tooltipItem.dataset.hoverBorderColor;

                      const bgColor =
                        //@ts-ignore
                        hoverBackgroundColors?.[index] ||
                        //@ts-ignore
                        backgroundColors?.[index] ||
                        '';

                      return {
                        backgroundColor: bgColor,
                      };
                    },
                  },
                  // Disable the on-canvas tooltip
                  enabled: false,

                  external: function (context: any) {
                    const tooltipModel = context.tooltip;

                    // Tooltip Element
                    let tooltipEl = document.getElementById('chartjs-tooltip');
                    // `this` will be the overall tooltip
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    const position = this._chart.canvas.getBoundingClientRect();
                    // Create element on first render
                    if (!tooltipEl) {
                      tooltipEl = document.createElement('div');
                      tooltipEl.style.display = 'block';
                      tooltipEl.style.maxWidth = maxWebWidth;
                      if (position.width <= 300) {
                        tooltipEl.style.maxWidth = maxMobileWidth;
                      }
                      tooltipEl.style.background = background;
                      tooltipEl.style.padding = padding;
                      tooltipEl.style.color = color;
                      tooltipEl.style.position = 'absolute';
                      tooltipEl.id = 'chartjs-tooltip';
                      // eslint-disable-next-line
                      tooltipEl.innerHTML = `<div style='width:100%'></div>`;
                      document.body.appendChild(tooltipEl);
                    }

                    // Hide if no tooltip
                    if (tooltipModel.opacity === 0) {
                      tooltipEl.style.opacity = '0';
                      return;
                    }

                    // Set caret Position
                    tooltipEl.classList.remove(
                      'above',
                      'below',
                      'no-transform'
                    );
                    if (tooltipModel.yAlign) {
                      tooltipEl.classList.add(tooltipModel.yAlign);
                    } else {
                      tooltipEl.classList.add('no-transform');
                    }

                    function getBody(bodyItem: any) {
                      return bodyItem.lines;
                    }

                    // Set Text
                    if (tooltipModel.body) {
                      const titleLines = tooltipModel.title || [];
                      const bodyLines = tooltipModel.body.map(getBody);
                      let innerHtml = '';
                      bodyLines.forEach(function (body: any, i: number) {
                        const colors = tooltipModel.labelColors[i];
                        let style = 'background:' + colors.backgroundColor;
                        style +=
                          '; border: solid 1.2px #ffffff; border-radius:50%; width:12px; height:12px; display:inline-block;margin-right:8px;margin-top:3px';
                        const span = '<span style="' + style + '"></span>';
                        let content = '';
                        body.forEach((text: string) => {
                          content += text + '<br/>';
                        });
                        innerHtml += `<div style='display: flex !important;flex-direction: row;'><div>${span}</div><div'>${content}</div></div>`;
                      });

                      const tableRoot = tooltipEl.querySelector('div');
                      if (tableRoot) {
                        tableRoot.innerHTML = innerHtml;
                      }
                    }

                    // Display, position, and set styles for font
                    tooltipEl.style.opacity = '1';
                    tooltipEl.style.position = 'absolute';
                    tooltipEl.style.left =
                      position.left +
                      window.pageXOffset +
                      tooltipModel.caretX -
                      30 +
                      'px';
                    tooltipEl.style.top =
                      position.top +
                      window.pageYOffset +
                      tooltipModel.caretY +
                      'px';
                    tooltipEl.style.fontFamily = fontFamily;
                    tooltipEl.style.fontSize = fontSize;
                    tooltipEl.style.lineHeight = lineHeight.toString();
                    tooltipEl.style.fontStyle = tooltipModel._bodyFontStyle;
                    tooltipEl.style.padding =
                      tooltipModel.yPadding +
                      'px ' +
                      tooltipModel.xPadding +
                      'px';
                    tooltipEl.style.pointerEvents = 'none';
                  },
                },
              },
              layout,
              cutoutPercentage: cutoutPercentage,
            }}
          />
        )}
      </div>
    );
  }
}

export default DonutChart;
