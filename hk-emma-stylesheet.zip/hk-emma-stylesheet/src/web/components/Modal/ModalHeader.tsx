import React, { Component } from 'react';

export type ModalHeaderProps = {
  children?: React.ReactNode;
  onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
  className?: string;
};

class ModalHeader extends Component<ModalHeaderProps> {
  static defaultProps = {
    children: 'This the title of modal.',
  };

  render() {
    const { children, onClick, className } = this.props;
    return (
      <div
        className={`emma-stylesheet-modal-header ${className ? className : ''}`}
        onClick={onClick}
      >
        <div className="emma-stylesheet-modal-header__title">{children}</div>
      </div>
    );
  }
}

export default ModalHeader;
