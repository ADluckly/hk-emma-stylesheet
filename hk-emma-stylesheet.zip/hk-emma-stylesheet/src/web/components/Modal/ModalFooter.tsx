import React, { Component } from 'react';

export type ModalFooterProps = {
  children?: React.ReactNode;
  onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
  className?: string;
  wrapperClassName?: string;
};

class ModalFooter extends Component<ModalFooterProps> {
  static defaultProps = {
    children: null,
  };

  render() {
    const { children, onClick, className, wrapperClassName } = this.props;
    return (
      <div
        className={`emma-stylesheet-modal-footer ${className ? className : ''}`}
        onClick={onClick}
      >
        <div
          className={`emma-stylesheet-modal-footer__wrapper ${
            wrapperClassName ? wrapperClassName : ''
          }`}
        >
          {children}
        </div>
      </div>
    );
  }
}

export default ModalFooter;
