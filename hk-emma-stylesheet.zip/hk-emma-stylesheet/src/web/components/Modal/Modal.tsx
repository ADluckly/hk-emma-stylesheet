import React, { Component } from 'react';

export type ModalProps = {
  show?: boolean;
  children?: React.ReactNode;
  onHide?: (event: React.MouseEvent<HTMLDivElement>) => void;
  type?: string;
  zIndex?: number;
  onClick?: () => void;
  className?: string;
};

export type ModalState = {
  show: boolean;
  type: string;
};

class Modal extends Component<ModalProps, ModalState> {
  static defaultProps = {
    show: false,
    type: 'default',
  };

  render() {
    const { show, children, type, zIndex, className, onHide } = this.props;
    /** VERY IMPORTANT: Please search and scan the code of css class name before restructure existing component. 
     * Because there is a defect HKEMMA-67219 that caused by restructure.
     */
    return (
      <div className="emma-stylesheet-modal">
        <div
          className="emma-stylesheet-modal-overlay"
          hidden={!show}
          style={{ zIndex: zIndex }}
          onClick={onHide}
        />
        {!!show && (
          <div
            className={
              type === 'emma'
                ? `emma-stylesheet-modal-container-emma ${!!className && className}`
                : `emma-stylesheet-modal-container ${!!className && className}`
            }
          >
            {children}
          </div>
        )}
      </div>
    );
  }
}

export default Modal;
