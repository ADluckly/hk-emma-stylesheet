import React, { Component } from 'react';

export type ModalBodyProps = {
  children?: React.ReactNode;
  onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
  className?: string;
};

class ModalBody extends Component<ModalBodyProps> {
  static defaultProps = {
    children: 'This the content of modal.',
  };

  render() {
    const { children, onClick, className } = this.props;
    return (
      <div
        className={`emma-stylesheet-modal-body ${className ? className : ''}`}
        onClick={onClick}
      >
        {children}
      </div>
    );
  }
}

export default ModalBody;
