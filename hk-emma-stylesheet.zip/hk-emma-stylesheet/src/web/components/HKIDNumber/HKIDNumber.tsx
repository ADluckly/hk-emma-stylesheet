import React, { Component } from 'react';
import { validateFormatInput, validateHKid } from '../../common/common';

type ErrorMessage = {
  errorHKIDEmptyMessage: string;
  errorcheckDigitEmptyMessage: string;
  errorHKIDMessage: string;
  errorcheckDigitMessage: string;
};

type HKIDPlaceHolder = {
  hkidPlaceholder: string;
  checkDigitPlaceholder: string;
};

export type HKIDNumberProps = {
  hkidValue?: string;
  checkDigitValue?: string;
  isValidateInitValue?: boolean;
  onHandleValidateInitValue?: (value: any) => void;
  errorMessage?: ErrorMessage;
  placeholder?: HKIDPlaceHolder;
  onChange: (value: any) => void;
  onBlur?: () => void;
  onFocus?: () => void;
};

type HKIDNumberState = {
  hkidStateValue?: string;
  checkDigitStateValue?: string;
  isHkidError?: boolean;
  isHkidCorrect?: boolean;
  isCheckDigitError?: boolean;
  isCheckDigitCorrect?: boolean;
  errorHKIDMessage?: string;
  errorcheckDigitMessage?: string;
};

class HKIDNumber extends Component<HKIDNumberProps, HKIDNumberState> {
  static defaultProps = {
    placeholder: {
      hkidPlaceholder: 'Enter HKID',
      checkDigitPlaceholder: '-',
    },
    errorMessage: {
      errorHKIDEmptyMessage: 'Field cannot be empty',
      errorcheckDigitEmptyMessage: 'Field cannot be empty',
      errorHKIDMessage: 'HKID format is not correct',
      errorcheckDigitMessage: 'Format is not correct',
    },
    isValidateInitValue: false,
  };

  constructor(props: HKIDNumberProps) {
    super(props);
    this.state = {
      hkidStateValue: this.props.hkidValue ? this.props.hkidValue : '',
      checkDigitStateValue: this.props.checkDigitValue
        ? this.props.checkDigitValue
        : '',
      isHkidError: false,
      isHkidCorrect: false,
      isCheckDigitError: false,
      isCheckDigitCorrect: false,
      errorHKIDMessage: '',
      errorcheckDigitMessage: '',
    };
  }

  componentDidMount() {
    // when user want to init data and validate value
    if (this.props.isValidateInitValue) {
      this.initValidateData(
        this.props.hkidValue,
        this.props.checkDigitValue,
        true
      );
    }
  }

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: HKIDNumberProps) {
    if (nextProps.hkidValue !== this.props.hkidValue) {
      this.setState({
        hkidStateValue: nextProps.hkidValue,
      });
    }
    if (nextProps.checkDigitValue !== this.props.checkDigitValue) {
      this.setState({
        checkDigitStateValue: nextProps.checkDigitValue,
      });
    }
    // for asyn update isValidateInitValue
    if (nextProps.isValidateInitValue !== this.props.isValidateInitValue) {
      this.initValidateData(
        nextProps.hkidValue,
        nextProps.checkDigitValue,
        true
      );
    }
  }

  initValidateData(
    hkidValue?: string,
    checkDigitValue?: string,
    isHKid = true
  ) {
    this.setState({
      hkidStateValue: hkidValue,
      checkDigitStateValue: checkDigitValue,
    });
    const returnValue = this.checkValidation(
      hkidValue,
      checkDigitValue,
      isHKid
    );
    this.props.onHandleValidateInitValue &&
      this.props.onHandleValidateInitValue(returnValue);
  }

  checkHKIDRule = (value?: string, errorMsg?: string) => {
    // check hkid rule
    let returnData = {
      errorMessage: '',
      isError: false,
      isCorrect: false,
    };
    if (!validateFormatInput(value, /^(?! )[a-zA-Z0-9_ ]*$/, null, 7, 8)) {
      returnData = {
        errorMessage: errorMsg || '',
        isError: true,
        isCorrect: false,
      };
    } else {
      returnData = {
        errorMessage: '',
        isError: false,
        isCorrect: true,
      };
    }
    return returnData;
  };

  checkDigitRule = (value?: string, errorMsg?: string) => {
    // check hkid rule
    let returnData = {
      errorMessage: '',
      isError: false,
      isCorrect: false,
    };
    if (!validateFormatInput(value, /^[A0-9]*$/, null, 1, 1)) {
      returnData = {
        errorMessage: errorMsg || '',
        isError: true,
        isCorrect: false,
      };
    } else {
      returnData = {
        errorMessage: '',
        isError: false,
        isCorrect: true,
      };
    }
    return returnData;
  };

  checkValidation = (hkid?: string, digit?: string, isHkid?: boolean) => {
    const { errorMessage } = this.props;
    let {
      errorHKIDMessage,
      errorcheckDigitMessage,
      isHkidError,
      isHkidCorrect,
      isCheckDigitError,
      isCheckDigitCorrect,
    } = this.state;

    // when hkid or digit is empty rule start
    if (!hkid) {
      // check hkid empty
      errorHKIDMessage = errorMessage?.errorHKIDEmptyMessage;
      isHkidError = true;
      isHkidCorrect = false;
    } 
    if (!digit) {
      // check digit empty
      errorcheckDigitMessage = errorMessage?.errorcheckDigitEmptyMessage;
      isCheckDigitError = true;
      isCheckDigitCorrect = false;
    } 
    // check hkid and digit rule
    // checkArr[0] check hkid
    // checkArr[1] check digit
    const checkArr = validateHKid(hkid || '', digit || '')
    console.log(checkArr, 'checkArr')
    if (!checkArr[0]) {
      if(hkid) {
        errorHKIDMessage = errorMessage?.errorHKIDMessage;
        isHkidError = true;
        isHkidCorrect = false;
      }
      if(digit) {
        isCheckDigitError = false;
        isCheckDigitCorrect = false;
        errorcheckDigitMessage = '';
      }
    } else if (!checkArr[1]) {
      errorcheckDigitMessage = errorMessage?.errorcheckDigitMessage;
      errorHKIDMessage = ''
      isHkidError = false;
      isHkidCorrect = true;
      isCheckDigitError = true;
      isCheckDigitCorrect = false;
    } else {
      errorHKIDMessage = '';
      errorcheckDigitMessage = '';
      isHkidError = false;
      isHkidCorrect = true;
      isCheckDigitError = false;
      isCheckDigitCorrect = true;
    }
    // when hkid and digit is not empty rule end
    this.setState({
      errorHKIDMessage: errorHKIDMessage,
      isHkidError,
      isHkidCorrect,
      errorcheckDigitMessage: errorcheckDigitMessage,
      isCheckDigitError,
      isCheckDigitCorrect,
    });
    return {
      hkidValue: hkid,
      checkDigitValue: digit,
      isCorrect: isHkidCorrect && isCheckDigitCorrect,
    };
  };

  // HKID
  onInputHKID = (
    e: React.FocusEvent<HTMLInputElement> | React.ChangeEvent<HTMLInputElement>
  ) => {
    const targeValue = e.target.value.toUpperCase();
    this.setState({
      hkidStateValue: targeValue,
    });
    const { checkDigitStateValue } = this.state;
    // route to same checking
    return this.checkValidation(targeValue, checkDigitStateValue, true);
  };

  onHKIDChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const returnValue = this.onInputHKID(e);
    this.props.onChange && this.props.onChange(returnValue);
  };

  onHKIDBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const returnValue = this.onInputHKID(e);
    this.props.onChange && this.props.onChange(returnValue);
  };

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  onHKIDFocus = (e: React.FocusEvent<HTMLInputElement>) => {};

  // Check Digit
  onInputCheckDigit = (
    e: React.FocusEvent<HTMLInputElement> | React.ChangeEvent<HTMLInputElement>
  ) => {
    const targeValue = e.target.value;
    this.setState({
      checkDigitStateValue: targeValue,
    });
    const { hkidStateValue } = this.state;
    // route to same checking
    return this.checkValidation(hkidStateValue, targeValue, false);
  };

  onCheckDigitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const returnValue = this.onInputCheckDigit(e);
    this.props.onChange && this.props.onChange(returnValue);
  };

  onCheckDigitBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const returnValue = this.onInputCheckDigit(e);
    this.props.onChange && this.props.onChange(returnValue);
  };

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  onCheckDigitFocus = (e: React.FocusEvent<HTMLInputElement>) => {};

  getStatusClassName(isError: boolean, isCorrect: boolean) {
    const childrenClassName = {
      childrenSubClassName: 'emma-stylesheet-input',
      inputClassName: 'emma-stylesheet-input-field',
    };
    childrenClassName.childrenSubClassName = isError
      ? 'emma-stylesheet-input-error'
      : childrenClassName.childrenSubClassName;
    childrenClassName.childrenSubClassName = isCorrect
      ? 'emma-stylesheet-input-success'
      : childrenClassName.childrenSubClassName;
    childrenClassName.inputClassName = isError
      ? 'emma-stylesheet-input-error-field'
      : childrenClassName.inputClassName;
    childrenClassName.inputClassName = isCorrect
      ? 'emma-stylesheet-input-success-field'
      : childrenClassName.inputClassName;
    return childrenClassName;
  }

  render() {
    const { placeholder, hkidValue, checkDigitValue } = this.props;

    const { hkidPlaceholder, checkDigitPlaceholder } = placeholder || {};

    const {
      isHkidError,
      isHkidCorrect,
      isCheckDigitError,
      isCheckDigitCorrect,
      errorHKIDMessage,
      errorcheckDigitMessage,
    } = this.state;

    const statusHkidClassName = this.getStatusClassName(
      !!isHkidError,
      !!isHkidCorrect
    );
    const statusCheckDigitClassName = this.getStatusClassName(
      !!isCheckDigitError,
      !!isCheckDigitCorrect
    );

    return (
      <div className="emma-stylesheet-hkid-number">
        <div className="row emma-stylesheet-hkid-number-level">
          <div className={'hkid'}>
            <div className={`${statusHkidClassName.childrenSubClassName}`}>
              <input
                type="hkid"
                autoComplete="off"
                value={hkidValue}
                className={`hkid-input ${statusHkidClassName.inputClassName}`}
                placeholder={hkidPlaceholder}
                maxLength={8}
                onBlur={(e) => this.onHKIDBlur(e)}
                onFocus={(e) => this.onHKIDFocus(e)}
                onChange={(e) => this.onHKIDChange(e)}
              />
            </div>
            <div className="row">
              <div className="col-12 content-align-right">
                {isHkidError && errorHKIDMessage ? (
                  <div className="input-mandatoryText-container">
                    <span className="emma-stylesheet-input-tip-error">
                      {errorHKIDMessage}
                    </span>
                  </div>
                ) : (
                  <div />
                )}
              </div>
            </div>
          </div>
          <div className="check-digit">
            <div className="content-align-right">
              <div className="check-digit__cert-left-no-label">(</div>
              <div
                className={`${statusCheckDigitClassName.childrenSubClassName}`}
              >
                <input
                  type="checkDigit"
                  autoComplete="off"
                  value={checkDigitValue}
                  className={`check-digit-input ${statusCheckDigitClassName.inputClassName}`}
                  placeholder={checkDigitPlaceholder}
                  maxLength={1}
                  onBlur={(e) => this.onCheckDigitBlur(e)}
                  onFocus={(e) => this.onCheckDigitFocus(e)}
                  onChange={(e) => this.onCheckDigitChange(e)}
                />
              </div>
              <div className="check-digit__cert-right-no-label">)</div>
            </div>
            <div className="row">
              <div className="col-12 content-align-right">
                {isCheckDigitError && errorcheckDigitMessage ? (
                  <div className="input-mandatoryText-container">
                    <span className="emma-stylesheet-input-tip-error">
                      {errorcheckDigitMessage}
                    </span>
                  </div>
                ) : (
                  <div />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default HKIDNumber;
