import React from 'react';
import PropTypes from 'prop-types';

export type SearchInputProps = {
  id?: string;
  label?: string;
  placeholder?: string;
  value?: string;
  isReadOnly?: boolean;
  isDisabled?: boolean;
  isShowError?: boolean;
  errorMsg?: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onFocus?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onKeyDown?: (e: any) => void;
  childrenClassName?: string;
  inputClassName?: string;
};

type SearchInputState = {
  showSearchInput: boolean;
  inputOnFocus: boolean;
  searchInputValue: string;
  isShowError: boolean;
};

class SearchInput extends React.Component<SearchInputProps, SearchInputState> {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    isReadOnly: PropTypes.bool,
    isDisabled: PropTypes.bool,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    onFocus: PropTypes.func,
    childrenClassName: PropTypes.string,
    inputClassName: PropTypes.string
  };

  static defaultProps = {
    placeholder: 'Enter SearchInput',
    isReadOnly: false,
    isDisabled: false,
    isShowError: false,
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onChange: () => { }
  };

  constructor(props: SearchInputProps) {
    super(props);
    this.state = {
      showSearchInput: false,
      inputOnFocus: false,
      searchInputValue: this.props.value ? this.props.value : '',
      isShowError: this.props.isShowError ? this.props.isShowError : false
    };
    this.searchInputOnChange = this.searchInputOnChange.bind(this);
    this.searchInputOnFocus = this.searchInputOnFocus.bind(this);
    this.searchInputOnBlur = this.searchInputOnBlur.bind(this);
  }

  componentWillReceiveProps(nextProps: any) {
    if (nextProps.value !== this.props.value) {
      this.setState({
        searchInputValue: nextProps.value
      });
    }
    if (nextProps.isShowError !== this.props.isShowError) {
      this.setState({
        isShowError: nextProps.isShowError
      });
    }
  }

  searchInputOnChange(e: React.ChangeEvent<HTMLInputElement>) {
    let inputOnFocus = false;
    if (e && e.target && e.target.value) {
      inputOnFocus = true;
    }
    const searchInputValue = e.target.value;
    e.persist();
    this.setState(
      {
        inputOnFocus: inputOnFocus,
        searchInputValue
      },
      () => {
        this.props.onChange(e);
      }
    );
  }

  searchInputOnFocus(e: React.ChangeEvent<HTMLInputElement>) {
    const { onFocus } = this.props;
    const searchInputValue = e.target.value;
    e.persist();
    this.setState(
      {
        inputOnFocus: true,
        searchInputValue
      },
      () => {
        onFocus && onFocus(e);
      }
    );
  }

  searchInputOnBlur(e: React.ChangeEvent<HTMLInputElement>) {
    const { onBlur } = this.props;
    const searchInputValue = e.target.value;
    e.persist();
    this.setState(
      {
        inputOnFocus: false,
        searchInputValue
      },
      () => {
        onBlur && onBlur(e);
      }
    );
  }

  searchInputOnKeyDown = (e: any) => {
    const { onKeyDown } = this.props;
    onKeyDown && onKeyDown(e);
  }

  render() {
    const {
      label,
      placeholder,
      isReadOnly,
      isDisabled,
      childrenClassName,
      inputClassName,
      id,
      errorMsg
    } = this.props;
    const { inputOnFocus, searchInputValue, isShowError } = this.state;
    let searchInputDivClass = inputOnFocus
      ? 'emma-stylesheet-input-search-right-selected'
      : 'emma-stylesheet-input-search-right';
    let searchInputFieldClass = inputOnFocus
      ? 'emma-stylesheet-input-search-right-selected-field'
      : 'emma-stylesheet-input-search-right-field';
    searchInputDivClass = isShowError
      ? 'emma-stylesheet-input-search-right-error'
      : searchInputDivClass;
    searchInputFieldClass = isShowError
      ? 'emma-stylesheet-input-search-right-error-field'
      : searchInputFieldClass;
    return (
      <div
        className={`emma-stylesheet-searchInput ${childrenClassName ? childrenClassName : ''
          }`}
      >
        {!!label && (
          <div className="row">
            <div className="emma-stylesheet-label">
              <label className="emma-stylesheet-label__text">{label}</label>
            </div>
          </div>
        )}
        <div className="row">
          <div className={`${searchInputDivClass} col-12`}>
            <input
              id={id}
              className={`${searchInputFieldClass} ${inputClassName ? inputClassName : ''
                }`}
              value={searchInputValue}
              type="text"
              size={255}
              placeholder={placeholder}
              disabled={isDisabled}
              readOnly={isReadOnly}
              onChange={this.searchInputOnChange}
              onFocus={this.searchInputOnFocus}
              onBlur={this.searchInputOnBlur}
              onKeyDown={this.searchInputOnKeyDown}
            />
          </div>
        </div>
        {!!isShowError && (
          <div className="row">
            <div className="emma-stylesheet-searchInput-error">
              <label className="emma-stylesheet-searchInput-error__text">
                {errorMsg}
              </label>
            </div>
          </div>
        )}
      </div>
    );
  }
}
export default SearchInput;
