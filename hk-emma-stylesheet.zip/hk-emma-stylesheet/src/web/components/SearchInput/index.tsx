import SearchInput from './SearchInput';

export default SearchInput;
