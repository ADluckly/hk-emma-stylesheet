import React, { Component } from 'react';
import IconEyeCloseBlue from '../../icons/IconTooltipBlue';

type ContextualHelpProps = {
  label: string;
  placeholder: string;
  isReadOnly: boolean;
  isDisabled: boolean;
  desc: string;
  tipClassName: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  inputClassName: string;
};

type ContextualHelpState = {
  isToolTipShow?: boolean;
};

class ContextualHelp extends Component<
  ContextualHelpProps,
  ContextualHelpState
> {
  static defaultProps = {
    label: 'Label',
    placeholder: 'Placeholder Text',
    isReadOnly: false,
    isDisabled: false,
    desc: '',
    tipClassName: '',
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
      console.log(e);
    },
  };

  constructor(props: ContextualHelpProps) {
    super(props);
    this.state = { isToolTipShow: false };

    this.onContentChange = this.onContentChange.bind(this);
    this.onToolTipDisplay = this.onToolTipDisplay.bind(this);
  }

  onContentChange(e: React.ChangeEvent<HTMLInputElement>) {
    !!this.props.onChange && this.props.onChange(e);
  }

  onToolTipDisplay() {
    this.setState({
      isToolTipShow: !this.state.isToolTipShow,
    });
  }

  render() {
    const {
      label,
      placeholder,
      isReadOnly,
      isDisabled,
      desc,
      tipClassName,
      inputClassName,
    } = this.props;
    const { isToolTipShow } = this.state;

    return (
      <div className="emma-stylesheet-contextual-help-container">
        <div className="emma-stylesheet-contextual-help-label">
          <div className="emma-stylesheet-contextual-help-label__content">
            <label className="emma-stylesheet-contextual-help-label__text">
              {label}
            </label>
            <div
              className="emma-stylesheet-contextual-help-label__icon"
              onClick={this.onToolTipDisplay}
            >
              <IconEyeCloseBlue />
            </div>
          </div>
          <div className="emma-stylesheet-contextual-help-label__tip">
            <div
              className={`${tipClassName ? tipClassName : 'tool-tip-white'}`}
              hidden={!isToolTipShow}
            >
              <div
                className={`${
                  tipClassName ? tipClassName : 'tool-tip-white'
                }__desc`}
              >
                {desc}
              </div>
            </div>
          </div>
        </div>
        <div className="emma-stylesheet-contextual-help-input">
          <input
            id={label}
            className={`emma-stylesheet-contextual-help-input__content ${
              inputClassName ? inputClassName : ''
            }`}
            type="text"
            placeholder={placeholder}
            disabled={isDisabled}
            readOnly={isReadOnly}
            onChange={this.onContentChange}
          />
        </div>
      </div>
    );
  }
}

export default ContextualHelp;
