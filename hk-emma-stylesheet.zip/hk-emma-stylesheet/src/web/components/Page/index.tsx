import GeneralErrorPage from './GeneralErrorPage';

export { GeneralErrorPage };
