import React, { Component } from 'react';

export type GeneralErrorPageProps = {
  title?: string;
  descChildren?: React.ReactNode;
  buttonChildren?: React.ReactNode;
};

class GeneralErrorPage extends Component<GeneralErrorPageProps> {
  constructor(props: GeneralErrorPageProps) {
    super(props);
  }

  render() {
    const {
      title,
      descChildren,
      buttonChildren,
    } = this.props;

    return (
      <div className="emma-stylesheet-page-general-error">
        {!!title && <div className="emma-stylesheet-page-general-error-title">
          {title}
        </div>}
        {!!descChildren && <div className="emma-stylesheet-page-general-error-sub-desc">
          {descChildren}
        </div>}
        {!!buttonChildren && <div className="emma-stylesheet-page-general-error-button">
          {buttonChildren}
        </div>}
      </div>
    );
  }
}

export default GeneralErrorPage;
