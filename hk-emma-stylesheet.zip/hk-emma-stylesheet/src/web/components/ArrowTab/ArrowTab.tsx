import React, { Component } from 'react';
import IconArrowLeft from '../../icons/IconArrowLeft';
import IconArrowRight from '../../icons/IconArrowRight';

export type SwitchTabProps = {
  currentTab: string;
  currentTabIndex: number;
};

type ArrowTabProps = {
  tabList: string[];
  onSwitchTab: (props: SwitchTabProps) => void;
  value: string;
};

type ArrowTabState = {
  currentTabIndex: number;
  currentTab: string;
  leftArrow: boolean;
  rightArrow: boolean;
};

class ArrowTab extends Component<ArrowTabProps, ArrowTabState> {
  static defaultProps = {
    tabList: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'],
  };

  scrollRef!: Element;

  constructor(props: ArrowTabProps) {
    super(props);
    this.state = {
      currentTabIndex: 0,
      currentTab: '',
      leftArrow: false,
      rightArrow: false,
    };
    this.onSwitchTab = this.onSwitchTab.bind(this);
  }

  componentDidMount() {
    const { tabList, value } = this.props;
    this.initTab(tabList, value);
  }

  initTab = (tabList: string[], value: string) => {
    const currentTabIndex = value ? tabList.indexOf(value) : 0;
    const currentTab = value ? value : tabList[0];
    const leftArrow = false;
    const rightArrow = tabList.length > 3;
    this.setState({
      currentTabIndex,
      currentTab,
      leftArrow,
      rightArrow,
    });
  };

  // eslint-disable-next-line react/no-deprecated
  componentWillReceiveProps(nextProps: ArrowTabProps): void {
    if (nextProps.tabList !== this.props.tabList || nextProps.value !== this.props.value) {
      this.initTab(nextProps.tabList, nextProps.value);
    }
  }

  onSwitchTab(event: React.MouseEvent<HTMLDivElement>): void {
    const { tabList, onSwitchTab } = this.props;
    const input = event.target as HTMLElement;

    const currentTabIndex = tabList.findIndex((t) => t === input.innerHTML);
    if (currentTabIndex > -1) {
      const obj = {
        currentTab: input.innerHTML,
        currentTabIndex,
      } as SwitchTabProps;
      this.setState(obj);
      onSwitchTab && onSwitchTab(obj);
    }
  }

  onScrollHandle = (): void => {
    const { scrollLeft, scrollWidth, clientWidth } = this.scrollRef;
    const bottom = scrollWidth - clientWidth;

    if (scrollLeft === 0) {
      this.setState({
        leftArrow: false,
        rightArrow: true,
      });
      return;
    }

    if (scrollLeft > 0 && scrollLeft < bottom) {
      this.setState({
        leftArrow: true,
        rightArrow: true,
      });
    }

    if (scrollLeft === bottom) {
      this.setState({
        leftArrow: true,
        rightArrow: false,
      });
    }
  };

  render() {
    const { tabList } = this.props;
    const { currentTab, leftArrow, rightArrow } = this.state;

    return (
      <div className="content-align-right">
        {leftArrow ? (
          <IconArrowRight />
        ) : (
          <div className="emma-stylesheet-tab-arrow" />
        )}
        <div
          className="emma-stylesheet-tabs"
          onClick={(e) => this.onSwitchTab(e)}
          ref={(c: HTMLDivElement) => {
            this.scrollRef = c;
          }}
          onScrollCapture={() => this.onScrollHandle()}
        >
          {tabList.map((item) => (
            <li
              key={item}
              className={`emma-stylesheet-arrow-tab ${
                item === currentTab ? 'emma-stylesheet-tab--active' : ''
              }`}
              data-enable-ga
              data-ga-type="tab"
            >
              {item}
            </li>
          ))}
        </div>
        {rightArrow ? (
          <IconArrowLeft />
        ) : (
          <div className="emma-stylesheet-tab-arrow" />
        )}
      </div>
    );
  }
}

export default ArrowTab;
