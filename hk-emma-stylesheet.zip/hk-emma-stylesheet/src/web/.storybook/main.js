const path = require('path');

module.exports = {
  "stories": [
    "../stories/**/*.stories.mdx",
    "../stories/**/*.stories.@(js|jsx|ts|tsx)"
  ],
  "addons": [
    "@storybook/addon-links",
    "@storybook/addon-essentials",
    "storybook-zeplin/register",
    {
      name: '@storybook/preset-scss',
      options: {
        cssLoaderOptions: {
          modules: {
            mode: "global",
            localIdentName: "[local]-[hash:base64:8]",
          }
        }
      }
    },
  ],
  webpackFinal: (config) => {
    const TsconfigPathsPlugin = require("tsconfig-paths-webpack-plugin");

    config.resolve.plugins = [
      ...(config.resolve.plugins || []),
      new TsconfigPathsPlugin({
        configFile: path.resolve(__dirname, "../../../tsconfig.json"),
      }),
    ];
    return config;
  }
}