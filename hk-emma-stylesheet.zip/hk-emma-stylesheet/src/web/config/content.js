export const PrimaryButtonContent = {
  title: 'Primary Button',
  subTitle: 'Sub Primary Button',
  description: 'Description'
};
export const SecondaryButtonContent = {
  title: 'Secondary Button',
  subTitle: 'Sub Secondary Button',
  description: 'Description'
};
export const WhiteButtonContent = {
  title: 'White Button',
  subTitle: 'Sub White Button',
  description: 'Description'
};
export const TabContent = {
  title: 'Tab',
  subTitle: 'Tab',
  description: 'Description'
};
export const ArrowTabContent = {
  title: 'ArrowTab',
  subTitle: 'ArrowTab',
  description: 'Description'
};
export const ListCellContent = {
  title: 'ListCell',
  subTitle: 'ListCell',
  description: 'Description'
};
export const ListTableContent = {
  title: 'ListTable',
  subTitle: 'ListTable',
  description: 'Description'
};
export const PrimaryGhostButtonContent = {
  title: 'Primary Ghost Button',
  subTitle: 'Sub Primary Mobile Button',
  description: 'Description'
};

export const SecondaryGhostButtonContent = {
  title: 'Secondary Ghost Button',
  subTitle: 'Sub Secondary Ghost Button',
  description: 'Description'
};

export const StepContent = {
  title: 'Step',
  subTitle: 'Step component',
  description: 'The step component is mainly for showing the step text'
};

export const CheckboxContent = {
  title: 'Checkbox',
  subTitle: 'Sub Checkbox',
  description: 'Description'
};
export const ModalContent = {
  title: 'Modal',
  subTitle: 'Sub Modal',
  description: 'Description'
};
export const EmmaModalContent = {
  title: 'Emma Modal UI',
  subTitle: 'Sub Emma Modal UI',
  description: 'Description'
};

export const RadioButtonContent = {
  title: 'Radio Button',
  subTitle: 'Sub Radio Button',
  description: 'Description'
};

export const DateOfBirthContent = {
  title: 'Date Of Birth',
  subTitle: 'Sub Date Of Birth UI',
  description: 'Description'
};

export const DropdownListContent = {
  title: 'Dropdown List',
  subTitle: 'Sub Dropdown List',
  description: 'Description'
};

export const StateInputContent = {
  title: 'State Input',
  subTitle: 'Sub State Input',
  description: 'Description'
};

export const PasswordInputContent = {
  title: 'Password Input',
  subTitle: 'Sub Password Input',
  description: 'Description'
};
export const collapsibleContent = {
  title: 'Collapsible',
  subTitle: 'Sub Collapsible',
  description: 'Description'
};

export const collapsibleContentTwo = {
  title: 'CollapsibleTwo',
  subTitle: 'Sub CollapsibleTwo',
  description: 'Description'
};

export const CountryTelephoneNumberInputContent = {
  title: 'Country Telephone Number Input',
  subTitle: 'Sub Country Telephone Number Input',
  description: 'Description'
};

export const HKIDNumberContent = {
  title: 'HKID Number',
  subTitle: 'Sub HKID Number',
  description: 'Description'
};

export const ContextualHelpInputContent = {
  title: 'Contextual Help Input',
  subTitle: 'Sub Contextual Help Input',
  description: 'Description'
};

export const RadioButtonComponentContent = {
  title: 'Toggle Component',
  subTitle: 'Sub Toggle Component',
  description: 'Description'
};

export const TypeInputContent = {
  title: 'Type Input',
  subTitle: 'Sub Type Input',
  description: 'Description'
};

export const ContentListingContent = {
  title: 'Content Listing',
  subTitle: 'Sub Content Listing',
  description: 'Description'
};

export const DialogContent = {
  title: 'Dialog',
  subTitle: 'Sub Dialog',
  description: 'Description'
};
export const DialogUIContent = {
  title: 'Dialog UI',
  subTitle: 'Sub Dialog UI',
  description: 'Description'
};
export const EmmaColorDemoContent = {
  title: 'Emma Color Demo',
  subTitle: 'Sub Emma Color Demo',
  description: 'Description'
};
export const fullPageTnCDemo = {
  title: 'Full Page TnC Demo',
  subTitle: 'Sub Full Page TnC Demo',
  description: 'Description'
};

export const TypographyContent = {
  title: 'Typography',
  subTitle: 'Sub Typography',
  description: 'Description'
};

export const TimePickerContent = {
  title: 'TimePicker',
  subTitle: 'Sub TimePicker',
  description: 'Description'
};

export const TransparentButtonContent = {
  title: 'TransparentButton',
  subTitle: 'TransparentButton',
  description: 'Description'
};

export const BannerContent = {
  title: 'Banner',
  subTitle: 'Sub Banner',
  description: 'Description'
};

export const NotificationContent = {
  title: 'Notification',
  subTitle: 'Sub Notification',
  description: 'Description'
};

export const LevelContent = {
  title: 'level',
  subTitle: 'Sub level',
  description: 'Description'
};

export const DonutChartContent = {
  title: 'DonutChart',
  subTitle: 'Sub DonutChart',
  description: 'Description'
};

export const PolicyCardContent = {
  title: 'PolicyCard',
  subTitle: 'Sub PolicyCard',
  description: 'Description'
};

export const LoadingContent = {
  title: 'Loading',
  subTitle: 'Sub Loading',
  description: 'Description'
};

export const ImageTitleContentContent = {
  title: 'Get up to 20% premium rebate when you get moving ',
  content:
    'Link a tracking device with your registered Emma by AXA account via the Emma setting page to start tracking your steps.',
  image: ''
};

export const progressBarContent = {
  title: 'progressBar',
  subTitle: 'Sub progressBar',
  description: 'Description'
};

export const progressCircleContent = {
  title: 'progressCircle',
  subTitle: 'Sub progressCircle',
  description: 'Description'
};


export const progressBigBarContent = {
  title: 'progressBigBar',
  subTitle: 'Sub progressBigBar',
  description: 'Description'
};

export const ProgressStepContent = {
  title: 'ProgressStep',
  subTitle: 'Sub ProgressStep',
  description: 'Description'
};

export const goalCardContent = {
  title: 'goalCardContent',
  subTitle: 'Sub goalCardContent',
  description: 'Description'
};

export const generalErrorPageContent = {
  title: 'generalErrorPage',
  subTitle: 'Sub generalErrorPage',
  description: 'Description'
};

export const RadioContent = {
  title: 'Radio',
  subTitle: 'Sub Radio',
  description: 'Description'
};

export const SearchInputContent = {
  title: 'Search Input',
  subTitle: 'Sub Search Input',
  description: 'Description'
};