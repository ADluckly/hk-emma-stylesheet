export const zeplinButtonLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f0f0227e95e8e9d2dd9ccb3';
export const zeplinGridSystemLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f1a934c5184382ac722a142';
export const zeplinCheckBoxLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f1e2d5272702a3892af125c';
export const zeplinInputLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f1e2d4fedc3b445b7956a1a';
export const zeplinDropDownLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f1e2d4fedc3b445b7956a1a';
export const zeplinTabLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f9941c85d34a2b4bbf400d9';
export const zeplinModalLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5f0f0226e95e8e9d2dd9cc29';
export const zeplinStepLink =
  'https://app.zeplin.io/project/5f29144650d070308f3d5657/screen/5f6c58b975b8344956fdabc0';
export const zeplinContentListingLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5fe98c8c671efe984b9057e7';
export const zeplinDialogLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5fe98c8c5e253e9a24f38089';
export const zeplinEmmaColorLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/styleguide/colors';
export const zeplinTypographyLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/5fe30b43671efe984b852de5';
export const zeplinNotificationLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/60e3075aa66da816cab7ad24';
export const zeplinDonutChartLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/60f68194e5d431112454c990';
export const zeplinPolicyCardLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/61403dbb8fcaa92bea39b306';
  export const zeplinLoadingLink =
  'https://app.zeplin.io/project/5f0bcab8e844c47fa9bce6e4/screen/618117fd06cf72bf11769a4f';
