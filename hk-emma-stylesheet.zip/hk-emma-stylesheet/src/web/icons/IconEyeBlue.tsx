import React, { PureComponent } from 'react';

export default class IconEyeBlue extends PureComponent {
  render() {
    return (
      <svg
        width="24px"
        height="24px"
        viewBox="0 0 24 24"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g
          id="Registration"
          stroke="none"
          strokeWidth="1"
          fill="none"
          fillRule="evenodd"
        >
          <g
            id="Onboarding-Registration-Day-3-Journey"
            transform="translate(-123.000000, -23.000000)"
          >
            <g
              id="Icon/16px_Functional/Eye/Blue"
              transform="translate(123.000000, 23.000000)"
            >
              <rect id="Rectangle" x="0" y="0" width="24" height="24" />
              <g id="Group" fill="#494DF4" fillRule="nonzero">
                <g
                  id="ic_remove_red_eye_black_24px-(2)"
                  transform="translate(0.000000, 4.500000)"
                >
                  <path
                    d="M12,0 C7,0 2.73,3.11 1,7.5 C2.73,11.89 7,15 12,15 C17,15 21.27,11.89 23,7.5 C21.27,3.11 17,0 12,0 Z M12,12.5 C9.24,12.5 7,10.26 7,7.5 C7,4.74 9.24,2.5 12,2.5 C14.76,2.5 17,4.74 17,7.5 C17,10.26 14.76,12.5 12,12.5 Z M12,4.5 C10.34,4.5 9,5.84 9,7.5 C9,9.16 10.34,10.5 12,10.5 C13.66,10.5 15,9.16 15,7.5 C15,5.84 13.66,4.5 12,4.5 Z"
                    id="Shape"
                  />
                </g>
              </g>
            </g>
          </g>
        </g>
      </svg>
    );
  }
}
