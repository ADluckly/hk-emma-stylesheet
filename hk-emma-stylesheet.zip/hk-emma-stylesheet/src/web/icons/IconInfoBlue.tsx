import React, { PureComponent } from 'react';

export default class IconInfoBlue extends PureComponent {
  render() {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 16 16"
      >
        <g fill="none" fill-rule="evenodd">
          <g fill="#494DF4" fill-rule="nonzero">
            <g>
              <g>
                <path
                  d="M7 0C3.136 0 0 3.136 0 7s3.136 7 7 7 7-3.136 7-7-3.136-7-7-7zm.7 10.5H6.3V6.3h1.4v4.2zm0-5.6H6.3V3.5h1.4v1.4z"
                  transform="translate(-125 -1079) translate(125 1079) translate(1 1)"
                />
              </g>
            </g>
          </g>
        </g>
      </svg>
    );
  }
}
