import React, { PureComponent } from 'react';

export default class IconEyeGrey extends PureComponent {
  render() {
    return (<svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
      <g id="Registration" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="Onboarding-Registration-Day-3-Journey" transform="translate(-165.000000, -23.000000)">
          <g id="Icon/16px_Functional/Eye/Grey" transform="translate(165.000000, 23.000000)">
            <rect id="Rectangle" x="0" y="0" width="24" height="24" />
            <g id="ic_remove_red_eye_black_24px-(2)" transform="translate(1.000000, 4.500000)" fill="#999999" fillRule="nonzero">
              <path d="M11,0 C6,0 1.73,3.11 0,7.5 C1.73,11.89 6,15 11,15 C16,15 20.27,11.89 22,7.5 C20.27,3.11 16,0 11,0 Z M11,12.5 C8.24,12.5 6,10.26 6,7.5 C6,4.74 8.24,2.5 11,2.5 C13.76,2.5 16,4.74 16,7.5 C16,10.26 13.76,12.5 11,12.5 Z M11,4.5 C9.34,4.5 8,5.84 8,7.5 C8,9.16 9.34,10.5 11,10.5 C12.66,10.5 14,9.16 14,7.5 C14,5.84 12.66,4.5 11,4.5 Z" id="Shape" />
            </g>
          </g>
          </g>
        </g>
    </svg>
    );
  }
}
