import React, { PureComponent } from 'react';

export default class IconArrowLeft extends PureComponent {
  render() {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="17"
        viewBox="0 0 16 17"
      >
        <g fill="none" fill-rule="evenodd" stroke-linecap="round">
          <g stroke="#494DF4" stroke-width="2">
            <g>
              <g>
                <path
                  d="M0 4L8 12 16 4"
                  transform="translate(-350 -425) translate(339 409) matrix(0 1 1 0 11 15)"
                />
              </g>
            </g>
          </g>
        </g>
      </svg>
    );
  }
}
