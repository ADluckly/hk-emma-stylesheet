import React, { PureComponent } from 'react';

export default class IconTooltipBlue extends PureComponent {
  render() {
    return (
      <svg
        width="16px"
        height="16px"
        viewBox="0 0 16 16"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g
          id="Registration"
          stroke="none"
          stroke-width="1"
          fill="none"
          fill-rule="evenodd"
        >
          <g
            id="Onboarding-Registration-Day-3-Journey"
            transform="translate(-57.000000, -26.000000)"
          >
            <g
              id="Icon/16px_Functional/Tooltip-Blue"
              transform="translate(57.000000, 26.000000)"
            >
              <circle id="Oval-6" stroke="#494DF4" cx="8" cy="8" r="7.5" />
              <rect
                id="Rectangle"
                fill="#494DF4"
                x="7"
                y="7"
                width="2"
                height="5"
                rx="1"
              />
              <rect
                id="Rectangle"
                fill="#494DF4"
                x="7"
                y="4"
                width="2"
                height="2"
                rx="1"
              />
            </g>
          </g>
        </g>
      </svg>
    );
  }
}
