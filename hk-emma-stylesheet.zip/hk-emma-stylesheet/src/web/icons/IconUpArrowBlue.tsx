import React, { PureComponent } from 'react';

type IconUpArrowBlueProps = {
  normalIconSize: string;
};

export default class IconUpArrowBlue extends PureComponent<IconUpArrowBlueProps> {
  static defaultProps = {
    normalIconSize: '28',
  };

  render() {
    const { normalIconSize } = this.props;
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={normalIconSize}
        height={normalIconSize}
        viewBox="0 0 16 16"
      >
        <g fill="none" fillRule="evenodd">
          <g>
            <g>
              <path
                d="M0 0H16V16H0z"
                transform="translate(-343.000000, -350.000000) translate(351.000000, 358.000000) rotate(180.000000) translate(-351.000000, -358.000000) translate(343.000000, 350.000000)"
              />
              <path
                fill="#494DF4"
                fill-rule="nonzero"
                d="M4.175 5L8 8.712 11.825 5 13 6.148 8 11 3 6.148z"
                transform="translate(-343.000000, -350.000000) translate(351.000000, 358.000000) rotate(180.000000) translate(-351.000000, -358.000000) translate(343.000000, 350.000000)"
              />
            </g>
          </g>
        </g>
      </svg>
    );
  }
}
