import React, { PureComponent } from 'react';

export default class IconUpTriangleBlue extends PureComponent {
  render() {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="12"
        height="12"
        viewBox="0 0 12 12"
      >
        <defs>
          <filter id="v77wfp0hfa" colorInterpolationFilters="auto">
            <feColorMatrix
              in="SourceGraphic"
              values="0 0 0 0 0.286275 0 0 0 0 0.301961 0 0 0 0 0.956863 0 0 0 1.000000 0"
            />
          </filter>
        </defs>
        <g fill="none" fillRule="evenodd">
          <g>
            <g>
              <g>
                <g>
                  <g
                    transform="translate(-726.000000, -757.000000) translate(523.000000, 525.000000) translate(26.000000, 229.000000) translate(0.000000, 3.000000) translate(177.000000, -0.000000)"
                  >
                    <g>
                      <path
                        fill="#494DF4"
                        fillRule="nonzero"
                        d="M0.247 0.247L0.247 7.245 5.753 3.75z"
                        transform="translate(6.000000, 6.000000) rotate(-270.000000) translate(-6.000000, -6.000000) translate(3.000000, 2.250000)"
                      />
                    </g>
                  </g>
                </g>
              </g>
            </g>
          </g>
        </g>
      </svg>
    );
  }
}
