import React, { PureComponent } from 'react';

export default class IconClockDark extends PureComponent {
  render() {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
      >
        <g fill="#333">
          <path
            d="M10.5.495C4.974.495.495 4.975.495 10.5c0 5.526 4.48 10.005 10.005 10.005 5.526 0 10.005-4.48 10.005-10.005.004-2.655-1.049-5.202-2.926-7.079C15.702 1.544 13.155.491 10.5.495zm0 18c-4.416 0-7.995-3.58-7.995-7.995 0-4.416 3.58-7.995 7.995-7.995 4.416 0 7.995 3.58 7.995 7.995 0 4.416-3.58 7.995-7.995 7.995z"
            transform="translate(1.5 1.5)"
          />
          <path
            d="M10.995 5.505L9.495 5.505 9.495 11.505 14.745 14.655 15.495 13.425 10.995 10.755z"
            transform="translate(1.5 1.5)"
          />
        </g>
      </svg>
    );
  }
}
