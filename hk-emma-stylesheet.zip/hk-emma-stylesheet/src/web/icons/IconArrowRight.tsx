import React, { PureComponent } from 'react';

export default class IconArrowRight extends PureComponent {
  render() {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="17"
        viewBox="0 0 16 17"
      >
        <g fill="none" fill-rule="evenodd" stroke-linecap="round">
          <g stroke="#494DF4" stroke-width="2">
            <g>
              <path
                d="M1 4L9 12 17 4"
                transform="translate(-9 -423) rotate(90 -199 224)"
              />
            </g>
          </g>
        </g>
      </svg>
      
    );
  }
}
