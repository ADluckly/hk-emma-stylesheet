export const isApp = () => {
  const userAgent = navigator.userAgent;
  const regex = new RegExp("EMMA( [A-Za-z]+)?/([0-9]+.){3}[0-9]{8,10}", "g");
  return regex.test(userAgent);
};

type ComposeFn<R> = (a: R) => R;

export const compose = <R>(..._fns: Array<ComposeFn<R> | false>) => {
  const fns = _fns.filter(Boolean) as Array<ComposeFn<R>>;

  const composedFn: ComposeFn<R> = fns.reduce(
    (prevFn, nextFn) => (value: R) => nextFn(prevFn(value)),
    (a) => a
  );

  return composedFn;
};

export function bypassFalse<T>(fn: (t: T) => T | false) {
  const wrappedFn = (t: T | false) => {
    if (!t) return false;
    return fn(t);
  };
  return wrappedFn;
}
