export const removeCommas = (s: string) => s.replace(/,/g, '');
export const removeLeadingZeros = (s: string) => s.replace(/^(-?)0+/, '$1') || '0';

// https://stackoverflow.com/a/2901298
export const numberWithCommas = (s: string) => {
  const [integer, decimal] = s.split('.');
  const integerWithCommas = integer.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  if (!decimal) return integerWithCommas;
  return `${integerWithCommas}.${decimal}`;
};

// https://stackoverflow.com/a/5917250
export const commasOptional = (s: string) => {
  const valid = /^(-)?(\d+|\d{1,3}(,\d{3})*)(\.\d+)?$/.test(s);
  // console.log("commasOptional valid", valid, String(s), typeof s);
  return valid ? removeCommas(s) : false;
};

export const numberOnly = (s: string) => {
  const valid = /^(-)?\d/.test(s);
  // console.log("numberOnly valid", valid);
  return valid ? removeLeadingZeros(s) : false;
};

export const positiveOnly = (s: string) => {
  const valid = /^\d/.test(s);
  // console.log("positiveOnly valid", valid);
  return valid ? removeLeadingZeros(s) : false;
};

export const toCommasGrouped = (s: string) => {
  const valid = !isNaN(Number(s));
  // console.log("toCommasGrouped valid", valid, String(s), typeof s);
  return valid ? numberWithCommas(s) : false;
};
