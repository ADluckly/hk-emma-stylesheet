// Valid Email
import { DropdownOption, DropdownProps } from '../components/Dropdown/Dropdown';

export const getIsValidEmail = (value: string) => {
  // General Email Regex (RFC 5322 Official Standard)
  const isValidEmail =
    (value && /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(value)) || false;
  return isValidEmail;
};

// Valid Mobile
export const getIsValidMobileNumber = (
  countryCode: string,
  mobileNo: string
) => {
  const mobileLen = mobileNo.length;
  if (RegExp(/[^0-9]/).test(mobileNo)) return false;
  if (countryCode === '86') {
    return mobileLen === 11 && mobileNo.startsWith('1');
  } else if (countryCode === '852' || countryCode === '853') {
    return mobileLen === 8;
  } else if (countryCode === '886') {
    if (mobileNo.substr(0, 1) === '9') {
      return mobileLen === 9;
    }
    if (mobileNo.substr(0, 2) === '09') {
      return mobileLen === 10;
    }
  }
  return false;
};

// Valid Number
export const getIsValidNumber = (number: string) => {
  if (!number && number.length === 0) return false;
  if (RegExp(/[^0-9]/).test(number)) return false;
  return true;
};

// get FullName
export const getFullName = (value: string) => {
  value = value.replace(/[^\u4E00-\u9FA5a-zA-Z\s]/g, '');
  return value;
};

// Valid FullName
export const getIsValidFullName = (value: string) => {
  const IsValidFullName = value && value.length > 0;
  return IsValidFullName;
};

// get int number for maxlength
export const intNumberInMaxLength = (max: number, value: string) => {
  const reg = /^-?(0|[1-9][0-9]*)?$/;
  let result = value;
  if (!reg.test(value.charAt(value.length - 1))) {
    result = value.slice(0, value.length - 1);
  }
  if (result && result.length === max) {
    return result;
  }
  return result.slice(0, max);
};

// validate Format Input
export const validateFormatInput = (
  value?: string,
  validateRule?: RegExp,
  opt?: any,
  min?: number,
  max?: number
) => {
  const re = validateRule ? new RegExp(validateRule) : null;
  if (!value && !opt) return false;
  if (value && /[\uff00-\uffff]/.test(value)) return false;
  if (value && min && value.length < min) return false;
  if (value && max && value.length > max) return false;
  if (value && re && !re.test(value)) return false;
  return true;
};

// get day list
export const getDayList = () => {
  const days = [];
  for (let i = 1; i <= 31; i++) {
    let dayString = i.toString();
    if (dayString.length === 1) {
      dayString = `0${dayString}`;
    }
    days.push({
      optionVal: dayString,
      optionTitle: dayString,
    } as DropdownOption);
  }
  return days;
};

// get month list
export const getMonthList = () => {
  const months = [];
  for (let i = 1; i <= 12; i++) {
    let monthString = i.toString();
    if (monthString.length === 1) {
      monthString = `0${monthString}`;
    }
    months.push({
      optionVal: monthString,
      optionTitle: monthString,
    } as DropdownOption);
  }
  return months;
};

// get year list
export const getYearList = () => {
  const years = [];
  const year = new Date().getFullYear();
  for (let i = year - 18; i > year - 65; i--) {
    const yearString = i.toString();
    years.push({
      optionVal: yearString,
      optionTitle: yearString,
    } as DropdownOption);
  }
  return years;
};

const convertHKIdIChar = (char: string | any) => {
  if (char.match('^[A-Z]*$')) {
    return char.charCodeAt() - 55;
  }
  return char;
};

// valiate hkid for checkDight
export const validateHKid = (hkId: string, checkDight: string | number) => {
  let strValidChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  let str = hkId + checkDight

  // basic check hkid length
  if (hkId.length < 7)
    return [false, true];

  // basic check hkid
  let hkidPat = /^([A-Z]{1,2})([0-9]{6})$/;
  let hkidArray = hkId.match(hkidPat);
  // not match, return false
  if (hkidArray == null)
    return [false, true];

  // basic check length
  if (str.length < 8)
    return [true, false];

  // handling bracket
  if (str.charAt(str.length - 3) == '(' && str.charAt(str.length - 1) == ')')
    str = str.substring(0, str.length - 3) + str.charAt(str.length - 2);

  // convert to upper case
  str = str.toUpperCase();

  // regular expression to check pattern and split
  let strPat = /^([A-Z]{1,2})([0-9]{6})([A0-9])$/;
  let matchArray = str.match(strPat);

  // not match, return false
  if (matchArray == null)
    return [true, false];

  // the character part, numeric part and check digit part
  let charPart:any = matchArray[1];
  let numPart:any = matchArray[2];
  let checkDigit:any = matchArray[3];

  // calculate the checksum for character part
  let checkSum = 0;
  if (charPart.length == 2) {
    checkSum += 9 * (10 + strValidChars.indexOf(charPart.charAt(0)));
    checkSum += 8 * (10 + strValidChars.indexOf(charPart.charAt(1)));
  } else {
    checkSum += 9 * 36;
    checkSum += 8 * (10 + strValidChars.indexOf(charPart));
  }

  // calculate the checksum for numeric part
  for (var i = 0, j = 7; i < numPart.length; i++, j--)
    checkSum += j * numPart.charAt(i);

  // verify the check digit
  let remaining = checkSum % 11;
  let verify = remaining == 0 ? 0 : 11 - remaining;

  return [true, verify == checkDigit || (verify == 10 && checkDigit == 'A')];
};

//filter zh
export const filterPasswordValue = (value: string = '') => {
  return value.replace(/[\u4E00-\u9FA5]/g, '')
}

export const BEMClassName = (block: string, elements?: string | string[], modifier?: string) => {
  let className: string = block;

  if (elements) {
    className = Array.isArray(elements) && elements.length > 0
      ? `${block}__${elements.join('__')}`
      : `${block}__${elements}`;
  }

  if(modifier) className = `${className}--${modifier}`;

  return className
}