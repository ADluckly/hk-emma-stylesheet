// input field
export const INPUT_TYPE_TEXT = 'text';
export const INPUT_TYPE_EMAIL = 'email';
export const INPUT_TYPE_FULL_NAME = 'fullName';
export const INPUT_TYPE_MOBILE = 'mobile';
export const INPUT_TYPE_HKID = 'hkid';
export const INPUT_TYPE_CHECKDIGIT = 'checkDigit';
export const INPUT_TYPE_NUMBER = 'number';
export const TEXTAREA = 'textarea';
