declare module '*.scss';
declare module '*.mdx';
