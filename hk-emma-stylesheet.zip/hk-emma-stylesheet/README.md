# hk-emma-style-sheet

This is a project contains all the common components that share by all EMMA projects. It contains React Web Components, Web SaaS Styles and APP React Native Components. All the components can be viewed in the [online storybook](https://hk-emma-storybook-emma-dv.axa-hk-preprod-mpl-int.berry.eastasia.azure.openpaas.axa-cloud.com/main/index.html).

## Prerequisites
- Node Version: 10.15.3
- Yarn Version: 1.22.11

## Installation

1. Install all the dependencies for three different code base: web, app & app example
```
yarn run install-all
```
2. Start 3 storybook processes includes MAIN, WEB & APP
```
yarn run storybook
```
- The WEB & APP processes will run in background managed by [PM2](https://github.com/Unitech/pm2) 
- The WEB & APP processes should start **BEFORE** the MAIN process
  1. The script will sleep for 45 seconds before run the MAIN
  2. Sometime 45 seconds are not enough to start the service
  3. To fix it 
     1. `ctrl+c` to exit
     2. `yarn run storybook-main`
3. Stop the WEB & APP processes that were running in background managed by [PM2](https://github.com/Unitech/pm2)
```
yarn run storybook-stop 
```

## Storybook

[Storybook](https://storybook.js.org/) is a UI components explorer for developers and designers to view. To make the components viewable by the storybook, the developers should define the *.stories.tsx files in the specific stories folder.

This project has used the advance [composition logic](https://storybook.js.org/docs/react/workflows/storybook-composition) to make both APP & WEB stories can be shown in one page. In fact, there are 3 storybook instance running which are MAIN, APP and WEB.

#### MAIN storybook
It is the entry point that will embed the APP storybook and WEB storybook by iFrame.

#### WEB storybook
The web component can be directly rendered by the storybook after defined the `*.stories.tsx` in the `stories` folder.

#### APP storybook
The react-native-web library will help to compile the app components and rendered in web after defined `*.stories.tsx` in the `stories` folder.

## Project Structure

The project contains both APP & WEB logic. The logic will be separated by different folders

#### WEB
- Mainly Under `hk-emma-stylesheet/src/web`
- The `hk-emma-stylesheet` is the base for WEB library
  - When deploy the web component to public, the yarn command should run here
- File Structure
  - Components: `hk-emma-stylesheet/src/web/components`
  - Styles: `hk-emma-stylesheet/styles`
  - Storybook Setting: `hk-emma-stylesheet/src/web/.storybook`
  - Stories: `hk-emma-stylesheet/src/web/stories`
 
#### APP
- Mainly under `hk-emma-stylesheet/src/app`
- The `hk-emma-stylesheet/src/app` is for base for APP library
  - When deploy the app component to public, the yarn command should run here
- The `hk-emma-stylesheet/src/app/example` is for local run example
  - When building the app or view the storybook locally, the yarn command should run here
- File Structure
  - Components: `hk-emma-stylesheet/src/app/src/components`
  - Styles: TODO
  - Storybook Setting: `hk-emma-stylesheet/src/app/example/.storybook`
  - Stories: `hk-emma-stylesheet/src/app/example/stories` 

## Development Procedures
1. Start the storybook locally according to the above Installation guide


2. Create your new component in .tsx format
   - For APP: `hk-emma-stylesheet/src/app/src/components`
   - For WEB: `hk-emma-stylesheet/src/web/components`


3. Add your components in
    - For APP: `hk-emma-stylesheet/src/app/src/index.tsx`
    - For WEB: `hk-emma-stylesheet/src/web/index.ts`


4. Create the story file in *.stories.tsx format
   - The format of the stories will be different for WEB & APP
     - [APP story development guide](https://storybook.js.org/tutorials/intro-to-storybook/react-native/en/simple-component)
     - [WEB story development guide](https://storybook.js.org/docs/react/workflows/build-pages-with-storybook)
   - For APP: `hk-emma-stylesheet/src/app/example/stories`
   - For WEB: `hk-emma-stylesheet/src/web/stories`
   - Component will be automatically added to the storybook after you have created the correct stories 


5. Publish the storybook
   1. Push all your update to Git
   2. `yarn release-storybook`
      - It will build and extract one `stories.json` file for WEB and one `stories.json` file for APP
      - These two files should also be committed to Git for facilitate the build process
   3. `yarn pr`


6. Publish the web component library 
   1. Push all your update to Git
   2. `yarn release-web`
      - It will update the version by `npm version` 
      - And it will upload the latest update to the registry
